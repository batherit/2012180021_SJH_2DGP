import game_framework
from simple_math_tool import *
from hero import *
from map import Map
from carpet import Carpet
import random
import json
import stage2_gap
import stage1_gap
from pico2d import *


#주인공의 공격 상태
enumerate(['NORAML', 'ATTACK' ])
#주인공의 공격 방향
enumerate(['DEFAULT','LEFT, RIGHT, UP, DOWN'])
#주인공의 공격 타입
enumerate(['SKILL1, SKILL2, SKILL3'])
#왕과 왕비 구출 상태
enumerate(['NOT', 'SAVE']) #APPEAR, DIE 추가 예정

#UI 클래스
class UI:
    # global font
    # global hero
    # global enemy2
    # global hostage_num
    # global king_state
    # global queen_state
    # global HP_buff_show_time
    # global HP_buff_degree
    # global combo_flag
    # global combo_score
    # global combo_score_show_time
    # global combo_score_degree

    INIT_X, INIT_Y = 450, 350
    DISPLAY_CENTER_X, DISPLAY_CENTER_Y = 350, 350
    ULTRA_SCORE_SHOW_TIME = 70

    def ScoreInform(self, x, y, ctrlY, color):
        font.draw(x, y, '[SCORE]', color)
        font.draw(x, y-20, ': %d'%score, color)
        if combo_flag == True:
            font.draw(x, y-40, ': +RESCUE BONUS', color)
            font.draw(x, y-60, ': %d'%combo_score, color)


    def EnemyState(self, x, y, ctrlY, color):
        font.draw(x, y+ctrlY, '[Boss State]', color)
        font.draw(x, y-20+ctrlY, '-HP : %d'%enemy1.HP, color)


    def HeroState(self, x, y, ctrlY, color):
        font.draw(x, y+ctrlY, '[Hero State]', color)
        font.draw(x, y-20+ctrlY, '-HP : %d'%hero.HP, color)
        font.draw(x, y-40+ctrlY, '-Skill Type', color)
        font.draw(x, y-60+ctrlY, ': %s'%hero.skillType, color)
        if hero.skillType == 'SKILL2' :
            font.draw(x, y-80+ctrlY, '+CAHRGE', color)
            if hero.skill2Delay == 0 : font.draw(x, y-100+ctrlY, ': READY', color)
            else: font.draw(x, y-100+ctrlY, ': %d'%(70-hero.skill2Delay), color)
        elif hero.skillType == 'SKILL3' :
            font.draw(x, y-80+ctrlY, '+VALID NUM', color)
            font.draw(x, y-100+ctrlY, ': %d'%(5-hero.heroSkill3_num), color)
            font.draw(x, y-120+ctrlY, '+COOLTIME', color)
            if hero.heroSkill3_num >= 5:
                font.draw(x, y-140+ctrlY, ': %d'%(300-hero.heroSkill3CoolTime), color)
            else :
                font.draw(x, y-140+ctrlY, ': Completion', color)


    def RescueInform(self, x, y, ctrlY, color):
        font.draw(x, y+ctrlY, '[RESCUE INFORM]', color)
        font.draw(x, y-20+ctrlY, '-APPEAR : %d'%hostage_num, color)
        font.draw(x, y-40+ctrlY, '-SAVE : %d'%save_num, color)
        font.draw(x, y-60+ctrlY, 'KING : %s'%king_state, color)
        font.draw(x, y-80+ctrlY, 'QUEEN : %s'%queen_state, color)

    def CurrentStage(self, x, y, ctrlY, color, stage):
        font.draw(x, y, '[Current Stage]', color)
        font.draw(x, y-20, ': %d'%stage, color)
    def __init__(self):
        self.UITitle = load_image('UI/UITitle.png')
        self.gameover = load_image('UI/gameover.png')
        ui_data_file = open('UI/UI.txt', 'r')
        self.ui_data = json.load(ui_data_file)
        ui_data_file.close()

    def update(self):
        global score
        global king_state
        global queen_state
        global ultra_score
        global ultra_score_show_time
        global kq_all_rescue_flag
        if hero.survive == True : score += 1
        if kq_all_rescue_flag == False:
            if king_state == 'SAVE' and queen_state == 'SAVE':
                ultra_score_show_time = self.ULTRA_SCORE_SHOW_TIME
                score += ultra_score
                kq_all_rescue_flag = True


    def draw(self):
        global HP_buff_show_time
        global point_show_time
        global combo_score_show_time
        global combo_score_degree
        global ultra_score
        global ultra_score_show_time
        self.UITitle.draw(UI.INIT_X, UI.INIT_Y)
        self.ScoreInform(self.ui_data['Score']['x'], self.ui_data['Score']['y'], self.ui_data['Score']['ctrlY'],\
                        (self.ui_data['Score']['R'], self.ui_data['Score']['G'], self.ui_data['Score']['B']))
        if point_show_time > 0 :
            font.draw(hero.x + carpet.x - 50, hero.y + carpet.y +40+40/(point_show_time+1), 'POINT +%d'%point_degree, (100,200,100))
            point_show_time -= 1
        if combo_score_show_time > 0 :
            font.draw(hero.x + carpet.x - 100, hero.y + carpet.y +40+40/(combo_score_show_time+1), 'RESCUE BONUS +%d'%combo_score_degree , (200,100,200))
            combo_score_show_time -= 1
        if ultra_score_show_time > 0 :
            font.draw(hero.x + carpet.x - 90, hero.y + carpet.y +40+40/(ultra_score_show_time+1), 'ULTRA BONUS +%d'%ultra_score  , (250,250,100))
            ultra_score_show_time -= 1
        # self.CurrentStage(self.ui_data['CurrentStage']['x'], self.ui_data['CurrentStage']['y'], self.ui_data['CurrentStage']['ctrlY'],\
        #                   (self.ui_data['CurrentStage']['R'], self.ui_data['CurrentStage']['G'], self.ui_data['CurrentStage']['B']), 2)
        self.EnemyState(self.ui_data['EnemyState']['x'], self.ui_data['EnemyState']['y'], self.ui_data['EnemyState']['ctrlY'],\
                         (self.ui_data['EnemyState']['R'], self.ui_data['EnemyState']['G'], self.ui_data['EnemyState']['B']))
        self.HeroState(self.ui_data['HeroState']['x'], self.ui_data['HeroState']['y'], self.ui_data['HeroState']['ctrlY'],\
                       (self.ui_data['HeroState']['R'], self.ui_data['HeroState']['G'], self.ui_data['HeroState']['B']))
        self.RescueInform(self.ui_data['RescueInform']['x'], self.ui_data['RescueInform']['y'], self.ui_data['RescueInform']['ctrlY'],\
                          (self.ui_data['RescueInform']['R'], self.ui_data['RescueInform']['G'], self.ui_data['RescueInform']['B']))
        if HP_buff_show_time > 0 :
            font.draw(hero.x + carpet.x - 30, hero.y + carpet.y +20+20/(HP_buff_show_time+1), 'HP +%d'%HP_buff_degree, (200,100,100))
            HP_buff_show_time -= 1
        if hero.survive == False : self.gameover.draw(UI.DISPLAY_CENTER_X, UI.DISPLAY_CENTER_Y)



#enemy1 클래스
class Enemy1:
    global hero
    global carpet

    enemy1img = None
    enemy1die = None
    enemy1disappear = None
    enemy1dark = None
    # enemy2die = None
    electric_shock = None

    EYE_TO_RIGHT, EYE_TO_LEFT = 0, 1
    EYE_TO_UP, EYE_TO_DOWN = 0, 1
    EYE_POSITION_Y = 80
    MAP_CENTER_X, MAP_CENTER_Y = 350, 350

    NORMAL, ENEMY1_PATTERN1, ENEMY1_PATTERN2, ENEMY1_PATTERN3  = 0, 1, 2, 3

    def enemy1_normal(self):        #enemy1의 평범한 움직임
        if self.move_count == 4:
            if self.frame == 0:     #self.aniDelay == 0 인 상태
                self.state = random.randint(1,3)#random.randint(0,3) #차후 추가되면 랜덤으로 패턴을 돌린다.
                self.move_flag = False
                self.move_count = 0
        else :
            if self.move_flag == False:
                self.move_delay+=1
                if self.move_delay == self.move_ding:
                    self.carpetX = carpet.x
                    self.carpetY = carpet.y
                    self.hero_around_angle += (-1+2*random.randint(0,1))*30
                    self.around_r = random.randint(-300,300)
                    self.endX = self.carpetX + self.around_r*math.cos(math.pi/180*self.hero_around_angle)
                    self.endY = self.carpetY + self.around_r*math.sin(math.pi/180*self.hero_around_angle)
                    self.angle = angle(self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X), self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y), self.endX, self.endY)
                    self.move_flag = True
                    self.move_delay = 0
                    self.move_ding = 1
                    self.velocity = 5
            elif self.move_flag == True:
                if 12 > distance(self.endX, self.endY,self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X), self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)):
                    self.move_flag = False
                    self.move_count+=1
                else:
                    self.x += self.velocity*math.cos(math.pi/180*self.angle)
                    self.y += self.velocity*math.sin(math.pi/180*self.angle)

    def enemy1_pattern1(self): #SickleWind!
        if self.move_count == 7:
            if self.frame == 0:     #self.aniDelay == 0 인 상태
                self.state = random.randint(1,3)#random.randint(0,3) #차후 추가되면 랜덤으로 패턴을 돌린다.
                self.move_flag = False
                self.move_count = 0
        else :
            if self.move_flag == False:
                self.move_delay+=1
                if self.move_delay == self.move_ding:
                    self.carpetX = carpet.x
                    self.carpetY = carpet.y
                    #self.hero_around_angle += (-1+2*random.randint(0,1))*30
                    self.around_r = random.randint(-200,200)
                    if math.fabs(carpet.x-(self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X))) > math.fabs(carpet.y-(self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y))):
                        self.endX = Enemy1.MAP_CENTER_X + (-1+2*self.ThisIsRight(carpet.x))*400-0.7*(self.carpetX-Enemy1.MAP_CENTER_X)
                        self.endY = Enemy1.MAP_CENTER_Y +  ((carpet.y-Enemy1.MAP_CENTER_Y)/400)*400-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)
                    else :
                        self.endX =Enemy1.MAP_CENTER_X +  ((carpet.x-Enemy1.MAP_CENTER_X)/400)*400-0.7*(self.carpetX-Enemy1.MAP_CENTER_X)
                        self.endY =Enemy1.MAP_CENTER_Y + (-1+2*self.ThisIsUP(carpet.y))*400-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)
                    self.angle = angle(self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X), self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y), self.endX, self.endY)
                    self.move_flag = True
                    self.move_delay = 0
                    self.move_ding = 1
                    self.velocity = 1
            elif self.move_flag == True:
                if 30 > distance(self.endX, self.endY, self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X), self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)) :
                    self.move_flag = False
                    self.acceleration = 0
                    self.move_count+=1
                else:
                    self.acceleration += 0.1
                    self.x += (self.velocity+self.acceleration)*math.cos(math.pi/180*self.angle)
                    self.y += (self.velocity+self.acceleration)*math.sin(math.pi/180*self.angle)


    def enemy1_pattern2(self): #HideAndSeek
        if self.move_count == 4:
            if self.frame == 0:     #self.aniDelay == 0 인 상태
                self.state = random.randint(1,3)#random.randint(0,3) #차후 추가되면 랜덤으로 패턴을 돌린다.
                self.move_flag = False
                self.move_count = 0
        else :
            if self.move_flag == False:
                self.move_delay+=1
                if self.move_delay == self.move_ding:
                    self.carpetX = carpet.x
                    self.carpetY = carpet.y
                    #self.hero_around_angle += (-1+2*random.randint(0,1))*30
                    self.around_r = random.randint(-200,200)
                    # if self.move_count <5:
                    self.endX = Enemy1.MAP_CENTER_X + (1-2*self.ThisIsRight(carpet.x))*(380+random.randint(-20, 20))-0.7*(self.carpetX-Enemy1.MAP_CENTER_X)
                    self.endY = Enemy1.MAP_CENTER_Y +  ((carpet.y-Enemy1.MAP_CENTER_Y)/350)*(400+random.randint(-20, 20))-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)
                    # else:
                    #     self.endX = Enemy1.MAP_CENTER_X + (-1+2*self.ThisIsRight(carpet.x))*(380+random.randint(-20, 20))-0.7*(self.carpetX-Enemy1.MAP_CENTER_X)
                    #     self.endY = Enemy1.MAP_CENTER_Y +  ((carpet.y-Enemy1.MAP_CENTER_Y)/350)*(400+random.randint(-20, 20))-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)
                    self.angle = angle(self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X), self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y), self.endX, self.endY)
                    self.move_flag = True
                    self.move_delay = 0
                    self.move_ding = 1
                    self.velocity = 3
            elif self.move_flag == True:
                if 30 > distance(self.endX, self.endY, self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X), self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)) :
                    self.move_flag = False
                    self.move_count+=1
                else:
                    self.x += (self.velocity+self.acceleration)*math.cos(math.pi/180*self.angle)
                    self.y += (self.velocity+self.acceleration)*math.sin(math.pi/180*self.angle)


    def enemy1_pattern3(self):
        if self.attack_time <= 0:
            if self.frame == 0:     #self.aniDelay == 0 인 상태
                self.state = random.randint(1,3)#random.randint(0,3) #차후 추가되면 랜덤으로 패턴을 돌린다.
                self.darkFlag = False
                self.disappear = False
                self.attack_time = 500
        else :
            if self.darkFlag == True:
                self.attack_time-=1
                if 10 < distance(carpet.x, carpet.y,self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y)):
                    self.angle = angle(self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y), carpet.x, carpet.y)
                    self.x += self.velocity*math.cos(math.pi/180*self.angle)
                    self.y += self.velocity*math.sin(math.pi/180*self.angle)
    enemy1_state = {
        NORMAL : enemy1_normal,
        ENEMY1_PATTERN1 : enemy1_pattern1,
        ENEMY1_PATTERN2 : enemy1_pattern2,
        ENEMY1_PATTERN3 : enemy1_pattern3
    }

    def ThisIsRight(self, objX):
        if self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X) < objX : return 1
        else : return 0
    def ThisIsUP(self, objY):
        if self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y) < objY : return 1
        else : return 0

    def __init__(self):
        self.x, self.y = Enemy1.MAP_CENTER_X+400*math.cos(math.pi/180 * random.randint(0, 360)), Enemy1.MAP_CENTER_Y+400*math.sin(math.pi/180 * random.randint(0, 360))
        self.frame = 0
        self.move_count = 0 #패턴 총 행동 횟수
        self.move_flag = False
        self.move_delay = 0
        self.move_ding = 10
        self.darkFlag = False
        self.angle = 0.0
        self.hero_around_angle = 0.0
        self.carpetX=0.0
        self.carpetY=0.0
        self.endX = 0.0
        self.endY = 0.0
        self.around_r = 0
        self.velocity = 0
        self.acceleration = 0
        self.state = Enemy1.NORMAL
        self.aniDelay = 0
        self.attack_time = 500
        self.attack_ding=0
        self.attack_delay = 0
        self.attack_count = 0
        self.attack_count_max = 0
        self.skillX = 0
        self.skillY = 0
        self.signFlag = 1
        self.HP = 5
        self.survive = True
        self.delete = False
        self.disappear=False
        self.electric_shock_flag = False
        self.electric_shock_frame = 0
        self.electric_shock_aniDelay = 0
        self.power = 20
        # self.defensive_power = 5
        if Enemy1.enemy1img == None: Enemy1.enemy1img = load_image('enemy1/enemy1AniSet.png')
        if Enemy1.enemy1die == None: Enemy1.enemy1die = load_image('enemy1/enemy1die.png')
        if Enemy1.enemy1disappear == None : Enemy1.enemy1disappear = load_image('enemy1/pattern/enemy1darksign.png')
        if Enemy1.enemy1dark == None : Enemy1.enemy1dark = load_image('enemy1/pattern/enemy1pattern2dark.png')
        if Enemy1.electric_shock == None: Enemy1.electric_shock = load_image('hero/heroSkill/skill2boom.png')
    def update(self):
        if self.HP <= 0:
            if self.survive == True:
                self.survive = False
                self.frame = 0
                self.aniDelay = 0
        if self.survive == True : self.enemy1_state[self.state](self)


    def draw(self, objX):
        global enemy1
        global score
        global combo_flag
        global combo_score
        global combo_score_degree
        global combo_score_show_time

        self.aniDelay+=1
        if self.survive == True:
            #if self.state == self.NORMAL :
            if self.darkFlag == False : self.enemy1img.clip_draw(self.frame*300, 350*(1-self.ThisIsRight(objX))+700*(self.state), 300,350, self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y))
            else :
                self.enemy1img.clip_draw(self.frame*300, 350*(1-self.ThisIsRight(objX))+700*(self.state - 1), 300,350, self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y))
                self.enemy1dark.clip_draw(0, 0, 1250,1250, carpet.x, carpet.y)
                if self.disappear == False : self.enemy1disappear.clip_draw(self.frame*300, 80*(1-self.ThisIsRight(objX)), 300,80, self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y+Enemy1.EYE_POSITION_Y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y))
        else:
            if self.delete == False : self.enemy1die.clip_draw(self.frame*300, 0, 300,300, self.x-0.7*(carpet.x-350), self.y-0.7*(carpet.y-350))

        if self.aniDelay == 10 :
            if self.delete == False : self.frame = (self.frame+1)%8

            if self.survive == True:
                if self.state == self.ENEMY1_PATTERN2:
                    if self.frame == 4:
                        enemy1SickleWindList.append(SickleWind(1-self.ThisIsRight(carpet.x),self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y), carpet.x,carpet.y))
                elif self.state == self.ENEMY1_PATTERN3:
                    if self.darkFlag == False and self.frame == 0:
                        self.darkFlag = True
                        self.velocity = 1
                    # elif self.darkFlag == True and self.frame == 4 and 250 < distance(carpet.x, carpet.y,self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y)):
                    #     enemy1SickleWindList.append(SickleWind(self.ThisIsRight(carpet.x),self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y), carpet.x,carpet.y))
                    elif self.darkFlag == True and self.disappear == False:
                        if self.frame == 0:
                            self.disappear = True
                            self.attack_ding = 2
                            self.attack_delay = 0
                            # self.attack_count = 0
                            # self.attack_count_max = 6
            else:
                if self.frame == 0:
                    self.delete = True
                    while(len(enemy1SickleWindList)):
                        del enemy1SickleWindList[0]
                    while(len(enemy1RazerBox)):
                        del enemy1RazerBox[0]
                    if combo_flag == True:
                        combo_flag = False
                        combo_score_show_time = 15
                        score += combo_score
                        combo_score_degree = combo_score
                        combo_score = 0
            if self.disappear == True:
                self.attack_delay +=1
                if self.attack_delay == self.attack_ding:
                    self.skillX= (Enemy1.MAP_CENTER_X+((-1+2*random.randint(0,1))*350))-0.7*(carpet.x-Enemy1.MAP_CENTER_X)
                    self.skillY= (Enemy1.MAP_CENTER_Y+((-1+2*random.randint(0,1))*350))-0.7*(carpet.y-Enemy1.MAP_CENTER_Y)
                    for i in range(0, 30):
                        enemy1RazerBox.append(Enemy1Razer(360/30*i+45*self.signFlag, self.skillX, self.skillY ))
                    self.signFlag = 1-self.signFlag
                    self.attack_delay = 0
                #
                # if self.attack_count >= self.attack_count_max:
                #         self.attack_start = False
                #         self.move_count+=1
                        # self.attack_count=0
                        # self.x = Enemy1Razer.MAP_CENTER_X+random.randint(-Enemy1Razer.MAP_CENTER_X, Enemy1Razer.MAP_CENTER_X)+0.7*(carpet.x-Enemy1Razer.MAP_CENTER_X)
                        # self.y = Enemy1Razer.MAP_CENTER_Y+random.randint(-Enemy1Razer.MAP_CENTER_Y, Enemy1Razer.MAP_CENTER_Y)+0.7*(carpet.y-Enemy1Razer.MAP_CENTER_Y)
                        # self.disappear = False
                        # self.frame = 0
                        # self.attack_ding = 2
                        # self.attack_delay = 0
                        # self.attack_count = 0
                        # self.attack_count_max = 6
                # elif self.attack_count < self.attack_count_max:
                #     if self.attack_delay == self.attack_ding: #공격 입력
                #         for i in range(0, 20):
                #             enemy1RazerBox.append(Enemy1Razer(360/20*i+45*(self.attack_count%2), self.x-0.7*(carpet.x-Enemy1Razer.MAP_CENTER_X),self.y-0.7*(carpet.y-Enemy1Razer.MAP_CENTER_Y)))
                #         self.attack_count = self.attack_count+1
                #         self.attack_delay = 0
            self.aniDelay=0

        if self.electric_shock_flag == True:
            self.electric_shock_aniDelay+=1
            self.electric_shock.clip_draw(self.electric_shock_frame*50, 0, 50,50, self.x-0.7*(carpet.x-350), self.y-0.7*(carpet.y-350))
            if self.electric_shock_aniDelay == 3:
                self.electric_shock_frame=(self.electric_shock_frame+1)%9
                self.electric_shock_aniDelay=0
                if self.electric_shock_frame == 0: self.electric_shock_flag = False

class SickleWind:

    sickleWindImg = None
    EYE_TO_RIGHT, EYE_TO_LEFT = 0, 1

    def __init__(self, dir, x, y, carpetX, carpetY):
        if SickleWind.sickleWindImg == None : SickleWind.sickleWindImg = load_image('enemy1/SickleWind.png')
        self.dir = dir
        self.carpetX = carpetX
        self.carpetY = carpetY
        self.x = x+150*(1-2*self.dir)
        self.y = y
        self.collision = False
        self.velocity = 1
        self.acceleration = 0
        self.power=30

    def update(self):
        self.acceleration+=0.1
        self.x += (self.velocity+self.acceleration)*(1-2*self.dir)

    def draw(self, carpetX, carpetY):
        if self.collision == False :self.sickleWindImg.clip_draw(100*self.dir, 0, 100,350, self.x-0.7*(carpetX-self.carpetX), self.y-0.7*(carpetY-self.carpetY))
        else:
            for i in range(-1, len(enemy1SickleWindList)-1):
                if self == enemy1SickleWindList[i]:
                    del enemy1SickleWindList[i]
                    break

class Enemy1Razer:
    global hero
    global carpet
    global ballRazerBox

    razer = None
    MAP_CENTER_X, MAP_CENTER_Y = 350, 350

    def __init__(self, angle, x, y):
        if Enemy1Razer.razer == None:
            Enemy1Razer.razer = load_image('enemy1/enemy1razer.png')
        self.x = x
        self.y = y
        self.angle = angle
        self.collision = False
        self.carpetX = carpet.x
        self.carpetY = carpet.y
        self.velocity = 3
        self.acceleration = 0
        self.power=20
        self.slope = 0
    def update(self):
        if self.collision == False:
            self.acceleration+=0.01
            self.slope+=1
            self.x += self.velocity*self.acceleration*math.cos(math.pi/180*(self.angle))
            self.y += self.velocity*self.acceleration*math.sin(math.pi/180*(self.angle))

    def draw(self):
        if self.collision == False : self.razer.clip_draw(0, 0, 15,15, self.x-0.7*(carpet.x-self.carpetX), self.y-0.7*(carpet.y-self.carpetY))
        else:
            for i in range(-1, len(enemy1RazerBox)-1):
                if self == enemy1RazerBox[i]:
                    del enemy1RazerBox[i]
                    break

#인질 클래스
class Hostage:
    global carpet
    global hostageList

    #king, queen, butler, knight, clergy, slave1, slave2 = None, None, None, None, None, None, None
    hostage_set = None
    hostageDie = None
    hostage_data = None
    KING, BUTLER, KNIGHT, CLERGY, SLAVE1, SLAVE2, QUEEN = 0, 1, 2, 3, 4, 5, 6
    SPAN_POSITION = 375
    GUARD_MAX, GUARD_MIN = 350, -350
    MAP_CENTER_X, MAP_CENTER_Y = 350, 350
    UP, DOWN, LEFT, RIGHT = 0, 1, 2, 3
    #왕과 왕비는 한 스테이지에 한 번밖에 등장하지 않는다.
    #스테이지가 바뀌면 아래 두 클래스 변수는 0으로 초기화된다.
    #supervise_hostage에서 관리한다.
    king_appearance, queen_appearance = 0, 0

    hostage_position = {
        KING : 'KING',
        BUTLER : 'BUTLER',
        KNIGHT : 'KNIGHT',
        CLERGY : 'CLERGY',
        SLAVE1 : 'SLAVE1' ,
        SLAVE2 : 'SLAVE2',
        QUEEN : 'QUEEN'
    }

    def __init__(self):
        if Hostage.hostage_set == None : Hostage.hostage_set = load_image('hostage/hostage_set.png')
        if Hostage.hostageDie == None : Hostage.hostageDie = load_image('hostage/hostage_die.png')
        if Hostage.hostage_data == None :
            hostage_data_file = open('hostage/hostage_data.txt', 'r')
            Hostage.hostage_data = json.load(hostage_data_file)
            hostage_data_file.close()

        self.frame = 0
        self.aniDelay = 0
        self.x = 0
        self.y = 0
        self.HP_buff = 0
        self.guardMax = Hostage.GUARD_MAX
        self.guardMin = Hostage.GUARD_MIN
        self.turnFlag=random.randint(0, 1)
        self.velocity = random.randint(1, 2)
        self.position = random.randint(0+Hostage.king_appearance,100-Hostage.queen_appearance)
        self.direct = random.randint(0,3)
        self.survive = True

        if self.direct == self.UP : self.y += Hostage.SPAN_POSITION
        elif self.direct == self.DOWN : self.y -= Hostage.SPAN_POSITION
        elif self.direct == self.LEFT : self.x -= Hostage.SPAN_POSITION
        elif self.direct == self.RIGHT : self.x += Hostage.SPAN_POSITION
        self.point = 0

        if -1 < self.position and self.position < 1:
            self.position = self.KING
            Hostage.king_appearance = 1
        elif 0 < self.position and self.position < 11 : self.position = self.BUTLER
        elif 10 < self.position and self.position < 17 : self.position = self.KNIGHT
        elif 16 < self.position and self.position < 21 : self.position = self.CLERGY
        elif 20 < self.position and self.position < 100 : self.position = random.randint(self.SLAVE1, self.SLAVE2)
        elif 99 < self.position and self.position < 101:
            self.position = self.QUEEN
            Hostage.queen_appearance = 1
        self.point = Hostage.hostage_data[self.hostage_position[self.position]]['point']
        self.HP_buff = Hostage.hostage_data[self.hostage_position[self.position]]['HP_buff']
        self.life = True
    def update(self):
        if self.survive == True:
            if self.direct == self.UP or self.direct == self.DOWN:
                if self.turnFlag == 1:
                    self.x += self.velocity
                    if self.x > self.guardMax:
                        self.x=self.guardMax
                        self.guardMin=random.randint(Hostage.GUARD_MIN, self.x)
                        self.turnFlag = 0
                elif self.turnFlag == 0:
                    self.x -= self.velocity
                    if self.x < self.guardMin:
                        self.x=self.guardMin
                        self.guardMax=random.randint(self.x, Hostage.GUARD_MAX)
                        self.turnFlag = 1

            elif self.direct  == self.LEFT or self.direct  == self.RIGHT:
                if self.turnFlag == 1:
                    self.y += self.velocity
                    if self.y > self.guardMax:
                        self.y=self.guardMax
                        self.guardMin=random.randint(Hostage.GUARD_MIN, self.y)
                        self.turnFlag = 0
                elif self.turnFlag == 0:
                    self.y -= self.velocity
                    if self.y < self.guardMin:
                        self.y=self.guardMin
                        self.guardMax=random.randint(self.y, Hostage.GUARD_MAX)
                        self.turnFlag = 1
        else : pass
    def draw(self):
        global hostage_num
        self.aniDelay +=1
        if self.survive == True:
            self.hostage_set.clip_draw(self.frame*40, self.position*40, 40,40, Hostage.MAP_CENTER_X+self.x-0.20*(carpet.x-Hostage.MAP_CENTER_X), Hostage.MAP_CENTER_Y+self.y-0.20*(carpet.y-Hostage.MAP_CENTER_Y))
            if self.aniDelay == 30 :
                self.frame = (self.frame+1)%2
                self.aniDelay=0
        elif self.survive == False:
            self.hostageDie.clip_draw(self.frame*40, 0, 40,40, Hostage.MAP_CENTER_X+self.x-0.20*(carpet.x-Hostage.MAP_CENTER_X), Hostage.MAP_CENTER_Y+self.y-0.20*(carpet.y-Hostage.MAP_CENTER_Y))
            if self.aniDelay == 10:
                self.frame = (self.frame+1)%12
                self.aniDelay = 0
                if self.frame == 0:
                    for i in range(-1, len(hostageList)-1):
                        if self == hostageList[i]:
                            del hostageList[i]
                            hostage_num-=1
                            break



#주인공의 스킬 속성 변화를 관리하는 함수
def supervise_bullet():
    global heroSkillBox
    global enemy2RazerBox
    global enemy2BombBox
    global ballRazerBox
    global enemy1
    global carpet
    global score
    global combo_flag
    global combo_score
    global combo_score_show_time
    global combo_score_degree

    #supervise skill1
    for i in range(-1, len(heroSkill1Box)-1):
        #if heroSkill1Box[i] in heroSkill1Box:
        if heroSkill1Box[i].direct == 'UP':
            if heroSkill1Box[i].y-0.7*(carpet.y-heroSkill1Box[i].carpetY) > 800-0.20*(carpet.y-350) : heroSkill1Box[i].collision = True
        elif heroSkill1Box[i].direct == 'DOWN':
            if heroSkill1Box[i].y-0.7*(carpet.y-heroSkill1Box[i].carpetY) < -100-0.20*(carpet.y-350) : heroSkill1Box[i].collision = True
        elif heroSkill1Box[i].direct == 'LEFT':
            if heroSkill1Box[i].x-0.7*(carpet.x-heroSkill1Box[i].carpetX) < -100-0.20*(carpet.x-350) : heroSkill1Box[i].collision = True
        elif heroSkill1Box[i].direct == 'RIGHT':
            if heroSkill1Box[i].x-0.7*(carpet.x-heroSkill1Box[i].carpetX) > 800-0.20*(carpet.x-350) : heroSkill1Box[i].collision = True

    # superbise_allSkill
    for i in range(-1, len(heroSkillBox)-1):
        for j in range(-1, len(heroSkillBox[i])-1):
            if heroSkillBox[i][j].collision == False:
                if enemy1.survive == True:
                    if enemy1.state != enemy1.ENEMY1_PATTERN1:
                        if ((enemy1.x-0.7*(carpet.x-350)-30 < heroSkillBox[i][j].x-0.7*(carpet.x-heroSkillBox[i][j].carpetX) and \
                            heroSkillBox[i][j].x-0.7*(carpet.x-heroSkillBox[i][j].carpetX) < enemy1.x-0.7*(carpet.x-350)+30 and \
                            enemy1.y-0.7*(carpet.y-350)+35 < heroSkillBox[i][j].y-0.7*(carpet.y-heroSkillBox[i][j].carpetY) and \
                            heroSkillBox[i][j].y-0.7*(carpet.y-heroSkillBox[i][j].carpetY) < enemy1.y-0.7*(carpet.y-350)+115) or \
                            (enemy1.x-0.7*(carpet.x-350)-35 < heroSkillBox[i][j].x-0.7*(carpet.x-heroSkillBox[i][j].carpetX) and \
                            heroSkillBox[i][j].x-0.7*(carpet.x-heroSkillBox[i][j].carpetX) < enemy1.x-0.7*(carpet.x-350)+35 and \
                            enemy1.y-0.7*(carpet.y-350)-35 < heroSkillBox[i][j].y-0.7*(carpet.y-heroSkillBox[i][j].carpetY) and \
                            heroSkillBox[i][j].y-0.7*(carpet.y-heroSkillBox[i][j].carpetY) < enemy1.y-0.7*(carpet.y-350)+35) or \
                            (enemy1.x-0.7*(carpet.x-350)-50 < heroSkillBox[i][j].x-0.7*(carpet.x-heroSkillBox[i][j].carpetX) and \
                            heroSkillBox[i][j].x-0.7*(carpet.x-heroSkillBox[i][j].carpetX) < enemy1.x-0.7*(carpet.x-350)+50 and \
                            enemy1.y-0.7*(carpet.y-350)-105 < heroSkillBox[i][j].y-0.7*(carpet.y-heroSkillBox[i][j].carpetY) and \
                            heroSkillBox[i][j].y-0.7*(carpet.y-heroSkillBox[i][j].carpetY) < enemy1.y-0.7*(carpet.y-350)-35)):
                            heroSkillBox[i][j].collision = True
                            enemy1.HP-=heroSkillBox[i][j].power
                            score += 1
                    else:
                        if 120 > distance(heroSkillBox[i][j].x-0.7*(carpet.x-heroSkillBox[i][j].carpetX), heroSkillBox[i][j].y-0.7*(carpet.y-heroSkillBox[i][j].carpetY),
                                          enemy1.x-0.7*(carpet.x-350), enemy1.y-0.7*(carpet.y-350)):
                            heroSkillBox[i][j].collision = True
                            enemy1.HP-=heroSkillBox[i][j].power
                            score += 1

    for i in range(-1, len(enemy1RazerBox)-1):
        if enemy1RazerBox[i].collision == False:
        #if ballRazerBox[i] in ballRazerBox:
            if enemy1RazerBox[i].y-0.7*(carpet.y-enemy1RazerBox[i].carpetY) > 800-0.20*(carpet.y-350) or \
                enemy1RazerBox[i].y-0.7*(carpet.y-enemy1RazerBox[i].carpetY) < -100-0.20*(carpet.y-350) or \
                enemy1RazerBox[i].x-0.7*(carpet.x-enemy1RazerBox[i].carpetX) < -100-0.20*(carpet.x-350) or \
                enemy1RazerBox[i].x-0.7*(carpet.x-enemy1RazerBox[i].carpetX) > 800-0.20*(carpet.x-350) :
                enemy1RazerBox[i].collision = True
            if 15 > distance(enemy1RazerBox[i].x-0.7*(carpet.x-enemy1RazerBox[i].carpetX), enemy1RazerBox[i].y-0.7*(carpet.y-enemy1RazerBox[i].carpetY), hero.x+carpet.x, hero.y+carpet.y) \
                    and hero.survive == True:
                hero.HP-=enemy1RazerBox[i].power
                enemy1RazerBox[i].collision = True
                #break
            for j in range(-1, len(hostageList)-1):
                if 15 > distance(350+hostageList[j].x-0.20*(carpet.x-350), 350+hostageList[j].y-0.20*(carpet.y-350), enemy1RazerBox[i].x-0.7*(carpet.x-enemy1RazerBox[i].carpetX), enemy1RazerBox[i].y-0.7*(carpet.y-enemy1RazerBox[i].carpetY) ) and \
                    hostageList[j].survive == True:
                    hostageList[j].survive = False
                    if combo_flag == True:
                        combo_flag = False
                        combo_score_show_time = 15
                        score += combo_score
                        combo_score_degree = combo_score
                        combo_score = 0
                    hostageList[j].frame = 0
                    hostageList[j].aniDelay = 0
# enemy1SickleWindList = []
# 인질의 속성 변화를 관리하는 함수
    for i in range(-1, len(enemy1SickleWindList)-1):
        if enemy1SickleWindList[i].collision == False:
        #if ballRazerBox[i] in ballRazerBox:
            if enemy1SickleWindList[i].y-0.7*(carpet.y-enemy1SickleWindList[i].carpetY) > 800-0.20*(carpet.y-350) or \
                enemy1SickleWindList[i].y-0.7*(carpet.y-enemy1SickleWindList[i].carpetY) < -100-0.20*(carpet.y-350) or \
                enemy1SickleWindList[i].x-0.7*(carpet.x-enemy1SickleWindList[i].carpetX) < -100-0.20*(carpet.x-350) or \
                enemy1SickleWindList[i].x-0.7*(carpet.x-enemy1SickleWindList[i].carpetX) > 800-0.20*(carpet.x-350) :
                enemy1SickleWindList[i].collision = True
            elif ((enemy1SickleWindList[i].x-0.7*(carpet.x-enemy1SickleWindList[i].carpetX)-40*(-1+2*enemy1SickleWindList[i].dir)-(1-enemy1SickleWindList[i].dir)*20 < carpet.x and \
                carpet.x < enemy1SickleWindList[i].x-0.7*(carpet.x-enemy1SickleWindList[i].carpetX)-20*(-1+2*enemy1SickleWindList[i].dir)+(1-enemy1SickleWindList[i].dir)*20 and \
                enemy1SickleWindList[i].y-0.7*(carpet.y-enemy1SickleWindList[i].carpetY)-50 < carpet.y and \
                carpet.y < enemy1SickleWindList[i].y-0.7*(carpet.y-enemy1SickleWindList[i].carpetY)+50) or \
                (enemy1SickleWindList[i].x-0.7*(carpet.x-enemy1SickleWindList[i].carpetX)-20*(-1+2*enemy1SickleWindList[i].dir)-(1-enemy1SickleWindList[i].dir)*40) < carpet.x and \
                carpet.x < enemy1SickleWindList[i].x-0.7*(carpet.x-enemy1SickleWindList[i].carpetX)+20*(-1+2*enemy1SickleWindList[i].dir)+(1-enemy1SickleWindList[i].dir)*40 and \
                enemy1SickleWindList[i].y-0.7*(carpet.y-enemy1SickleWindList[i].carpetY)-100 < carpet.y and \
                carpet.y < enemy1SickleWindList[i].y-0.7*(carpet.y-enemy1SickleWindList[i].carpetY)+100) or \
                (enemy1SickleWindList[i].x-0.7*(carpet.x-enemy1SickleWindList[i].carpetX)+20*(-1+2*enemy1SickleWindList[i].dir)-(1-enemy1SickleWindList[i].dir)*30 < carpet.x and \
                carpet.x < enemy1SickleWindList[i].x-0.7*(carpet.x-enemy1SickleWindList[i].carpetX)+50*(-1+2*enemy1SickleWindList[i].dir)+(1-enemy1SickleWindList[i].dir)*30 and \
                enemy1SickleWindList[i].y-0.7*(carpet.y-enemy1SickleWindList[i].carpetY)-170   < carpet.y and \
                carpet.y < enemy1SickleWindList[i].y-0.7*(carpet.y-enemy1SickleWindList[i].carpetY)+180):
                if hero.survive == True:
                    hero.HP-=enemy1SickleWindList[i].power
                    enemy1SickleWindList[i].collision = True
    for i in range(-1, len(enemy1SickleWindList)-1):
        if enemy1SickleWindList[i].collision == False:
            for j in range(-1, len(hostageList)-1):
                if hostageList[j].survive == True:
                    if ((enemy1SickleWindList[i].x-0.7*(carpet.x-enemy1SickleWindList[i].carpetX)-40*(-1+2*enemy1SickleWindList[i].dir)-(1-enemy1SickleWindList[i].dir)*20 < 350+hostageList[j].x-0.20*(carpet.x-350) and \
                        350+hostageList[j].x-0.20*(carpet.x-350) < enemy1SickleWindList[i].x-0.7*(carpet.x-enemy1SickleWindList[i].carpetX)-20*(-1+2*enemy1SickleWindList[i].dir)+(1-enemy1SickleWindList[i].dir)*20 and \
                        enemy1SickleWindList[i].y-0.7*(carpet.y-enemy1SickleWindList[i].carpetY)-50 < 350+hostageList[j].y-0.20*(carpet.y-350) and \
                        350+hostageList[j].y-0.20*(carpet.y-350) < enemy1SickleWindList[i].y-0.7*(carpet.y-enemy1SickleWindList[i].carpetY)+50) or \
                        (enemy1SickleWindList[i].x-0.7*(carpet.x-enemy1SickleWindList[i].carpetX)-20*(-1+2*enemy1SickleWindList[i].dir)-(1-enemy1SickleWindList[i].dir)*40) < 350+hostageList[j].x-0.20*(carpet.x-350) and \
                        350+hostageList[j].x-0.20*(carpet.x-350) < enemy1SickleWindList[i].x-0.7*(carpet.x-enemy1SickleWindList[i].carpetX)+20*(-1+2*enemy1SickleWindList[i].dir)+(1-enemy1SickleWindList[i].dir)*40 and \
                        enemy1SickleWindList[i].y-0.7*(carpet.y-enemy1SickleWindList[i].carpetY)-100 < 350+hostageList[j].y-0.20*(carpet.y-350) and \
                        350+hostageList[j].y-0.20*(carpet.y-350) < enemy1SickleWindList[i].y-0.7*(carpet.y-enemy1SickleWindList[i].carpetY)+100) or \
                        (enemy1SickleWindList[i].x-0.7*(carpet.x-enemy1SickleWindList[i].carpetX)+20*(-1+2*enemy1SickleWindList[i].dir)-(1-enemy1SickleWindList[i].dir)*30 < 350+hostageList[j].x-0.20*(carpet.x-350) and \
                        350+hostageList[j].x-0.20*(carpet.x-350) < enemy1SickleWindList[i].x-0.7*(carpet.x-enemy1SickleWindList[i].carpetX)+50*(-1+2*enemy1SickleWindList[i].dir)+(1-enemy1SickleWindList[i].dir)*30 and \
                        enemy1SickleWindList[i].y-0.7*(carpet.y-enemy1SickleWindList[i].carpetY)-170   < 350+hostageList[j].y-0.20*(carpet.y-350) and \
                        350+hostageList[j].y-0.20*(carpet.y-350) < enemy1SickleWindList[i].y-0.7*(carpet.y-enemy1SickleWindList[i].carpetY)+180):
                        hostageList[j].survive = False
                        if combo_flag == True:
                            combo_flag = False
                            combo_score_show_time = 15
                            score += combo_score
                            combo_score_degree = combo_score
                            combo_score = 0
                        hostageList[j].frame = 0
                        hostageList[j].aniDelay = 0

    if enemy1.state == enemy1.ENEMY1_PATTERN1:
        if enemy1.survive == True:
            if 120 > distance(carpet.x, carpet.y, enemy1.x-0.7*(carpet.x-350), enemy1.y-0.7*(carpet.y-350) ) :
                if hero.survive == True and hero.collision == False:
                    hero.HP-=enemy1.power
                    hero.collision = True
            for i in range(-1, len(hostageList)-1):
                if hostageList[i].survive == True:
                    if 120 > distance(350+hostageList[i].x-0.20*(carpet.x-350), 350+hostageList[i].y-0.20*(carpet.y-350),enemy1.x-0.7*(carpet.x-350), enemy1.y-0.7*(carpet.y-350) ) :
                        hostageList[i].survive = False
                        if combo_flag == True:
                            combo_flag = False
                            combo_score_show_time = 15
                            score += combo_score
                            combo_score_degree = combo_score
                            combo_score = 0
                        hostageList[i].frame = 0
                        hostageList[i].aniDelay = 0

    if enemy1.state == enemy1.ENEMY1_PATTERN3:
        if enemy1.survive == True:
            if enemy1.x-0.7*(carpet.x-350)-150*(-1+2*(1-enemy1.ThisIsRight(carpet.x)))-(1-(1-enemy1.ThisIsRight(carpet.x)))*150  < carpet.x and \
                carpet.x < enemy1.x-0.7*(carpet.x-350)+(1-(1-enemy1.ThisIsRight(carpet.x)))*150 and \
                enemy1.y-0.7*(carpet.y-350)-175 < carpet.y and carpet.y < enemy1.y-0.7*(carpet.y-350)+175:
                if hero.survive == True and hero.collision == False and enemy1.frame == 4:
                    hero.HP-=enemy1.power
                    hero.collision = True

def supervise_hostage():
    global hostageList
    global delay_create_hostage
    global carpet
    global hostage_num
    global king_state
    global queen_state
    global save_num
    global HP_buff_show_time
    global HP_buff_degree
    global score
    global combo_flag
    global combo_score
    global point_show_time
    global point_degree

    #도망치는 사람 생성을 관리한다.
    if hostage_num < 20:
        delay_create_hostage+=1
        if delay_create_hostage ==200:
            hostageList.append(Hostage())
            hostage_num+=1
            delay_create_hostage = 0
    #도망치는 사람이 구출됐을 경우
    for i in range(-1, len(hostageList)-1):
        if 80 > distance(350+hostageList[i].x-0.20*(carpet.x-350), 350+hostageList[i].y-0.20*(carpet.y-350), carpet.x, carpet.y ) and \
                hostageList[i].survive == True and hero.survive == True and enemy1.survive == True:
            if hostageList[i].position == hostageList[i].KING  :
                king_state = 'SAVE'
            elif hostageList[i].position == hostageList[i].QUEEN :
                queen_state = 'SAVE'
            if hero.HP < 100 : hero.HP += hostageList[i].HP_buff
            if hero.HP >= 100 : hero.HP = 100
            HP_buff_degree = hostageList[i].HP_buff
            score += hostageList[i].point
            point_degree = hostageList[i].point
            HP_buff_show_time = 15
            point_show_time = 15
            combo_flag = True
            combo_score+=10
            del hostageList[i]
            hostage_num-=1
            save_num+=1
            break

def handle_events(): #플래그에 한 순간 영향받는 변수 처리
    global running
    global carpet
    global hero

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_ESCAPE: running = False
            # 마법 타입이 바뀔 수 있는 유일한 부분.l
            if event.key == SDLK_LSHIFT or event.key == SDLK_RSHIFT:
                hero.skill1Delay = 0
                hero.skill2Delay = 0
                if hero.skillType == 'SKILL1' : hero.skillType = 'SKILL2'
                elif hero.skillType == 'SKILL2' : hero.skillType = 'SKILL3'
                elif hero.skillType == 'SKILL3' : hero.skillType = 'SKILL1'
            if event.key == SDLK_d: carpet.goToRight = True
            if event.key == SDLK_a: carpet.goToLeft = True
            if event.key == SDLK_w: carpet.goToUp = True
            if event.key == SDLK_s: carpet.goToDown = True
            # 주인공의 공격 방향 설정 및 공격을 수행한다.
            if event.key == SDLK_i or event.key == SDLK_k or event.key ==SDLK_j or event.key == SDLK_l:
                if event.key == SDLK_i : hero.attackDirect = 'UP'
                if event.key == SDLK_k : hero.attackDirect = 'DOWN'
                if event.key == SDLK_j : hero.attackDirect = 'LEFT'
                if event.key == SDLK_l : hero.attackDirect = 'RIGHT'
                # hero.state는 공격 모션, 마법 탄환 생성에 영향을 준다.
                hero.state = 'ATTACK'
                hero.delay = 0
                hero.frame = 0
            if event.key == SDLK_SPACE :
                if enemy1.delete == True:
                    game_framework.change_state(stage2_gap)
                elif hero.delete == True:
                    game_framework.change_state(stage1_gap)
        elif event.type == SDL_KEYUP:
            if event.key == SDLK_d: carpet.goToRight = False
            if event.key == SDLK_a: carpet.goToLeft = False
            if event.key == SDLK_w: carpet.goToUp = False
            if event.key == SDLK_s: carpet.goToDown = False
            if event.key == SDLK_i or event.key == SDLK_k or event.key ==SDLK_j or event.key == SDLK_l:
                hero.attackDirect = 'DEFAULT'
                hero.state = 'NORMAL'
                hero.skill1Delay = 0
                hero.attackAniFlag = 0
                hero.delay = 0
                hero.frame = 0
            pass
        #공격 키 간에 동기화가 필요해보인다.

#UI 관련 클래스
ui = None
score = 0
combo_flag = False
combo_score = 0
combo_score_show_time = 0
combo_score_degree = 0
ultra_score = 5000
ultra_score_show_time = 0
kq_all_rescue_flag = False
font = None
#맵 관련 클래스
map = None

#주인공 관련 클래스
hero = None                       #주인공 인스턴스
#양탄자 관련 클래스
carpet = None

#enemy1 클래스
enemy1 = None
enemy1SickleWindList = []
enemy1RazerBox = []

#인질 리스트
hostageList=[]
delay_create_hostage = 0
hostage_num = 0
save_num = 0
HP_buff_show_time = 0
HP_buff_degree = 0
point_show_time = 0
point_degree = 0
king_state = 'NOT'
queen_state = 'NOT'


#running = True;

#리팩토링
def enter():

    global map
    global ui
    global hero
    global carpet
    global enemy1

    global score
    global combo_flag
    global combo_score
    global combo_score_show_time
    global combo_score_degree
    global ultra_score
    global ultra_score_show_time
    global kq_all_rescue_flag
    global font

    global delay_create_hostage
    global hostage_num
    global save_num
    global HP_buff_show_time
    global HP_buff_degree
    global point_show_time
    global point_degree
    global king_state
    global queen_state


    map = Map()
    ui = UI()
    hero = Hero()
    carpet = Carpet()
    enemy1 = Enemy1()

    score = 0
    combo_flag = False
    combo_score = 0
    combo_score_show_time = 0
    combo_score_degree = 0
    ultra_score = 5000
    ultra_score_show_time = 0
    kq_all_rescue_flag = False
    font = load_font('ENCR10B.TTF')

    delay_create_hostage = 0
    hostage_num = 0
    save_num = 0
    HP_buff_show_time = 0
    HP_buff_degree = 0
    point_show_time = 0
    point_degree = 0
    king_state = 'NOT'
    queen_state = 'NOT'

def exit():
    global map
    global ui
    global hero
    global carpet
    global enemy1
    global font

    global heroSkill1Box
    global heroSkill2Box
    global heroSkill3Box
    global heroSkillBox

    global hostageList

    while(len(heroSkill1Box)):
        del heroSkill1Box[0]
    while(len(heroSkill2Box)):
        del heroSkill2Box[0]
    while(len(heroSkill3Box)):
        del heroSkill3Box[0]

    while(len(enemy1SickleWindList)):
         del enemy1SickleWindList[0]
    while(len(enemy1RazerBox)):
        del enemy1RazerBox[0]

    while(len(hostageList)):
        del hostageList[0]

    del(map)
    del(ui)
    del(hero)
    del(carpet)
    del (enemy1)
    del (font)


def update():
    ui.update()
    carpet.update()
    hero.update(carpet)
    enemy1.update()
    for sickleWind in enemy1SickleWindList:
        sickleWind.update()
    for skill1 in heroSkill1Box:
        skill1.update()
    for skill3 in heroSkill3Box:
        skill3.update()
    for razer in enemy1RazerBox:
        razer.update()
    for hostage in hostageList:
        hostage.update()
    supervise_bullet()
    supervise_hostage()

    #delay(0.005)


def draw():

    global carpet
    clear_canvas()
    map.draw(carpet)
    carpet.draw()
    hero.draw(carpet)
    for hostage in hostageList:
        hostage.draw()
    for razer in enemy1RazerBox:
        razer.draw()
    enemy1.draw(carpet.x)
    for sickleWind in enemy1SickleWindList:
        sickleWind.draw(carpet.x, carpet.y)
    for skill1 in heroSkill1Box:
        skill1.draw(heroSkill1Box, carpet)
    for skill2 in heroSkill2Box:
        skill2.draw()
    for skill3 in heroSkill3Box:
        skill3.draw()

    ui.draw()

    update_canvas()


