import game_framework
import math
import random
from pico2d import *



#주인공의 공격 상태
enumerate(['NORAML', 'ATTACK' ])
#주인공의 공격 방향
enumerate(['DEFAULT','LEFT, RIGHT, UP, DOWN'])
#주인공의 공격 타입
enumerate(['SKILL1, SKILL2, SKILL3'])
#인질들의 계급
#enumerate(['KING', 'QUEEN', 'BUTLER', 'KNIGHT', 'SLAVE'])

#UI 클래스
class UI:
    def __init__(self):
        self.UITitle = load_image('UI/UITitle.png')
    def update(self):
        pass
    def draw(self):
        self.UITitle.draw(450, 350)
#맵 클래스 : carpet의 움직임에 종속적
class Map:
    global carpet
    def __init__(self):
        #self.mapCast = load_image('map/mapCast2.png')
        self.baseMap = load_image('map/baseMap.png')
        self.map1 = load_image('map/simpleMap1.png')
        self.map2 = load_image('map/simpleMap2.png')
        self.map3 = load_image('map/simpleMap3.png')
        self.map4 = load_image('map/simpleMap4.png')
        self.map5 = load_image('map/simpleMap5.png')
    def draw(self):
        self.baseMap.draw(450, 350)
        self.map1.draw(450-0.5*(carpet.x-350), 350-0.5*(carpet.y-350))
        self.map2.draw(450-0.25*(carpet.x-350), 350-0.25*(carpet.y-350))
        self.map3.draw(450-0.125*(carpet.x-350), 350-0.125*(carpet.y-350))
        self.map4.draw(450-0.0625*(carpet.x-350), 350-0.0625*(carpet.y-350))
        self.map5.draw(350-0.20*(carpet.x-350), 350-0.20*(carpet.y-350))
        #self.mapCast.draw(450, 350)
    pass


#주인공 클래스 : carpet 클래스와 cootTime 변수에 종속적
#속성값 : 주인공 위치 좌표, 현재 상태(기본, 공격), 공격 방향, 공격 타입
class Hero:
    global carpet
    global heroSkill1Box
    global heroSkill2Box

    def __init__(self): #속성 초기화
        self.x = 0
        self.y = 0
        self.state = 'NORMAL'
        self.attackDirect = 'DEFAULT'
        self.skillType = 'SKILL1'
        self.hero = load_image('mainchar.png')
        self.attack = load_image('mainchar_attack.png')
        self.attackAniFlag = 0
        self.frame = 0
        self.delay = 0
        self.skill1Delay = 0
        self.skill2Delay = 0
    def update(self): #게임 로직
        #주인공이 공격 상태라면 탄환을 생성한다.
        if self.state == 'ATTACK':
            if self.skillType == 'SKILL1':
                self.skill1Delay+=1
                if self.skill1Delay == 5:
                    heroSkill1Box.append(Skill1())
                    self.skill1Delay = 0
                #for i in range(0, 100):
                #    if True == i not in heroSkill1Box:
                #        heroSkill1Box[i]= Skill1()
                #        break
            elif self.skillType == 'SKILL2':
                self.skill2Delay+=1
                if self.skill2Delay == 35:
                    heroSkill2Box.append(Skill2())
                    self.skill2Delay = 0
            elif self.skillType == 'SKILL3':
                pass


    def draw(self): #게임 렌더링
        self.delay+=1
        if self.state == 'NORMAL': #아무런 입력이 없을 경우
            self.hero.clip_draw(self.frame*40, 0, 40,40, self.x+carpet.x, self.y+carpet.y)
            if self.delay == 10:
                self.frame = (self.frame+1) % 2
                self.delay = 0
        elif self.state == 'ATTACK': #스페이스키를 눌러 공격 형태가 됐을 경우
            if self.attackAniFlag == 0:
                self.attack.clip_draw(self.frame*40, 40, 40,40,self.x+carpet.x, self.y+carpet.y)
                if self.delay == 4:
                    self.frame = (self.frame+1) % 8
                    self.delay = 0
                    if self.frame == 0:
                        self.attackAniFlag = 1-self.attackAniFlag
            else:
                self.attack.clip_draw(self.frame*40, 0, 40,40, self.x+carpet.x, self.y+carpet.y)
                if self.delay == 4:
                    self.frame = (self.frame+1)%8
                    self.delay =0
                    #if self.frame == 0:
                    #    self.attackAniFlag = 1-self.attackAniFlag
            pass

def angle(startX,startY,directX, directY):
    axisDegree = (180.0 / math.pi)*math.atan2(0.0, 1.0)
    if axisDegree < 0: axisDegree += 360
    moveDegree = (180.0 / math.pi)*math.atan2((directY - startY), (directX - startX))
    if moveDegree < 0: moveDegree += 360
    return moveDegree - axisDegree
#주인공 마법 타입1 클래스 : 주인공 클래스에 종속적
#속성값 : 마법 초기 생성 위치, 마법 진행 방향, 마법 진행 방향각, 마법 이동 속도
#전제 : Skill1 인스턴스는 hero 내에서 생성된다. (hero.state == 'ATTACK' 상태 )
class Skill1:
    global hero
    global carpet
    global heroSkill1Box

    skill1 = None

    def __init__(self):
        if Skill1.skill1 == None:
            Skill1.skill1 = load_image('heroSkill/skill1.png')
        #마법은 주인공 기준으로 생성된다.
        self.x = hero.x+carpet.x
        self.y = hero.y+carpet.y
        self.angle = 0.0
        self.frame = 0
        self.collision = False
        self.aniDelay = 0
        #마법 탄환 초기 생성 위치 초기화
        if hero.attackDirect=='UP':
            self.y += 30
            self.angle = angle(self.x, self.y, self.x+random.randint(-40, 40), self.y+500)
        elif hero.attackDirect == 'DOWN':
            self.y -= 30
            self.angle = angle(self.x, self.y, self.x+random.randint(-40, 40), self.y-500)
        elif hero.attackDirect == 'LEFT':
            self.x -= 30
            self.angle = angle(self.x, self.y, self.x-500, self.y+random.randint(-40, 40))
        elif hero.attackDirect == 'RIGHT':
            self.x += 30
            self.angle = angle(self.x, self.y, self.x+500, self.y+random.randint(-40, 40))
        self.direct = hero.attackDirect
        self.velocity = random.randint(20,21)
    def update(self):
        if self.collision == False:
            self.x += self.velocity*math.cos(math.pi/180*self.angle)
            self.y += self.velocity*math.sin(math.pi/180*self.angle)
    def draw(self):
        if self.collision == False : self.skill1.clip_draw(0,0, 30, 30, self.x, self.y)
        else:
            self.aniDelay+=1
            self.skill1.clip_draw(self.frame*30, 0, 30, 30,self.x, self.y)
            if self.aniDelay == 3:
                self.frame = (self.frame+1)%8
                self.aniDelay = 0
                if self.frame == 0:
                    for i in range(-1, len(heroSkill1Box)-1):
                        if self == heroSkill1Box[i]:
                            del heroSkill1Box[i]

class Skill2:
    global hero
    global carpet
    global heroSkill2Box

    skill2_1LR, skill2_2LR, skill2_1UD, skill2_2UD = None, None, None, None

    def __init__(self):
        if Skill2.skill2_1LR == None:
            Skill2.skill2_1LR = load_image('heroSkill/skill2_1LR.png')
        if Skill2.skill2_2LR == None:
            Skill2.skill2_2LR = load_image('heroSkill/skill2_2LR.png')
        if Skill2.skill2_1UD == None:
            Skill2.skill2_1UD = load_image('heroSkill/skill2_1UD.png')
        if Skill2.skill2_2UD == None:
            Skill2.skill2_2UD = load_image('heroSkill/skill2_2UD.png')
        #마법은 주인공 기준으로 생성된다.
        self.x = hero.x+carpet.x
        self.y = hero.y+carpet.y
        self.frame = 0
        self.aniFlag = random.randint(0,1)
        self.aniDelay = 0
        self.direct = hero.attackDirect
        #마법 탄환 초기 생성 위치 초기화
        if hero.attackDirect=='UP':
            self.y += 430
        elif hero.attackDirect == 'DOWN':
            self.y -= 430
        elif hero.attackDirect == 'LEFT':
            self.x -= 430
        elif hero.attackDirect == 'RIGHT':
            self.x += 430

    def update(self):
        pass
    def draw(self):
        self.aniDelay+=1
        if self.direct == 'RIGHT' or self.direct == 'LEFT':
            if self.aniFlag == 0:
                self.skill2_1LR.clip_draw(0, 360-self.frame*60, 800,60, self.x, self.y)
                if self.aniDelay == 3:
                    self.frame = (self.frame+1)%7
                    self.aniDelay=0
                    if self.frame == 0:
                        for i in range(-1, len(heroSkill2Box)-1):
                                if self == heroSkill2Box[i]:
                                    del heroSkill2Box[i]
            else:
                self.skill2_2LR.clip_draw(0, 360-self.frame*60, 800,60, self.x, self.y)
                if self.aniDelay == 3:
                    self.frame = (self.frame+1)%7
                    self.aniDelay=0
                    if self.frame == 0:
                        for i in range(-1, len(heroSkill2Box)-1):
                                if self == heroSkill2Box[i]:
                                    del heroSkill2Box[i]
        elif self.direct == 'UP' or self.direct == 'DOWN':
            if self.aniFlag == 0:
                self.skill2_1UD.clip_draw(self.frame*60, 0, 60,800, self.x, self.y)
                if self.aniDelay == 3:
                    self.frame = (self.frame+1)%7
                    self.aniDelay=0
                    if self.frame == 0:
                        for i in range(-1, len(heroSkill2Box)-1):
                                if self == heroSkill2Box[i]:
                                    del heroSkill2Box[i]
            else:
                self.skill2_2UD.clip_draw(self.frame*60, 0, 60,800, self.x, self.y)
                if self.aniDelay == 3:
                    self.frame = (self.frame+1)%7
                    self.aniDelay=0
                    if self.frame == 0:
                        for i in range(-1, len(heroSkill2Box)-1):
                                if self == heroSkill2Box[i]:
                                    del heroSkill2Box[i]

#양탄자 클래스 : 이동방향 플래그 변수에 종속적
#속성값 : 양탄자 위치
class Carpet:
    goToRight, goToLeft, goToUp, goToDown = False, False, False, False
    def __init__(self):
        self.x = 350
        self.y = 350
        self.carpet = load_image('carpet.png')

    def update(self):
        if self.goToRight == True:
            if self.x+50 > 650 : self.x -= 2
            else: self.x += 2
        if self.goToLeft == True:
            if self.x-50 < 50 : self.x += 2
            else: self.x -= 2
        if self.goToUp == True:
            if self.y+50 > 650 : self.y -=2
            else: self.y += 2
        if self.goToDown == True:
            if self.y-50 < 50 : self.y +=2
            else: self.y -= 2
    def draw(self):
        self.carpet.draw(self.x, self.y)
    pass

#인질 클래스
class Hostage:
    global carpet
    king, queen, butler, knight, clergy, slave1, slave2 = None, None, None, None, None, None, None
    KING, BUTLER, KNIGHT, CLERGY, SLAVE1, SLAVE2, QUEEN = 0, 1, 2, 3, 4, 5, 6
    UP, DOWN, LEFT, RIGHT = 0, 1, 2, 3
    #왕과 왕비는 한 스테이지에 한 번밖에 등장하지 않는다.
    #스테이지가 바뀌면 아래 두 클래스 변수는 0으로 초기화된다.
    #supervise_hostage에서 관리한다.
    king_appearance, queen_appearance = 0, 0
    def __init__(self):
        self.frame = 0
        self.aniDelay = 0
        self.assign_position = 0
        self.x = 0
        self.y = 0
        self.guardMax=350
        self.guardMin=-350
        self.turnFlag=random.randint(0, 1)
        self.velocity = random.randint(1, 2)
        if Hostage.king == None:
            Hostage.king = load_image('hostage/king.png')
        if Hostage.queen == None:
            Hostage.queen = load_image('hostage/queen.png')
        if Hostage.butler == None:
            Hostage.butler = load_image('hostage/butler.png')
        if Hostage.knight == None:
            Hostage.knight = load_image('hostage/knight.png')
        if Hostage.clergy == None:
            Hostage.clergy = load_image('hostage/clergy.png')
        if Hostage.slave1 == None:
            Hostage.slave1 = load_image('hostage/slave1.png')
        if Hostage.slave2 == None:
            Hostage.slave2 = load_image('hostage/slave2.png')

        self.assign_position = random.randint(0+Hostage.king_appearance,100-Hostage.queen_appearance)
        self.direct = random.randint(0,3)

        if self.direct == self.UP:
            self.y += 375
        elif self.direct == self.DOWN:
            self.y -= 375
        elif self.direct == self.LEFT:
            self.x -= 375
        elif self.direct == self.RIGHT:
            self.x += 375
        self.point = 0

        if -1 < self.assign_position and self.assign_position < 1:
            self.position = self.KING
            Hostage.king_appearance = 1
            self.point = 15000
        elif 0 < self.assign_position and self.assign_position < 11:
            self.position = self.BUTLER
            self.point = 500
        elif 10 < self.assign_position and self.assign_position < 17:
            self.position = self.KNIGHT
            self.point = 1000
        elif 16 < self.assign_position and self.assign_position < 21:
            self.position = self.CLERGY
            self.point = 1200
        elif 20 < self.assign_position and self.assign_position < 100:
            self.position = random.randint(self.SLAVE1, self.SLAVE2)
            self.point = 100
        elif 99 < self.assign_position and self.assign_position < 101:
            self.position = self.QUEEN
            Hostage.queen_appearance = 1
            self.point = 10000

        self.life = True

    def update(self):
        if self.direct == self.UP or self.direct == self.DOWN:
            if self.turnFlag == 1:
                self.x += self.velocity
                if self.x > self.guardMax:
                    self.x=self.guardMax
                    self.guardMin=random.randint(-350, self.x)
                    self.turnFlag = 0
            elif self.turnFlag == 0:
                self.x -= self.velocity
                if self.x < self.guardMin:
                    self.x=self.guardMin
                    self.guardMax=random.randint(self.x, 350)
                    self.turnFlag = 1

        elif self.direct  == self.LEFT or self.direct  == self.RIGHT:
            if self.turnFlag == 1:
                self.y += self.velocity
                if self.y > self.guardMax:
                    self.y=self.guardMax
                    self.guardMin=random.randint(-350, self.y)
                    self.turnFlag = 0
            elif self.turnFlag == 0:
                self.y -= self.velocity
                if self.y < self.guardMin:
                    self.y=self.guardMin
                    self.guardMax=random.randint(self.y, 350)
                    self.turnFlag = 1
    def draw(self):
        self.aniDelay +=1
        if self.position == self.KING:
            self.king.clip_draw(self.frame*40, 0, 40,40, 350+self.x-0.20*(carpet.x-350), 350+self.y-0.20*(carpet.y-350))
        elif self.position == self.QUEEN:
            self.queen.clip_draw(self.frame*40, 0, 40,40, 350+self.x-0.20*(carpet.x-350), 350+self.y-0.20*(carpet.y-350))
        elif self.position == self.CLERGY:
            self.clergy.clip_draw(self.frame*40, 0, 40,40, 350+self.x-0.20*(carpet.x-350), 350+self.y-0.20*(carpet.y-350))
        elif self.position == self.KNIGHT:
            self.knight.clip_draw(self.frame*40, 0, 40,40, 350+self.x-0.20*(carpet.x-350), 350+self.y-0.20*(carpet.y-350))
        elif self.position == self.BUTLER:
            self.butler.clip_draw(self.frame*40, 0, 40,40, 350+self.x-0.20*(carpet.x-350), 350+self.y-0.20*(carpet.y-350))
        elif self.position == self.SLAVE1:
            self.slave1.clip_draw(self.frame*40, 0, 40,40, 350+self.x-0.20*(carpet.x-350), 350+self.y-0.20*(carpet.y-350))
        elif self.position == self.SLAVE2:
            self.slave2.clip_draw(self.frame*40, 0, 40,40, 350+self.x-0.20*(carpet.x-350), 350+self.y-0.20*(carpet.y-350))
        if self.aniDelay == 30 :
            self.frame = (self.frame+1)%2
            self.aniDelay=0

#주인공의 스킬 속성 변화를 관리하는 함수
def supervise_skill():
    global heroSkill1Box
    global carpet

    #supervise skill1
    for i in range(-1, len(heroSkill1Box)-1):
        if heroSkill1Box[i] in heroSkill1Box:
            if heroSkill1Box[i].direct == 'UP':
                if heroSkill1Box[i].y > 750-0.20*(carpet.y-350) : heroSkill1Box[i].collision = True
            elif heroSkill1Box[i].direct == 'DOWN':
                if heroSkill1Box[i].y < -50-0.20*(carpet.y-350) : heroSkill1Box[i].collision = True
            elif heroSkill1Box[i].direct == 'LEFT':
                if heroSkill1Box[i].x < -50-0.20*(carpet.x-350) : heroSkill1Box[i].collision = True
            elif heroSkill1Box[i].direct == 'RIGHT':
                if heroSkill1Box[i].x > 750-0.20*(carpet.x-350) : heroSkill1Box[i].collision = True

#인질의 속성 변화를 관리하는 함수
def distance(v1X,v1Y,  v2X, v2Y):
    return math.sqrt((v1X-v2X)*(v1X-v2X)+ (v1Y-v2Y)*(v1Y-v2Y))

def supervise_hostage():
    global hostageList
    global delay_create_hostage
    global carpet

    delay_create_hostage+=1
    if delay_create_hostage == 500:
        hostageList.append(Hostage())
        delay_create_hostage = 0

    for i in range(-1, len(hostageList)-1):
        if 80 > distance(350+hostageList[i].x-0.20*(carpet.x-350), 350+hostageList[i].y-0.20*(carpet.y-350), carpet.x, carpet.y ):
            del hostageList[i]

def handle_events(): #플래그에 한 순간 영향받는 변수 처리
    global running
    global carpet
    global hero

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_ESCAPE: running = False
            # 마법 타입이 바뀔 수 있는 유일한 부분.l
            if event.key == SDLK_LSHIFT or event.key == SDLK_RSHIFT:
                hero.skill1Delay = 0
                hero.skill2Delay = 0
                if hero.skillType == 'SKILL1' : hero.skillType = 'SKILL2'
                elif hero.skillType == 'SKILL2' : hero.skillType = 'SKILL1'
                #elif hero.skillType == 'SKILL3' : hero.skillType == 'SKILL1'
                pass
            if event.key == SDLK_d: carpet.goToRight = True
            if event.key == SDLK_a: carpet.goToLeft = True
            if event.key == SDLK_w: carpet.goToUp = True
            if event.key == SDLK_s: carpet.goToDown = True
            # 주인공의 공격 방향 설정 및 공격을 수행한다.
            if event.key == SDLK_i or event.key == SDLK_k or event.key ==SDLK_j or event.key == SDLK_l:
                if event.key == SDLK_i : hero.attackDirect = 'UP'
                if event.key == SDLK_k : hero.attackDirect = 'DOWN'
                if event.key == SDLK_j : hero.attackDirect = 'LEFT'
                if event.key == SDLK_l : hero.attackDirect = 'RIGHT'
                # hero.state는 공격 모션, 마법 탄환 생성에 영향을 준다.
                hero.state = 'ATTACK'
                hero.delay = 0
                hero.frame = 0

        elif event.type == SDL_KEYUP:
            if event.key == SDLK_d: carpet.goToRight = False
            if event.key == SDLK_a: carpet.goToLeft = False
            if event.key == SDLK_w: carpet.goToUp = False
            if event.key == SDLK_s: carpet.goToDown = False
            if event.key == SDLK_i or event.key == SDLK_k or event.key ==SDLK_j or event.key == SDLK_l:
                hero.attackDirect = 'DEFAULT'
                hero.state = 'NORMAL'
                hero.skill1Delay = 0
                hero.attackAniFlag = 0
                hero.delay = 0
                hero.frame = 0
            pass
        #공격 키 간에 동기화가 필요해보인다.

#UI 관련 클래스
ui=None

#맵 관련 클래스
map = None

#주인공 관련 클래스
hero = None                       #주인공 인스턴스
heroSkill1Box=[]                    #주인공 skill1 타입 마법 관리 리스트
heroSkill2Box=[]                    #주인공 skill2 타입 마법 관리 리스트

#양탄자 관련 클래스
carpet = None

#인질 리스트
hostageList=[]
delay_create_hostage = 0

#running = True;

#리팩토링
def enter():
    global map
    global ui
    global hero
    global carpet
    map = Map()
    ui = UI()
    hero = Hero()
    carpet = Carpet()

def exit():
    global map
    global ui
    global hero
    global carpet
    del(map)
    del(ui)
    del(hero)
    del(carpet)

def update():
    carpet.update()
    hero.update()
    for skill1 in heroSkill1Box:
         skill1.update()
    for hostage in hostageList:
        hostage.update()
    supervise_skill()
    supervise_hostage()
    #supervise_hostage()


def draw():
    clear_canvas()
    map.draw()
    carpet.draw()
    hero.draw()
    for hostage in hostageList:
        hostage.draw()
    for skill1 in heroSkill1Box:
        skill1.draw()
    for skill2 in heroSkill2Box:
        skill2.draw()

    #for hostage in hostageList:
    #    hostageList.draw()
    ui.draw()
    update_canvas()


