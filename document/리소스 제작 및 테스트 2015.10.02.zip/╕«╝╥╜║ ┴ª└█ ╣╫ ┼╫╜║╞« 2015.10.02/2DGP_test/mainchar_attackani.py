
from pico2d import *
open_canvas(40,40)
mainchar=load_image('mainchar_attack.png')

x=0
frame = 0
fFlag = 0
while (x<100):
    clear_canvas()
    if fFlag == 0:
        mainchar.clip_draw(frame*40, 40, 40,40, 20,20)
        frame = (frame+1)%8
        if frame == 0:
            fFlag = 1-fFlag
    else:
        mainchar.clip_draw(frame*40, 0, 40,40, 20,20)
        frame = (frame+1)%2
        if frame == 0:
            fFlag = 1-fFlag
    update_canvas()

    x+=1
    delay(0.08)
    get_events()

close_canvas()