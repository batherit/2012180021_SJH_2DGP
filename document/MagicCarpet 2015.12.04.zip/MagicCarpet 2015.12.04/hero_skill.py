from pico2d import *
import random
from stage1 import *
from hero import *

#주인공 마법 타입1 클래스 : 주인공 클래스에 종속적
#속성값 : 마법 초기 생성 위치, 마법 진행 방향, 마법 진행 방향각, 마법 이동 속도
#전제 : Skill1 인스턴스는 hero 내에서 생성된다. (hero.state == 'ATTACK' 상태 )
class Skill1:

    SPAN_POSITION = 30


    skill1 = None
    boom_sound = None
    angle_about_direct = { 'UP' : 90, 'DOWN' : 270, 'LEFT' : 180, 'RIGHT' : 0}

    def __init__(self, hero,carpet):
        if Skill1.boom_sound == None:
            Skill1.boom_sound = load_wav('sound/hero_skill/hero_skill1boom.ogg')
            Skill1.boom_sound.set_volume(32)
        if Skill1.skill1 == None:Skill1.skill1 = load_image('hero/heroSkill/skill1.png')
        #마법은 주인공 기준으로 생성된다.
        self.x = hero.x+carpet.x #변경 hero.x+carpet.x
        self.y = hero.y+carpet.y #변경 ''
        self.angle = 0.0
        self.frame = 0
        self.collision = False
        self.aniDelay = 0
        self.carpetX = carpet.x
        self.carpetY = carpet.y
        self.power = 2
        #마법 탄환 초기 생성 위치 초기화
        if hero.attackDirect=='UP': self.y += Skill1.SPAN_POSITION
        elif hero.attackDirect == 'DOWN': self.y -= Skill1.SPAN_POSITION
        elif hero.attackDirect == 'LEFT': self.x -= Skill1.SPAN_POSITION
        elif hero.attackDirect == 'RIGHT': self.x += Skill1.SPAN_POSITION
        self.angle = self.angle_about_direct[hero.attackDirect]+random.randint(-4, 4)
        self.direct = hero.attackDirect
        self.velocity = 10#random.randint(20,21)

    def boom(self):
        self.boom_sound.play()
    def update(self):
        if self.collision == False:
            self.x += self.velocity*math.cos(math.pi/180*self.angle)
            self.y += self.velocity*math.sin(math.pi/180*self.angle)
    def draw(self, hero, carpet):
        if self.collision == False : self.skill1.clip_draw(0,0, 30, 30, self.x-0.7*(carpet.x-self.carpetX), self.y-0.7*(carpet.y-self.carpetY))
        else:
            self.aniDelay+=1
            self.skill1.clip_draw(self.frame*30, 0, 30, 30,self.x-0.7*(carpet.x-self.carpetX), self.y-0.7*(carpet.y-self.carpetY))
            if self.aniDelay == 3:
                self.frame = (self.frame+1)%8
                self.aniDelay = 0
                if self.frame == 0:
                    for i in range(-1, len(hero.heroSkill1Box)-1):
                        if self == hero.heroSkill1Box[i]:
                            del hero.heroSkill1Box[i]
                            break


class Skill2:

    SPAN_POSITION = 430
    skill2_1LR, skill2_2LR, skill2_1UD, skill2_2UD = None, None, None, None
    boom_sound = None


    def collision(self, enemy, carpet, dir, ui, stage): #800 60
        if stage == 1 :
            if dir == 'LEFT' :
                if enemy.survive == True :
                    if enemy.x-0.7*(carpet.x-350) <= self.x + Skill2.SPAN_POSITION :
                        if enemy.state != enemy.ENEMY1_PATTERN1:
                            if self.y - 125 < enemy.y-0.7*(carpet.y-350) and enemy.y-0.7*(carpet.y-350) < self.y + 125 :
                                enemy.HP-=self.power
                                enemy.electric_shock_flag = True
                                ui.score += self.power
                            elif self.y - 160 < enemy.y-0.7*(carpet.y-350) and enemy.y-0.7*(carpet.y-350) < self.y + 160 :
                                enemy.HP-=self.power/2
                                enemy.electric_shock_flag = True
                                ui.score += self.power/2
                        else:
                            if self.y - 120 < enemy.y-0.7*(carpet.y-350) and enemy.y-0.7*(carpet.y-350) < self.y + 120 :
                                enemy.HP-=self.power
                                enemy.electric_shock_flag = True
                                ui.score += self.power
                            elif self.y - 160 < enemy.y-0.7*(carpet.y-350) and enemy.y-0.7*(carpet.y-350) < self.y + 160 :
                                enemy.HP-=self.power/2
                                enemy.electric_shock_flag = True
                                ui.score += self.power/2
            elif dir == 'RIGHT' :
                if enemy.survive == True :
                    if self.x - Skill2.SPAN_POSITION <= enemy.x-0.7*(carpet.x-350) :
                        if enemy.state != enemy.ENEMY1_PATTERN1:
                            if self.y - 125 < enemy.y-0.7*(carpet.y-350) and enemy.y-0.7*(carpet.y-350) < self.y + 125 :
                                enemy.HP-=self.power
                                enemy.electric_shock_flag = True
                                ui.score += self.power
                            elif self.y - 160 < enemy.y-0.7*(carpet.y-350) and enemy.y-0.7*(carpet.y-350) < self.y + 160 :
                                enemy.HP-=self.power/2
                                enemy.electric_shock_flag = True
                                ui.score += self.power/2
                        else:
                            if self.y - 120 < enemy.y-0.7*(carpet.y-350) and enemy.y-0.7*(carpet.y-350) < self.y + 120 :
                                enemy.HP-=self.power
                                enemy.electric_shock_flag = True
                                ui.score += self.power
                            elif self.y - 160 < enemy.y-0.7*(carpet.y-350) and enemy.y-0.7*(carpet.y-350) < self.y + 160 :
                                enemy.HP-=self.power/2
                                enemy.electric_shock_flag = True
                                ui.score += self.power/2
            elif dir == 'UP' :
                if enemy.survive == True :
                    if self.y - Skill2.SPAN_POSITION <= enemy.y-0.7*(carpet.y-350) :
                        if enemy.state != enemy.ENEMY1_PATTERN1:
                            if self.x - 50 < enemy.x-0.7*(carpet.x-350) and enemy.x-0.7*(carpet.x-350) < self.x + 50 :
                                enemy.HP-=self.power
                                enemy.electric_shock_flag = True
                                ui.score += self.power
                            elif self.x - 90 < enemy.x-0.7*(carpet.x-350) and enemy.x-0.7*(carpet.x-350) < self.x + 90 :
                                enemy.HP-=self.power/2
                                enemy.electric_shock_flag = True
                                ui.score += self.power/2
                        else:
                            if self.x - 120 < enemy.x-0.7*(carpet.x-350) and enemy.x-0.7*(carpet.x-350) < self.x + 120 :
                                enemy.HP-=self.power
                                enemy.electric_shock_flag = True
                                ui.score += self.power
                            elif self.x - 160 < enemy.x-0.7*(carpet.x-350) and enemy.x-0.7*(carpet.x-350) < self.x + 160 :
                                enemy.HP-=self.power/2
                                enemy.electric_shock_flag = True
                                ui.score += self.power/2
            elif dir == 'DOWN' :
                if enemy.survive == True :
                    if enemy.y-0.7*(carpet.y-350) <= self.y + Skill2.SPAN_POSITION :
                        if enemy.state != enemy.ENEMY1_PATTERN1:
                            if self.x - 50 < enemy.x-0.7*(carpet.x-350) and enemy.x-0.7*(carpet.x-350) < self.x + 50 :
                                enemy.HP-=self.power
                                enemy.electric_shock_flag = True
                                ui.score += self.power
                            elif self.x - 90 < enemy.x-0.7*(carpet.x-350) and enemy.x-0.7*(carpet.x-350) < self.x + 90 :
                                enemy.HP-=self.power/2
                                enemy.electric_shock_flag = True
                                ui.score += self.power/2
                        else:
                            if self.x - 120 < enemy.x-0.7*(carpet.x-350) and enemy.x-0.7*(carpet.x-350) < self.x + 120 :
                                enemy.HP-=self.power
                                enemy.electric_shock_flag = True
                                ui.score += self.power
                            elif self.x - 160 < enemy.x-0.7*(carpet.x-350) and enemy.x-0.7*(carpet.x-350) < self.x + 160 :
                                enemy.HP-=self.power/2
                                enemy.electric_shock_flag = True
                                ui.score += self.power/2

        if stage == 2 :
            if dir == 'LEFT' :
                for i in range(-1, len(enemy.ballList)-1):
                    if enemy.ballList[i].survive == True :
                        if enemy.ballList[i].x-0.7*(carpet.x-350) <= self.x + Skill2.SPAN_POSITION :
                            if self.y - 30 < enemy.ballList[i].y-0.7*(carpet.y-350) and enemy.ballList[i].y-0.7*(carpet.y-350) < self.y + 30 :
                                enemy.ballList[i].HP-=self.power
                                enemy.ballList[i].electric_shock_flag = True
                                ui.score += 10
                            elif self.y - 50 < enemy.ballList[i].y-0.7*(carpet.y-350) and enemy.ballList[i].y-0.7*(carpet.y-350) < self.y + 50 :
                                enemy.ballList[i].HP-=self.power/2
                                enemy.ballList[i].electric_shock_flag = True
                                ui.score += 10
                if enemy.survive == True :
                    if enemy.x-0.7*(carpet.x-350) <= self.x + Skill2.SPAN_POSITION :
                            if self.y - 130 < enemy.y-0.7*(carpet.y-350) and enemy.y-0.7*(carpet.y-350) < self.y + 130 :
                                if enemy.state != enemy.NORMAL :  enemy.HP-=self.power/enemy.defensive_power
                                elif enemy.HP < 500:
                                    enemy.HP+=self.power
                                    if enemy.HP >= 500 : enemy.HP = 500
                                enemy.electric_shock_flag = True
                                ui.score += 10
                            elif self.y - 160 < enemy.y-0.7*(carpet.y-350) and enemy.y-0.7*(carpet.y-350) < self.y + 160 :
                                if enemy.state != enemy.NORMAL :  enemy.HP-=(self.power/enemy.defensive_power)/2
                                elif enemy.HP < 500:
                                    enemy.HP+=self.power
                                    if enemy.HP >= 500 : enemy.HP = 500
                                enemy.electric_shock_flag = True
                                ui.score += 10

            elif dir == 'RIGHT' :
                for i in range(-1, len(enemy.ballList)-1):
                    if enemy.ballList[i].survive == True :
                        if self.x - Skill2.SPAN_POSITION <= enemy.ballList[i].x-0.7*(carpet.x-350) :
                            if self.y - 30 < enemy.ballList[i].y-0.7*(carpet.y-350) and enemy.ballList[i].y-0.7*(carpet.y-350) < self.y + 30 :
                                enemy.ballList[i].HP-=self.power
                                enemy.ballList[i].electric_shock_flag = True
                                ui.score += 10
                            elif self.y - 50 < enemy.ballList[i].y-0.7*(carpet.y-350) and enemy.ballList[i].y-0.7*(carpet.y-350) < self.y + 50 :
                                enemy.ballList[i].HP-=self.power/2
                                enemy.ballList[i].electric_shock_flag = True
                                ui.score += 10
                if enemy.survive == True :
                    if self.x - Skill2.SPAN_POSITION <= enemy.x-0.7*(carpet.x-350) :
                            if self.y - 130 < enemy.y-0.7*(carpet.y-350) and enemy.y-0.7*(carpet.y-350) < self.y + 130 :
                                if enemy.state != enemy.NORMAL :  enemy.HP-=self.power/enemy.defensive_power
                                elif enemy.HP < 500:
                                    enemy.HP+=self.power
                                    if enemy.HP >= 500 : enemy.HP = 500
                                enemy.electric_shock_flag = True
                                ui.score += 10
                            elif self.y - 160 < enemy.y-0.7*(carpet.y-350) and enemy.y-0.7*(carpet.y-350) < self.y + 160 :
                                if enemy.state != enemy.NORMAL :  enemy.HP-=(self.power/enemy.defensive_power)/2
                                elif enemy.HP < 500:
                                    enemy.HP+=self.power
                                    if enemy.HP >= 500 : enemy.HP = 500
                                enemy.electric_shock_flag = True
                                ui.score += 10

            elif dir == 'UP' :
                for i in range(-1, len(enemy.ballList)-1):
                    if enemy.ballList[i].survive == True :
                        if self.y - Skill2.SPAN_POSITION <= enemy.ballList[i].y-0.7*(carpet.y-350) :
                            if self.x - 30 < enemy.ballList[i].x-0.7*(carpet.x-350) and enemy.ballList[i].x-0.7*(carpet.x-350) < self.x + 30 :
                                enemy.ballList[i].HP-=self.power
                                enemy.ballList[i].electric_shock_flag = True
                                ui.score += 10
                            elif self.x - 50 < enemy.ballList[i].x-0.7*(carpet.x-350) and enemy.ballList[i].x-0.7*(carpet.x-350) < self.x + 50 :
                                enemy.ballList[i].HP-=self.power/2
                                enemy.ballList[i].electric_shock_flag = True
                                ui.score += 10
                if enemy.survive == True :
                    if self.y - Skill2.SPAN_POSITION <= enemy.y-0.7*(carpet.y-350) :
                            if self.x - 100 < enemy.x-0.7*(carpet.x-350) and enemy.x-0.7*(carpet.x-350) < self.x + 100 :
                                if enemy.state != enemy.NORMAL :  enemy.HP-=self.power/enemy.defensive_power
                                elif enemy.HP < 500:
                                    enemy.HP+=self.power
                                    if enemy.HP >= 500 : enemy.HP = 500
                                enemy.electric_shock_flag = True
                                ui.score += 10
                            elif self.x - 130 < enemy.x-0.7*(carpet.x-350) and enemy.x-0.7*(carpet.x-350) < self.x + 130 :
                                if enemy.state != enemy.NORMAL :  enemy.HP-=(self.power/enemy.defensive_power)/2
                                elif enemy.HP < 500:
                                    enemy.HP+=self.power
                                    if enemy.HP >= 500 : enemy.HP = 500
                                enemy.electric_shock_flag = True
                                ui.score += 10
            elif dir == 'DOWN' :
                for i in range(-1, len(enemy.ballList)-1):
                    if enemy.ballList[i].survive == True :
                        if enemy.ballList[i].y-0.7*(carpet.y-350) <= self.y + Skill2.SPAN_POSITION :
                            if self.x - 30 < enemy.ballList[i].x-0.7*(carpet.x-350) and enemy.ballList[i].x-0.7*(carpet.x-350) < self.x + 30 :
                                enemy.ballList[i].HP-=self.power
                                enemy.ballList[i].electric_shock_flag = True
                                ui.score += 10
                            elif self.x - 50 < enemy.ballList[i].x-0.7*(carpet.x-350) and enemy.ballList[i].x-0.7*(carpet.x-350) < self.x + 50 :
                                enemy.ballList[i].HP-=self.power/2
                                enemy.ballList[i].electric_shock_flag = True
                                ui.score += 10
                if enemy.survive == True :
                    if enemy.y-0.7*(carpet.y-350) <= self.y + Skill2.SPAN_POSITION :
                            if self.x - 100 < enemy.x-0.7*(carpet.x-350) and enemy.x-0.7*(carpet.x-350) < self.x + 100 :
                                if enemy.state != enemy.NORMAL :  enemy.HP-=self.power/enemy.defensive_power
                                elif enemy.HP < 500:
                                    enemy.HP+=self.power
                                    if enemy.HP >= 500 : enemy.HP = 500
                                enemy.electric_shock_flag = True
                                ui.score += 10
                            elif self.x - 130 < enemy.x-0.7*(carpet.x-350) and enemy.x-0.7*(carpet.x-350) < self.x + 130 :
                                if enemy.state != enemy.NORMAL :  enemy.HP-=(self.power/enemy.defensive_power)/2
                                elif enemy.HP < 500:
                                    enemy.HP+=self.power
                                    if enemy.HP >= 500 : enemy.HP = 500
                                enemy.electric_shock_flag = True
                                ui.score += 10

    def __init__(self, hero, carpet):
        if Skill2.boom_sound == None:
            Skill2.boom_sound = load_wav('sound/hero_skill/hero_skill2boom.ogg')
            Skill2.boom_sound.set_volume(32)
        if Skill2.skill2_1LR == None : Skill2.skill2_1LR = load_image('hero/heroSkill/skill2_1LR.png')
        if Skill2.skill2_2LR == None : Skill2.skill2_2LR = load_image('hero/heroSkill/skill2_2LR.png')
        if Skill2.skill2_1UD == None : Skill2.skill2_1UD = load_image('hero/heroSkill/skill2_1UD.png')
        if Skill2.skill2_2UD == None : Skill2.skill2_2UD = load_image('hero/heroSkill/skill2_2UD.png')
        #마법은 주인공 기준으로 생성된다.
        self.x = carpet.x
        self.y = carpet.y
        self.frame = 0
        self.aniFlag = random.randint(0,1)
        self.aniDelay = 0
        self.direct = hero.attackDirect
        self.distance = 0
        self.power = 26
        #마법 탄환 초기 생성 위치 초기화
        if hero.attackDirect=='UP' : self.y += Skill2.SPAN_POSITION
        elif hero.attackDirect == 'DOWN' : self.y -= Skill2.SPAN_POSITION
        elif hero.attackDirect == 'LEFT' : self.x -= Skill2.SPAN_POSITION
        elif hero.attackDirect == 'RIGHT' : self.x += Skill2.SPAN_POSITION
        self.boom()
    def boom(self):
        self.boom_sound.play()
    def update(self):
        pass
    def draw(self, hero, carpet, enemy1, ui, stage):
        global heroSkill2Box
        self.aniDelay+=1
        if self.direct == 'RIGHT' or self.direct == 'LEFT':
            if self.aniFlag == 0:
                self.skill2_1LR.clip_draw(0, 360-self.frame*60, 800,60, self.x, self.y)
                if self.aniDelay == 3:
                    if self.frame == 0 : self.collision(enemy1, carpet, self.direct, ui, stage)
                    self.frame = (self.frame+1)%7
                    self.aniDelay=0
                    if self.frame == 0:
                        for i in range(-1, len(hero.heroSkill2Box)-1):
                                if self == hero.heroSkill2Box[i]:
                                    del hero.heroSkill2Box[i]
                                    break
            else:
                self.skill2_2LR.clip_draw(0, 360-self.frame*60, 800,60, self.x, self.y)
                if self.aniDelay == 3:
                    if self.frame == 0 : self.collision(enemy1, carpet, self.direct,ui, stage)
                    self.frame = (self.frame+1)%7
                    self.aniDelay=0
                    if self.frame == 0:
                        for i in range(-1, len(hero.heroSkill2Box)-1):
                                if self == hero.heroSkill2Box[i]:
                                    del hero.heroSkill2Box[i]
                                    break
        elif self.direct == 'UP' or self.direct == 'DOWN':
            if self.aniFlag == 0:
                self.skill2_1UD.clip_draw(self.frame*60, 0, 60,800, self.x, self.y)
                if self.aniDelay == 3:
                    if self.frame == 0 : self.collision(enemy1, carpet, self.direct, ui, stage)
                    self.frame = (self.frame+1)%7
                    self.aniDelay=0
                    if self.frame == 0:
                        for i in range(-1, len(hero.heroSkill2Box)-1):
                                if self == hero.heroSkill2Box[i]:
                                    del hero.heroSkill2Box[i]
                                    break
            else:
                self.skill2_2UD.clip_draw(self.frame*60, 0, 60,800, self.x, self.y)
                if self.aniDelay == 3:
                    if self.frame == 0 : self.collision(enemy1, carpet, self.direct, ui, stage)
                    self.frame = (self.frame+1)%7
                    self.aniDelay=0
                    if self.frame == 0:
                        for i in range(-1, len(hero.heroSkill2Box)-1):
                                if self == hero.heroSkill2Box[i]:
                                    del hero.heroSkill2Box[i]
                                    break

class Skill3:

    skill3 = None
    skill3Boom = None
    skill3_data = None
    boom_sound = None
    KIND1, KIND2, KIND3, KIND4, KIND5 = 0, 1, 2, 3, 4
    SPAN_POSITION = 30
    SELF_EXPLOSION_TIME = 180
    skill3_kind = { KIND1 : 'KIND1', KIND2 : 'KIND2', KIND3 : 'KIND3', KIND4 : 'KIND4', KIND5 : 'KIND5' }


    def __init__(self, hero, carpet):
        if Skill3.boom_sound == None:
            Skill3.boom_sound = load_wav('sound/hero_skill/hero_skill3boom.ogg')
            Skill3.boom_sound.set_volume(32)
        if Skill3.skill3 == None: Skill3.skill3 = load_image('hero/heroSkill/skill3.png')
        if Skill3.skill3Boom == None: Skill3.skill3Boom = load_image('hero/heroSkill/skill3boom.png')
        if Skill3.skill3_data == None:
            skill3_data_file = open('hero/heroSkill/skill3_data.txt','r')
            Skill3.skill3_data = json.load(skill3_data_file)
            skill3_data_file.close()
        #마법은 주인공 기준으로 생성된다.
        self.x = hero.x+carpet.x
        self.y = hero.y+carpet.y
        self.frame = 0
        self.aniDelay = 0
        self.self_explosion_time = Skill3.SELF_EXPLOSION_TIME
        self.power = 0
        self.collision = False
        self.carpetX = carpet.x
        self.carpetY = carpet.y
        self.kind = random.randint(1, 36)
        if 0 < self.kind and self.kind < 16 : self.kind = self.KIND1
        elif 15< self.kind and self.kind <26 : self.kind = self.KIND2
        elif 25< self.kind and self.kind <31 : self.kind = self.KIND3
        elif 30< self.kind and self.kind <36 : self.kind = self.KIND4
        elif 35< self.kind and self.kind <37 : self.kind = self.KIND5
        self.power = Skill3.skill3_data[self.skill3_kind[self.kind]]['power']
        #마법 탄환 초기 생성 위치 초기화
        if hero.attackDirect=='UP': self.y += Skill3.SPAN_POSITION
        elif hero.attackDirect == 'DOWN': self.y -= Skill3.SPAN_POSITION
        elif hero.attackDirect == 'LEFT': self.x -= Skill3.SPAN_POSITION
        elif hero.attackDirect == 'RIGHT': self.x += Skill3.SPAN_POSITION
    def boom(self):
        Skill3.boom_sound.play()
    def update(self):
        if self.collision == False :
            self.self_explosion_time -= 1
            if self.self_explosion_time < 0:
                self.collision = True

    def draw(self, hero, carpet):
        if self.collision == False :
            self.skill3.clip_draw(self.kind*40,0, 40, 40, self.x-0.7*(carpet.x-self.carpetX), self.y-0.7*(carpet.y-self.carpetY))
        else :
            self.aniDelay+=1
            self.skill3Boom.clip_draw(60*self.frame, 0, 60, 60,self.x-0.7*(carpet.x-self.carpetX), self.y-0.7*(carpet.y-self.carpetY))
            if self.aniDelay == 10:
                self.frame = (self.frame+1)%8
                self.aniDelay = 0
                if self.frame == 0:
                    for i in range(-1, len(hero.heroSkill3Box)-1):
                        if self == hero.heroSkill3Box[i]:
                            del hero.heroSkill3Box[i]
                            break
