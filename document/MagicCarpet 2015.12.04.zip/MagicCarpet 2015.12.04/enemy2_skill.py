from pico2d import *
from simple_math_tool import *

class Enemy2Razer:

    razer = None

    def __init__(self, enemy2, carpet):
        if Enemy2Razer.razer == None:
            Enemy2Razer.razer = load_image('enemy2/enemy2razer.png')
        self.x = enemy2.x-0.7*(carpet.x-350)
        self.y = enemy2.y-0.7*(carpet.y-350)
        self.angle = enemy2.razer_angle
        self.collision = False
        self.carpetX = carpet.x
        self.carpetY = carpet.y
        self.velocity = 3
        self.power = 30
        self.acceleration = 0
        self.slope = 0
        self.slope_flag = (-1+ 2*(enemy2.move_count % 2))
    def update(self):
        if self.collision == False:
            self.acceleration+=0.03
            self.slope+=1
            self.x += self.velocity*self.acceleration*math.cos(math.pi/180*(self.angle+self.slope_flag*self.slope))
            self.y += self.velocity*self.acceleration*math.sin(math.pi/180*(self.angle+self.slope_flag*self.slope))

    def draw(self, enemy2, carpet):
        if self.collision == False : self.razer.clip_draw(0, 0, 30,30, self.x-0.7*(carpet.x-self.carpetX), self.y-0.7*(carpet.y-self.carpetY))
        else:
            for i in range(-1, len(enemy2.enemy2RazerBox)-1):
                if self == enemy2.enemy2RazerBox[i]:
                    del enemy2.enemy2RazerBox[i]
                    break

class Bomb:

    bomb = None
    boom = None
    boom_sound = None

    def collision(self, bombX, bombY, ui, carpet, hero): #800 60
        global score
        global combo_flag
        global combo_score
        global combo_score_show_time
        global combo_score_degree
        for i in range(-1, len(ui.hostageList)-1):
            if 40 > distance(bombX, bombY, 350+ui.hostageList[i].x-0.20*(carpet.x-350), 350+ui.hostageList[i].y-0.20*(carpet.y-350)) \
                            and ui.hostageList[i].survive == True:
                ui.hostageList[i].survive = False
                if ui.combo_flag == True:
                    ui.combo_flag = False
                    ui.combo_score_show_time = 15
                    ui.score += ui.combo_score
                    ui.combo_score_degree = ui.combo_score
                    ui.combo_score = 0
                ui.hostageList[i].frame = 0
                ui.hostageList[i].aniDelay = 0
        if 40 > distance(bombX, bombY, hero.x+carpet.x, hero.y+carpet.y) \
                and hero.survive == True:
            hero.HP-=self.power

    def __init__(self, carpet,enemy):
        if Bomb.boom_sound == None:
            Bomb.boom_sound = load_wav('sound/enemy2/enemy2_skill/enemy2_skill2.ogg')
            Bomb.boom_sound.set_volume(32)
        if Bomb.bomb == None: Bomb.bomb = load_image('enemy2/enemy2bomb.png')
        if Bomb.boom == None: Bomb.boom = load_image('enemy2/enemy2boom.png')
        self.x = enemy.skillX
        self.y = enemy.skillY
        self.carpetX = carpet.x
        self.carpetY = carpet.y
        self.boom_flag = False
        self.aniDelay = 0
        self.ding = 5
        self.power=40
        self.frame = 0
    def bomb_boom(self):
        Bomb.boom_sound.play()
    def update(self):
        pass

    def draw(self, enemy2, carpet, ui, hero):
        self.aniDelay += 1
        if self.boom_flag == False : self.bomb.clip_draw(self.frame*50, 0, 50, 50, self.x-0.7*(carpet.x-self.carpetX), self.y-0.7*(carpet.y-self.carpetY))
        elif self.boom_flag == True : self.boom.clip_draw(self.frame*100, 0, 100,100, self.x-0.7*(carpet.x-self.carpetX), self.y-0.7*(carpet.y-self.carpetY))
        if self.aniDelay == self.ding :
            self.frame = (self.frame+1)%8
            if self.frame == 0: #터지는 순간
                if self.boom_flag == False :
                    self.bomb_boom()
                    self.collision(self.x-0.7*(carpet.x-self.carpetX), self.y-0.7*(carpet.y-self.carpetY), ui, carpet, hero)
                    self.boom_flag = True
                    self.ding = 4
                    self.aniDelay=0
                    #충돌체크
                elif self.boom_flag == True :
                    for i in range(-1, len(enemy2.enemy2BombBox)-1):
                        if self == enemy2.enemy2BombBox[i]:
                            del enemy2.enemy2BombBox[i]
                            break
            self.aniDelay = 0