import json
from pico2d import *
from simple_math_tool import *
from hostage import Hostage
#UI 클래스
class UI:

    INIT_X, INIT_Y = 450, 350
    DISPLAY_CENTER_X, DISPLAY_CENTER_Y = 350, 350
    ULTRA_SCORE_SHOW_TIME = 70
    font = None
    rescue_sound = None
    ultra_bonus_sound = None
    magic_swap_sound = None

    def ScoreInform(self, x, y, ctrlY, color):
        self.font.draw(x, y, '[SCORE]', color)
        self.font.draw(x, y-20, ': %d'%self.score, color)
        if self.combo_flag == True:
            self.font.draw(x, y-40, ': +RESCUE BONUS', color)
            self.font.draw(x, y-60, ': %d'%self.combo_score, color)


    def EnemyState(self, x, y, ctrlY, color, enemy, stage):
        if stage == 1:
            self.font.draw(x, y+ctrlY, '[Boss State]', color)
            self.font.draw(x, y-20+ctrlY, '-HP : %d'%enemy.HP, color)
        elif stage == 2:
            self.font.draw(x, y+ctrlY, '[Boss State]', color)
            self.font.draw(x, y-20+ctrlY, '-DEF POWER',color)
            self.font.draw(x, y-40+ctrlY, ': %d'%enemy.defensive_power,color)
            self.font.draw(x, y-60+ctrlY, '-HP : %d'%enemy.HP, color)
            if enemy.state == enemy.ENEMY2_PATTERN3 :
                self.font.draw(x, y-80+ctrlY, '+BALL HP', color)
                for i in range(-1, len(enemy.ballList)-1):
                    self.font.draw(x, y-100+ctrlY-20*(i+1), 'ball_%d : %d'%(i+1, enemy.ballList[i].HP), color)
            elif enemy.state == enemy.NORMAL :
                self.font.draw(x, y-80+ctrlY, '+CHANGING DAMAGE', (200, 100, 100))
                self.font.draw(x, y-100+ctrlY, 'TO HP', (200, 100, 100))


    def HeroState(self, x, y, ctrlY, color, hero):
        self.font.draw(x, y+ctrlY, '[Hero State]', color)
        self.font.draw(x, y-20+ctrlY, '-HP : %d'%hero.HP, color)
        self.font.draw(x, y-40+ctrlY, '-Skill Type', color)
        self.font.draw(x, y-60+ctrlY, ': %s'%hero.skillType, color)
        if hero.skillType == 'SKILL2' :
            self.font.draw(x, y-80+ctrlY, '+CAHRGE', color)
            if hero.skill2Delay == 0 : self.font.draw(x, y-100+ctrlY, ': READY', color)
            else: self.font.draw(x, y-100+ctrlY, ': %d'%(70-hero.skill2Delay), color)
        elif hero.skillType == 'SKILL3' :
            self.font.draw(x, y-80+ctrlY, '+VALID NUM', color)
            self.font.draw(x, y-100+ctrlY, ': %d'%(5-hero.heroSkill3_num), color)
            self.font.draw(x, y-120+ctrlY, '+COOLTIME', color)
            if hero.heroSkill3_num >= 5:
                self.font.draw(x, y-140+ctrlY, ': %d'%(300-hero.heroSkill3CoolTime), color)
            else :
                self.font.draw(x, y-140+ctrlY, ': Completion', color)


    def RescueInform(self, x, y, ctrlY, color):
        self.font.draw(x, y+ctrlY, '[RESCUE INFORM]', color)
        self.font.draw(x, y-20+ctrlY, '-APPEAR : %d'%self.hostage_num, color)
        self.font.draw(x, y-40+ctrlY, '-SAVE : %d'%self.save_num, color)
        self.font.draw(x, y-60+ctrlY, 'KING : %s'%self.king_state, color)
        self.font.draw(x, y-80+ctrlY, 'QUEEN : %s'%self.queen_state, color)

    # def CurrentStage(self, x, y, ctrlY, color, font,stage):
    #     font.draw(x, y, '[Current Stage]', color)
    #     font.draw(x, y-20, ': %d'%stage, color)

    def supervise_hostage(self, hero, carpet, enemy, ui):
        #도망치는 사람 생성을 관리한다.
        if self.hostage_num < 20:
            self.delay_create_hostage+=1
            if self.delay_create_hostage ==2:
                self.hostageList.append(Hostage())
                self.hostage_num+=1
                self.delay_create_hostage = 0
        #도망치는 사람이 구출됐을 경우
        for i in range(-1, len(self.hostageList)-1):
            if 80 > distance(350+self.hostageList[i].x-0.20*(carpet.x-350), 350+self.hostageList[i].y-0.20*(carpet.y-350), carpet.x, carpet.y ) and \
                    self.hostageList[i].survive == True and hero.survive == True and enemy.survive == True:
                self.rescue_hostage()
                if self.hostageList[i].position == self.hostageList[i].KING  :
                    self.king_state = 'SAVE'
                elif self.hostageList[i].position == self.hostageList[i].QUEEN :
                    self.queen_state = 'SAVE'
                if hero.HP < 100 : hero.HP += self.hostageList[i].HP_buff
                if hero.HP >= 100 : hero.HP = 100
                self.HP_buff_degree = self.hostageList[i].HP_buff
                self.score += self.hostageList[i].point
                self.point_degree = self.hostageList[i].point
                self.HP_buff_show_time = 15
                self.point_show_time = 15
                self.combo_flag = True
                self.combo_score+=10
                del self.hostageList[i]
                self.hostage_num-=1
                self.save_num+=1
                break

    #주인공의 스킬 속성 변화를 관리하는 함수
    def supervise_bullet(self, hero, carpet, enemy, stage, ballRazerBox):
        if stage == 1:
            #supervise skill1
            for i in range(-1, len(hero.heroSkill1Box)-1):
                #if heroSkill1Box[i] in heroSkill1Box:
                if hero.heroSkill1Box[i].direct == 'UP':
                    if hero.heroSkill1Box[i].y-0.7*(carpet.y-hero.heroSkill1Box[i].carpetY) > 800-0.20*(carpet.y-350) : hero.heroSkill1Box[i].collision = True
                elif hero.heroSkill1Box[i].direct == 'DOWN':
                    if hero.heroSkill1Box[i].y-0.7*(carpet.y-hero.heroSkill1Box[i].carpetY) < -100-0.20*(carpet.y-350) : hero.heroSkill1Box[i].collision = True
                elif hero.heroSkill1Box[i].direct == 'LEFT':
                    if hero.heroSkill1Box[i].x-0.7*(carpet.x-hero.heroSkill1Box[i].carpetX) < -100-0.20*(carpet.x-350) : hero.heroSkill1Box[i].collision = True
                elif hero.heroSkill1Box[i].direct == 'RIGHT':
                    if hero.heroSkill1Box[i].x-0.7*(carpet.x-hero.heroSkill1Box[i].carpetX) > 800-0.20*(carpet.x-350) : hero.heroSkill1Box[i].collision = True

            # superbise_allSkill
            for i in range(-1, len(hero.heroSkillBox)-1):
                for j in range(-1, len(hero.heroSkillBox[i])-1):
                    if hero.heroSkillBox[i][j].collision == False:
                        if enemy.survive == True:
                            if enemy.state != enemy.ENEMY1_PATTERN1:
                                if ((enemy.x-0.7*(carpet.x-350)-30 < hero.heroSkillBox[i][j].x-0.7*(carpet.x-hero.heroSkillBox[i][j].carpetX) and \
                                    hero.heroSkillBox[i][j].x-0.7*(carpet.x-hero.heroSkillBox[i][j].carpetX) < enemy.x-0.7*(carpet.x-350)+30 and \
                                    enemy.y-0.7*(carpet.y-350)+35 < hero.heroSkillBox[i][j].y-0.7*(carpet.y-hero.heroSkillBox[i][j].carpetY) and \
                                    hero.heroSkillBox[i][j].y-0.7*(carpet.y-hero.heroSkillBox[i][j].carpetY) < enemy.y-0.7*(carpet.y-350)+115) or \
                                    (enemy.x-0.7*(carpet.x-350)-35 < hero.heroSkillBox[i][j].x-0.7*(carpet.x-hero.heroSkillBox[i][j].carpetX) and \
                                    hero.heroSkillBox[i][j].x-0.7*(carpet.x-hero.heroSkillBox[i][j].carpetX) < enemy.x-0.7*(carpet.x-350)+35 and \
                                    enemy.y-0.7*(carpet.y-350)-35 < hero.heroSkillBox[i][j].y-0.7*(carpet.y-hero.heroSkillBox[i][j].carpetY) and \
                                    hero.heroSkillBox[i][j].y-0.7*(carpet.y-hero.heroSkillBox[i][j].carpetY) < enemy.y-0.7*(carpet.y-350)+35) or \
                                    (enemy.x-0.7*(carpet.x-350)-50 < hero.heroSkillBox[i][j].x-0.7*(carpet.x-hero.heroSkillBox[i][j].carpetX) and \
                                    hero.heroSkillBox[i][j].x-0.7*(carpet.x-hero.heroSkillBox[i][j].carpetX) < enemy.x-0.7*(carpet.x-350)+50 and \
                                    enemy.y-0.7*(carpet.y-350)-105 < hero.heroSkillBox[i][j].y-0.7*(carpet.y-hero.heroSkillBox[i][j].carpetY) and \
                                    hero.heroSkillBox[i][j].y-0.7*(carpet.y-hero.heroSkillBox[i][j].carpetY) < enemy.y-0.7*(carpet.y-350)-35)):
                                    hero.heroSkillBox[i][j].collision = True
                                    hero.heroSkillBox[i][j].boom()
                                    enemy.HP-=hero.heroSkillBox[i][j].power
                                    self.score += hero.heroSkillBox[i][j].power
                            else:
                                if 120 > distance(hero.heroSkillBox[i][j].x-0.7*(carpet.x-hero.heroSkillBox[i][j].carpetX), hero.heroSkillBox[i][j].y-0.7*(carpet.y-hero.heroSkillBox[i][j].carpetY),
                                                  enemy.x-0.7*(carpet.x-350), enemy.y-0.7*(carpet.y-350)):
                                    hero.heroSkillBox[i][j].collision = True
                                    enemy.HP-=hero.heroSkillBox[i][j].power
                                    hero.heroSkillBox[i][j].boom()
                                    self.score += hero.heroSkillBox[i][j].power

            for i in range(-1, len(enemy.enemy1RazerBox)-1):
                if enemy.enemy1RazerBox[i].collision == False:
                #if ballRazerBox[i] in ballRazerBox:
                    if enemy.enemy1RazerBox[i].y-0.7*(carpet.y-enemy.enemy1RazerBox[i].carpetY) > 800-0.20*(carpet.y-350) or \
                        enemy.enemy1RazerBox[i].y-0.7*(carpet.y-enemy.enemy1RazerBox[i].carpetY) < -100-0.20*(carpet.y-350) or \
                        enemy.enemy1RazerBox[i].x-0.7*(carpet.x-enemy.enemy1RazerBox[i].carpetX) < -100-0.20*(carpet.x-350) or \
                        enemy.enemy1RazerBox[i].x-0.7*(carpet.x-enemy.enemy1RazerBox[i].carpetX) > 800-0.20*(carpet.x-350) :
                        enemy.enemy1RazerBox[i].collision = True
                    if 15 > distance(enemy.enemy1RazerBox[i].x-0.7*(carpet.x-enemy.enemy1RazerBox[i].carpetX), enemy.enemy1RazerBox[i].y-0.7*(carpet.y-enemy.enemy1RazerBox[i].carpetY), hero.x+carpet.x, hero.y+carpet.y) \
                            and hero.survive == True:
                        hero.HP-=enemy.enemy1RazerBox[i].power
                        enemy.enemy1RazerBox[i].collision = True
                        #break
                    for j in range(-1, len(self.hostageList)-1):
                        if 15 > distance(350+self.hostageList[j].x-0.20*(carpet.x-350), 350+self.hostageList[j].y-0.20*(carpet.y-350), enemy.enemy1RazerBox[i].x-0.7*(carpet.x-enemy.enemy1RazerBox[i].carpetX), enemy.enemy1RazerBox[i].y-0.7*(carpet.y-enemy.enemy1RazerBox[i].carpetY) ) and \
                            self.hostageList[j].survive == True:
                            self.hostageList[j].survive = False
                            if self.combo_flag == True:
                                self.combo_flag = False
                                self.combo_score_show_time = 15
                                self.score += self.combo_score
                                self.combo_score_degree = self.combo_score
                                self.combo_score = 0
                            self.hostageList[j].frame = 0
                            self.hostageList[j].aniDelay = 0
        # enemy1SickleWindList = []
        # 인질의 속성 변화를 관리하는 함수
            for i in range(-1, len(enemy.enemy1SickleWindList)-1):
                if enemy.enemy1SickleWindList[i].collision == False:
                #if ballRazerBox[i] in ballRazerBox:
                    if enemy.enemy1SickleWindList[i].y-0.7*(carpet.y-enemy.enemy1SickleWindList[i].carpetY) > 800-0.20*(carpet.y-350) or \
                        enemy.enemy1SickleWindList[i].y-0.7*(carpet.y-enemy.enemy1SickleWindList[i].carpetY) < -100-0.20*(carpet.y-350) or \
                        enemy.enemy1SickleWindList[i].x-0.7*(carpet.x-enemy.enemy1SickleWindList[i].carpetX) < -100-0.20*(carpet.x-350) or \
                        enemy.enemy1SickleWindList[i].x-0.7*(carpet.x-enemy.enemy1SickleWindList[i].carpetX) > 800-0.20*(carpet.x-350) :
                        enemy.enemy1SickleWindList[i].collision = True
                    elif ((enemy.enemy1SickleWindList[i].x-0.7*(carpet.x-enemy.enemy1SickleWindList[i].carpetX)-40*(-1+2*enemy.enemy1SickleWindList[i].dir)-(1-enemy.enemy1SickleWindList[i].dir)*20 < carpet.x and \
                        carpet.x < enemy.enemy1SickleWindList[i].x-0.7*(carpet.x-enemy.enemy1SickleWindList[i].carpetX)-20*(-1+2*enemy.enemy1SickleWindList[i].dir)+(1-enemy.enemy1SickleWindList[i].dir)*20 and \
                        enemy.enemy1SickleWindList[i].y-0.7*(carpet.y-enemy.enemy1SickleWindList[i].carpetY)-50 < carpet.y and \
                        carpet.y < enemy.enemy1SickleWindList[i].y-0.7*(carpet.y-enemy.enemy1SickleWindList[i].carpetY)+50) or \
                        (enemy.enemy1SickleWindList[i].x-0.7*(carpet.x-enemy.enemy1SickleWindList[i].carpetX)-20*(-1+2*enemy.enemy1SickleWindList[i].dir)-(1-enemy.enemy1SickleWindList[i].dir)*40) < carpet.x and \
                        carpet.x < enemy.enemy1SickleWindList[i].x-0.7*(carpet.x-enemy.enemy1SickleWindList[i].carpetX)+20*(-1+2*enemy.enemy1SickleWindList[i].dir)+(1-enemy.enemy1SickleWindList[i].dir)*40 and \
                        enemy.enemy1SickleWindList[i].y-0.7*(carpet.y-enemy.enemy1SickleWindList[i].carpetY)-100 < carpet.y and \
                        carpet.y < enemy.enemy1SickleWindList[i].y-0.7*(carpet.y-enemy.enemy1SickleWindList[i].carpetY)+100) or \
                        (enemy.enemy1SickleWindList[i].x-0.7*(carpet.x-enemy.enemy1SickleWindList[i].carpetX)+20*(-1+2*enemy.enemy1SickleWindList[i].dir)-(1-enemy.enemy1SickleWindList[i].dir)*30 < carpet.x and \
                        carpet.x < enemy.enemy1SickleWindList[i].x-0.7*(carpet.x-enemy.enemy1SickleWindList[i].carpetX)+50*(-1+2*enemy.enemy1SickleWindList[i].dir)+(1-enemy.enemy1SickleWindList[i].dir)*30 and \
                        enemy.enemy1SickleWindList[i].y-0.7*(carpet.y-enemy.enemy1SickleWindList[i].carpetY)-170   < carpet.y and \
                        carpet.y < enemy.enemy1SickleWindList[i].y-0.7*(carpet.y-enemy.enemy1SickleWindList[i].carpetY)+180):
                        if hero.survive == True:
                            hero.HP-=enemy.enemy1SickleWindList[i].power
                            enemy.enemy1SickleWindList[i].collision = True
            for i in range(-1, len(enemy.enemy1SickleWindList)-1):
                if enemy.enemy1SickleWindList[i].collision == False:
                    for j in range(-1, len(self.hostageList)-1):
                        if self.hostageList[j].survive == True:
                            if ((enemy.enemy1SickleWindList[i].x-0.7*(carpet.x-enemy.enemy1SickleWindList[i].carpetX)-40*(-1+2*enemy.enemy1SickleWindList[i].dir)-(1-enemy.enemy1SickleWindList[i].dir)*20 < 350+self.hostageList[j].x-0.20*(carpet.x-350) and \
                                350+self.hostageList[j].x-0.20*(carpet.x-350) < enemy.enemy1SickleWindList[i].x-0.7*(carpet.x-enemy.enemy1SickleWindList[i].carpetX)-20*(-1+2*enemy.enemy1SickleWindList[i].dir)+(1-enemy.enemy1SickleWindList[i].dir)*20 and \
                                enemy.enemy1SickleWindList[i].y-0.7*(carpet.y-enemy.enemy1SickleWindList[i].carpetY)-50 < 350+self.hostageList[j].y-0.20*(carpet.y-350) and \
                                350+self.hostageList[j].y-0.20*(carpet.y-350) < enemy.enemy1SickleWindList[i].y-0.7*(carpet.y-enemy.enemy1SickleWindList[i].carpetY)+50) or \
                                (enemy.enemy1SickleWindList[i].x-0.7*(carpet.x-enemy.enemy1SickleWindList[i].carpetX)-20*(-1+2*enemy.enemy1SickleWindList[i].dir)-(1-enemy.enemy1SickleWindList[i].dir)*40) < 350+self.hostageList[j].x-0.20*(carpet.x-350) and \
                                350+self.hostageList[j].x-0.20*(carpet.x-350) < enemy.enemy1SickleWindList[i].x-0.7*(carpet.x-enemy.enemy1SickleWindList[i].carpetX)+20*(-1+2*enemy.enemy1SickleWindList[i].dir)+(1-enemy.enemy1SickleWindList[i].dir)*40 and \
                                enemy.enemy1SickleWindList[i].y-0.7*(carpet.y-enemy.enemy1SickleWindList[i].carpetY)-100 < 350+self.hostageList[j].y-0.20*(carpet.y-350) and \
                                350+self.hostageList[j].y-0.20*(carpet.y-350) < enemy.enemy1SickleWindList[i].y-0.7*(carpet.y-enemy.enemy1SickleWindList[i].carpetY)+100) or \
                                (enemy.enemy1SickleWindList[i].x-0.7*(carpet.x-enemy.enemy1SickleWindList[i].carpetX)+20*(-1+2*enemy.enemy1SickleWindList[i].dir)-(1-enemy.enemy1SickleWindList[i].dir)*30 < 350+self.hostageList[j].x-0.20*(carpet.x-350) and \
                                350+self.hostageList[j].x-0.20*(carpet.x-350) < enemy.enemy1SickleWindList[i].x-0.7*(carpet.x-enemy.enemy1SickleWindList[i].carpetX)+50*(-1+2*enemy.enemy1SickleWindList[i].dir)+(1-enemy.enemy1SickleWindList[i].dir)*30 and \
                                enemy.enemy1SickleWindList[i].y-0.7*(carpet.y-enemy.enemy1SickleWindList[i].carpetY)-170   < 350+self.hostageList[j].y-0.20*(carpet.y-350) and \
                                350+self.hostageList[j].y-0.20*(carpet.y-350) < enemy.enemy1SickleWindList[i].y-0.7*(carpet.y-enemy.enemy1SickleWindList[i].carpetY)+180):
                                self.hostageList[j].survive = False
                                if self.combo_flag == True:
                                    self.combo_flag = False
                                    self.combo_score_show_time = 15
                                    self.score += self.combo_score
                                    self.combo_score_degree = self.combo_score
                                    self.combo_score = 0
                                self.hostageList[j].frame = 0
                                self.hostageList[j].aniDelay = 0

            if enemy.state == enemy.ENEMY1_PATTERN1:
                if enemy.survive == True:
                    if 120 > distance(carpet.x, carpet.y, enemy.x-0.7*(carpet.x-350), enemy.y-0.7*(carpet.y-350) ) :
                        if hero.survive == True and hero.collision == False:
                            hero.HP-=enemy.power
                            hero.collision = True
                    for i in range(-1, len(self.hostageList)-1):
                        if self.hostageList[i].survive == True:
                            if 120 > distance(350+self.hostageList[i].x-0.20*(carpet.x-350), 350+self.hostageList[i].y-0.20*(carpet.y-350),enemy.x-0.7*(carpet.x-350), enemy.y-0.7*(carpet.y-350) ) :
                                self.hostageList[i].survive = False
                                if self.combo_flag == True:
                                    self.combo_flag = False
                                    self.combo_score_show_time = 15
                                    self.score += self.combo_score
                                    self.combo_score_degree = self.combo_score
                                    self.combo_score = 0
                                self.hostageList[i].frame = 0
                                self.hostageList[i].aniDelay = 0

            if enemy.state == enemy.ENEMY1_PATTERN3:
                if enemy.survive == True:
                    if enemy.x-0.7*(carpet.x-350)-150*(-1+2*(1-enemy.ThisIsRight(carpet.x, carpet)))-(1-(1-enemy.ThisIsRight(carpet.x, carpet)))*150  < carpet.x and \
                        carpet.x < enemy.x-0.7*(carpet.x-350)+(1-(1-enemy.ThisIsRight(carpet.x, carpet)))*150 and \
                        enemy.y-0.7*(carpet.y-350)-175 < carpet.y and carpet.y < enemy.y-0.7*(carpet.y-350)+175:
                        if hero.survive == True and hero.collision == False and enemy.frame == 4:
                            hero.HP-=enemy.power
                            hero.collision = True

        elif stage == 2 :
            for i in range(-1, len(hero.heroSkill1Box)-1):
                #if heroSkill1Box[i] in heroSkill1Box:
                if hero.heroSkill1Box[i].direct == 'UP':
                    if hero.heroSkill1Box[i].y-0.7*(carpet.y-hero.heroSkill1Box[i].carpetY) > 800-0.20*(carpet.y-350) : hero.heroSkill1Box[i].collision = True
                elif hero.heroSkill1Box[i].direct == 'DOWN':
                    if hero.heroSkill1Box[i].y-0.7*(carpet.y-hero.heroSkill1Box[i].carpetY) < -100-0.20*(carpet.y-350) : hero.heroSkill1Box[i].collision = True
                elif hero.heroSkill1Box[i].direct == 'LEFT':
                    if hero.heroSkill1Box[i].x-0.7*(carpet.x-hero.heroSkill1Box[i].carpetX) < -100-0.20*(carpet.x-350) : hero.heroSkill1Box[i].collision = True
                elif hero.heroSkill1Box[i].direct == 'RIGHT':
                    if hero.heroSkill1Box[i].x-0.7*(carpet.x-hero.heroSkill1Box[i].carpetX) > 800-0.20*(carpet.x-350) : hero.heroSkill1Box[i].collision = True
            # superbise_allSkill
            for i in range(-1, len(hero.heroSkillBox)-1):
                for j in range(-1, len(hero.heroSkillBox[i])-1):
                    if hero.heroSkillBox[i][j].collision == False:
                        if enemy.survive == True:
                            if ((enemy.x-0.7*(carpet.x-350)-40 < hero.heroSkillBox[i][j].x-0.7*(carpet.x-hero.heroSkillBox[i][j].carpetX) and \
                                hero.heroSkillBox[i][j].x-0.7*(carpet.x-hero.heroSkillBox[i][j].carpetX) < enemy.x-0.7*(carpet.x-350)+40 and \
                                enemy.y-0.7*(carpet.y-350)-100 < hero.heroSkillBox[i][j].y-0.7*(carpet.y-hero.heroSkillBox[i][j].carpetY) and \
                                hero.heroSkillBox[i][j].y-0.7*(carpet.y-hero.heroSkillBox[i][j].carpetY) < enemy.y-0.7*(carpet.y-350)+100)) or \
                                    ((enemy.x-0.7*(carpet.x-350)-75 < hero.heroSkillBox[i][j].x-0.7*(carpet.x-hero.heroSkillBox[i][j].carpetX) and \
                                hero.heroSkillBox[i][j].x-0.7*(carpet.x-hero.heroSkillBox[i][j].carpetX) < enemy.x-0.7*(carpet.x-350)+75 and \
                                enemy.y-0.7*(carpet.y-350)-40 < hero.heroSkillBox[i][j].y-0.7*(carpet.y-hero.heroSkillBox[i][j].carpetY) and \
                                hero.heroSkillBox[i][j].y-0.7*(carpet.y-hero.heroSkillBox[i][j].carpetY) < enemy.y-0.7*(carpet.y-350)+40)) :
                                hero.heroSkillBox[i][j].collision = True
                                hero.heroSkillBox[i][j].boom()
                                if enemy.state != enemy.NORMAL :  enemy.HP-=(hero.heroSkillBox[i][j].power/enemy.defensive_power)
                                elif enemy.HP < 500:
                                    enemy.HP+=hero.heroSkillBox[i][j].power
                                    if enemy.HP >= 500 : enemy.HP = 500
                                self.score += 1

                        for b in range(-1, len(enemy.ballList)-1):
                            if enemy.ballList[b].survive == True:
                                if i == 0: #첫 번째 스킬이고
                                    if 35 > distance(enemy.ballList[b].x-0.7*(carpet.x-350), enemy.ballList[b].y-0.7*(carpet.y-350), hero.heroSkillBox[i][j].x-0.7*(carpet.x-hero.heroSkillBox[i][j].carpetX),hero.heroSkillBox[i][j].y-0.7*(carpet.y-hero.heroSkillBox[i][j].carpetY)):
                                        hero.heroSkillBox[i][j].boom()
                                        hero.heroSkillBox[i][j].collision = True
                                        enemy.ballList[b].HP-=hero.heroSkillBox[i][j].power
                                        self.score += 1
                                else:
                                    if 40 > distance(enemy.ballList[b].x-0.7*(carpet.x-350), enemy.ballList[b].y-0.7*(carpet.y-350), hero.heroSkillBox[i][j].x-0.7*(carpet.x-hero.heroSkillBox[i][j].carpetX),hero.heroSkillBox[i][j].y-0.7*(carpet.y-hero.heroSkillBox[i][j].carpetY)):
                                        hero.heroSkillBox[i][j].boom()
                                        hero.heroSkillBox[i][j].collision = True
                                        enemy.ballList[b].HP-=hero.heroSkillBox[i][j].power
                                        self.score += 1


            # enemy2 razer
            for i in range(-1, len(enemy.enemy2RazerBox)-1):
                #if enemy2RazerBox[i] in enemy2RazerBox:
                if (enemy.enemy2RazerBox[i].y-0.7*(carpet.y-enemy.enemy2RazerBox[i].carpetY) > 800-0.20*(carpet.y-350) or \
                    enemy.enemy2RazerBox[i].y-0.7*(carpet.y-enemy.enemy2RazerBox[i].carpetY) < -100-0.20*(carpet.y-350) or \
                    enemy.enemy2RazerBox[i].x-0.7*(carpet.x-enemy.enemy2RazerBox[i].carpetX) < -100-0.20*(carpet.x-350) or \
                    enemy.enemy2RazerBox[i].x-0.7*(carpet.x-enemy.enemy2RazerBox[i].carpetX) > 800-0.20*(carpet.x-350)) and enemy.enemy2RazerBox[i].collision == False:
                    enemy.enemy2RazerBox[i].collision = True
            for i in range(-1, len(enemy.enemy2RazerBox)-1):
                if enemy.enemy2RazerBox[i].collision == False:
                    for j in range(-1, len(self.hostageList)-1):
                        if 20 > distance(350+self.hostageList[j].x-0.20*(carpet.x-350), 350+self.hostageList[j].y-0.20*(carpet.y-350), enemy.enemy2RazerBox[i].x-0.7*(carpet.x-enemy.enemy2RazerBox[i].carpetX), enemy.enemy2RazerBox[i].y-0.7*(carpet.y-enemy.enemy2RazerBox[i].carpetY) ) and \
                            self.hostageList[j].survive == True:
                            self.hostageList[j].survive = False
                            if self.combo_flag == True:
                                self.combo_flag = False
                                self.combo_score_show_time = 15
                                self.score += self.combo_score
                                self.combo_score_degree = self.combo_score
                                self.combo_score = 0
                            self.hostageList[j].frame = 0
                            self.hostageList[j].aniDelay = 0
                    if 20 > distance(enemy.enemy2RazerBox[i].x-0.7*(carpet.x-enemy.enemy2RazerBox[i].carpetX), enemy.enemy2RazerBox[i].y-0.7*(carpet.y-enemy.enemy2RazerBox[i].carpetY), hero.x+carpet.x, hero.y+carpet.y) \
                            and hero.survive == True:
                        hero.HP-=enemy.enemy2RazerBox[i].power
                        enemy.enemy2RazerBox[i].collision = True

            # ball razer
            for i in range(-1, len(ballRazerBox)-1):
                if ballRazerBox[i].collision == False:
                #if ballRazerBox[i] in ballRazerBox:
                    if ballRazerBox[i].y-0.7*(carpet.y-ballRazerBox[i].carpetY) > 800-0.20*(carpet.y-350) or \
                        ballRazerBox[i].y-0.7*(carpet.y-ballRazerBox[i].carpetY) < -100-0.20*(carpet.y-350) or \
                        ballRazerBox[i].x-0.7*(carpet.x-ballRazerBox[i].carpetX) < -100-0.20*(carpet.x-350) or \
                        ballRazerBox[i].x-0.7*(carpet.x-ballRazerBox[i].carpetX) > 800-0.20*(carpet.x-350) :
                        ballRazerBox[i].collision = True
                    if 15 > distance(ballRazerBox[i].x-0.7*(carpet.x-ballRazerBox[i].carpetX), ballRazerBox[i].y-0.7*(carpet.y-ballRazerBox[i].carpetY), hero.x+carpet.x, hero.y+carpet.y) \
                            and hero.survive == True:
                        hero.HP-=ballRazerBox[i].power
                        ballRazerBox[i].collision = True
                    #for i in range(-1, len(ballRazerBox)-1):
                for j in range(-1, len(self.hostageList)-1):
                    if 15 > distance(350+self.hostageList[j].x-0.20*(carpet.x-350), 350+self.hostageList[j].y-0.20*(carpet.y-350), ballRazerBox[i].x-0.7*(carpet.x-ballRazerBox[i].carpetX), ballRazerBox[i].y-0.7*(carpet.y-ballRazerBox[i].carpetY) ) and \
                        self.hostageList[j].survive == True:
                        self.hostageList[j].survive = False
                        if self.combo_flag == True:
                            self.combo_flag = False
                            self.combo_score_show_time = 15
                            self.score += self.combo_score
                            self.combo_score_degree = self.combo_score
                            self.combo_score = 0
                        self.hostageList[j].frame = 0
                        self.hostageList[j].aniDelay = 0

    def __init__(self):
        if UI.rescue_sound == None:
            UI.rescue_sound = load_wav('sound/UI/rescue.ogg')
            UI.rescue_sound.set_volume(32)
        if UI.ultra_bonus_sound == None:
            UI.ultra_bonus_sound = load_wav('sound/UI/ultra_bonus.ogg')
            UI.ultra_bonus_sound.set_volume(32)
        if UI.magic_swap_sound == None:
            UI.magic_swap_sound = load_wav('sound/UI/magic_swap.ogg')
            UI.magic_swap_sound.set_volume(32)
        self.UITitle = load_image('UI/UITitle.png')
        self.gameover = load_image('UI/gameover.png')
        ui_data_file = open('UI/UI.txt', 'r')
        self.ui_data = json.load(ui_data_file)
        if UI.font == None : UI.font = load_font('ENCR10B.TTF')
        ui_data_file.close()
        #인질 리스트
        self.hostageList=[]
        self.delay_create_hostage = 0
        self.hostage_num = 0
        self.save_num = 0
        self.HP_buff_show_time = 0
        self.HP_buff_degree = 0
        self.point_show_time = 0
        self.point_degree = 0
        self.king_state = 'NOT'
        self.queen_state = 'NOT'

        self.score = 0
        self.combo_flag = False
        self.combo_score = 0
        self.combo_score_show_time = 0
        self.combo_score_degree = 0
        self.ultra_score = 5000
        self.ultra_score_show_time = 0
        self.kq_all_rescue_flag = False

    def rescue_hostage(self):
        UI.rescue_sound.play()
    def get_ultra_bonus(self):
        UI.ultra_bonus_sound.play()
    def magic_swap(self):
        UI.magic_swap_sound.play()
    def update(self, hero):
        if hero.survive == True : self.score += 1
        if self.kq_all_rescue_flag == False:
            if self.king_state == 'SAVE' and self.queen_state == 'SAVE':
                self.ultra_bonus_sound()
                self.ultra_score_show_time = self.ULTRA_SCORE_SHOW_TIME
                self.score += self.ultra_score
                self.kq_all_rescue_flag = True


    def draw(self, hero, carpet, enemy, stage):
        global HP_buff_show_time
        global point_show_time
        global combo_score_show_time
        global combo_score_degree
        global ultra_score
        global ultra_score_show_time
        self.UITitle.draw(UI.INIT_X, UI.INIT_Y)
        self.ScoreInform(self.ui_data['Score']['x'], self.ui_data['Score']['y'], self.ui_data['Score']['ctrlY'],\
                        (self.ui_data['Score']['R'], self.ui_data['Score']['G'], self.ui_data['Score']['B']))
        if self.point_show_time > 0 :
            self.font.draw(hero.x + carpet.x - 50, hero.y + carpet.y +40+40/(self.point_show_time+1), 'POINT +%d'%self.point_degree, (100,200,100))
            self.point_show_time -= 1
        if self.combo_score_show_time > 0 :
            self.font.draw(hero.x + carpet.x - 100, hero.y + carpet.y +40+40/(self.combo_score_show_time+1), 'RESCUE BONUS +%d'%self.combo_score_degree , (200,100,200))
            self.combo_score_show_time -= 1
        if self.ultra_score_show_time > 0 :
            self.font.draw(hero.x + carpet.x - 90, hero.y + carpet.y +40+40/(self.ultra_score_show_time+1), 'ULTRA BONUS +%d'%self.ultra_score  , (250,250,100))
            self.ultra_score_show_time -= 1
        # self.CurrentStage(self.ui_data['CurrentStage']['x'], self.ui_data['CurrentStage']['y'], self.ui_data['CurrentStage']['ctrlY'],\
        #                   (self.ui_data['CurrentStage']['R'], self.ui_data['CurrentStage']['G'], self.ui_data['CurrentStage']['B']), 2)
        self.EnemyState(self.ui_data['EnemyState']['x'], self.ui_data['EnemyState']['y'], self.ui_data['EnemyState']['ctrlY'],\
                         (self.ui_data['EnemyState']['R'], self.ui_data['EnemyState']['G'], self.ui_data['EnemyState']['B']), enemy, stage)
        self.HeroState(self.ui_data['HeroState']['x'], self.ui_data['HeroState']['y'], self.ui_data['HeroState']['ctrlY'],\
                       (self.ui_data['HeroState']['R'], self.ui_data['HeroState']['G'], self.ui_data['HeroState']['B']), hero)
        self.RescueInform(self.ui_data['RescueInform']['x'], self.ui_data['RescueInform']['y'], self.ui_data['RescueInform']['ctrlY'],\
                          (self.ui_data['RescueInform']['R'], self.ui_data['RescueInform']['G'], self.ui_data['RescueInform']['B']))
        if self.HP_buff_show_time > 0 :
            self.font.draw(hero.x + carpet.x - 30, hero.y + carpet.y +20+20/(self.HP_buff_show_time+1), 'HP +%d'%self.HP_buff_degree, (200,100,100))
            self.HP_buff_show_time -= 1
        if hero.survive == False : self.gameover.draw(UI.DISPLAY_CENTER_X, UI.DISPLAY_CENTER_Y)