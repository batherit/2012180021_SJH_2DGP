import game_framework
from simple_math_tool import *
from hero import Hero
from map import Map
from carpet import Carpet
from UI import UI
from enemy1 import Enemy1

import random
import json
import stage2_gap
import stage1_gap
from pico2d import *


#주인공의 공격 상태
enumerate(['NORAML', 'ATTACK' ])
#주인공의 공격 방향
enumerate(['DEFAULT','LEFT, RIGHT, UP, DOWN'])
#주인공의 공격 타입
enumerate(['SKILL1, SKILL2, SKILL3'])
#왕과 왕비 구출 상태
enumerate(['NOT', 'SAVE']) #APPEAR, DIE 추가 예정


def handle_events(): #플래그에 한 순간 영향받는 변수 처리
    global running
    global carpet
    global hero
    global ui

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_ESCAPE: running = False
            # 마법 타입이 바뀔 수 있는 유일한 부분.l
            if event.key == SDLK_LSHIFT or event.key == SDLK_RSHIFT:
                ui.magic_swap()
                hero.skill1Delay = 0
                hero.skill2Delay = 0
                if hero.skillType == 'SKILL1' : hero.skillType = 'SKILL2'
                elif hero.skillType == 'SKILL2' : hero.skillType = 'SKILL3'
                elif hero.skillType == 'SKILL3' : hero.skillType = 'SKILL1'
            if event.key == SDLK_d: carpet.goToRight = True
            if event.key == SDLK_a: carpet.goToLeft = True
            if event.key == SDLK_w: carpet.goToUp = True
            if event.key == SDLK_s: carpet.goToDown = True
            # 주인공의 공격 방향 설정 및 공격을 수행한다.
            if event.key == SDLK_i or event.key == SDLK_k or event.key ==SDLK_j or event.key == SDLK_l:
                if event.key == SDLK_i : hero.attackDirect = 'UP'
                if event.key == SDLK_k : hero.attackDirect = 'DOWN'
                if event.key == SDLK_j : hero.attackDirect = 'LEFT'
                if event.key == SDLK_l : hero.attackDirect = 'RIGHT'
                # hero.state는 공격 모션, 마법 탄환 생성에 영향을 준다.
                hero.state = 'ATTACK'
                hero.delay = 0
                hero.frame = 0
            if event.key == SDLK_SPACE :
                if enemy1.delete == True:
                    game_framework.change_state(stage2_gap)
                elif hero.delete == True:
                    game_framework.change_state(stage1_gap)
        elif event.type == SDL_KEYUP:
            if event.key == SDLK_d: carpet.goToRight = False
            if event.key == SDLK_a: carpet.goToLeft = False
            if event.key == SDLK_w: carpet.goToUp = False
            if event.key == SDLK_s: carpet.goToDown = False
            if event.key == SDLK_i or event.key == SDLK_k or event.key ==SDLK_j or event.key == SDLK_l:
                hero.attackDirect = 'DEFAULT'
                hero.state = 'NORMAL'
                hero.skill1Delay = 0
                hero.attackAniFlag = 0
                hero.delay = 0
                hero.frame = 0
            pass
        #공격 키 간에 동기화가 필요해보인다.

#UI 관련 클래스
ui = None

#맵 관련 클래스
map = None

#주인공 관련 클래스
hero = None                       #주인공 인스턴스
#양탄자 관련 클래스
carpet = None

#enemy1 클래스
enemy1 = None

#running = True;

#리팩토링
def enter():

    global map
    global ui
    global hero
    global carpet
    global enemy1


    map = Map()
    ui = UI()
    hero = Hero()
    carpet = Carpet()
    enemy1 = Enemy1()


def exit():
    global map
    global ui
    global hero
    global carpet
    global enemy1
    global font

    while(len(hero.heroSkill1Box)):
        del hero.heroSkill1Box[0]
    del hero.heroSkill1Box
    while(len(hero.heroSkill2Box)):
        del hero.heroSkill2Box[0]
    del hero.heroSkill2Box
    while(len(hero.heroSkill3Box)):
        del hero.heroSkill3Box[0]
    del hero.heroSkill3Box
    del hero.heroSkillBox

    while(len(enemy1.enemy1SickleWindList)):
         del enemy1.enemy1SickleWindList[0]
    while(len(enemy1.enemy1RazerBox)):
        del enemy1.enemy1RazerBox[0]

    while(len(ui.hostageList)):
        del ui.hostageList[0]

    del(map)
    del(ui)
    del(hero)
    del(carpet)
    del (enemy1)



def update():
    ui.update(hero)
    carpet.update()
    hero.update(carpet)
    enemy1.update(carpet)
    for sickleWind in enemy1.enemy1SickleWindList:
        sickleWind.update()
    for skill1 in hero.heroSkill1Box:
        skill1.update()
    for skill3 in hero.heroSkill3Box:
        skill3.update()
    for razer in enemy1.enemy1RazerBox:
        razer.update()
    for hostage in ui.hostageList:
        hostage.update()
    ui.supervise_bullet(hero, carpet, enemy1, 1 , None)
    ui.supervise_hostage(hero, carpet, enemy1, ui)

    #delay(0.005)


def draw():

    global carpet
    clear_canvas()
    map.draw(carpet)
    carpet.draw()
    hero.draw(carpet)
    for hostage in ui.hostageList:
        hostage.draw(carpet, ui)
    for razer in enemy1.enemy1RazerBox:
        razer.draw(enemy1, carpet)
    enemy1.draw(carpet.x, carpet, ui)
    for sickleWind in enemy1.enemy1SickleWindList:
        sickleWind.draw(carpet.x, carpet.y, enemy1)
    for skill1 in hero.heroSkill1Box:
        skill1.draw(hero, carpet)
    for skill2 in hero.heroSkill2Box:
        skill2.draw(hero, carpet ,enemy1, ui,1)
    for skill3 in hero.heroSkill3Box:
        skill3.draw(hero, carpet)

    ui.draw(hero, carpet, enemy1, 1)

    update_canvas()


