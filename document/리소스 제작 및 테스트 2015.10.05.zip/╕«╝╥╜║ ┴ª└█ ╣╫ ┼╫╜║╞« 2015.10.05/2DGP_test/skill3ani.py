from pico2d import *
open_canvas(800,60)
skill3_1=load_image('skill3_1.png')
skill3_2=load_image('skill3_2.png')

x=0
frame1 = 0
frame2 = 0
fFlag = 0
while (x<500):
    clear_canvas()
    if fFlag == 0:
        skill3_1.clip_draw(0, 360-frame1*60, 800,60, 400,30)
        frame1 = (frame1+1)%7
        if frame1 == 0:
            fFlag = 1-fFlag
    else:
        skill3_2.clip_draw(0, 360-frame2*60, 800,60, 400,30)
        frame2 = (frame2+1)%7
        if frame2 == 0:
            fFlag = 1-fFlag
    update_canvas()

    x+=1
    delay(0.05)
    get_events()

close_canvas()