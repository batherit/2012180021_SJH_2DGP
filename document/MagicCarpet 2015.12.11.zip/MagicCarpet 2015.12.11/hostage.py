#인질 클래스
import random
from pico2d import *



class Hostage:

    #king, queen, butler, knight, clergy, slave1, slave2 = None, None, None, None, None, None, None
    hostage_set = None
    hostageDie = None
    hostage_data = None
    KING, BUTLER, KNIGHT, CLERGY, SLAVE1, SLAVE2, QUEEN = 0, 1, 2, 3, 4, 5, 6
    SPAN_POSITION = 375
    GUARD_MAX, GUARD_MIN = 350, -350
    MAP_CENTER_X, MAP_CENTER_Y = 350, 350
    UP, DOWN, LEFT, RIGHT = 0, 1, 2, 3
    #왕과 왕비는 한 스테이지에 한 번밖에 등장하지 않는다.
    #스테이지가 바뀌면 아래 두 클래스 변수는 0으로 초기화된다.
    #supervise_hostage에서 관리한다.
    king_appearance, queen_appearance = 0, 0

    hostage_position = {
        KING : 'KING',
        BUTLER : 'BUTLER',
        KNIGHT : 'KNIGHT',
        CLERGY : 'CLERGY',
        SLAVE1 : 'SLAVE1' ,
        SLAVE2 : 'SLAVE2',
        QUEEN : 'QUEEN'
    }

    def __init__(self):
        if Hostage.hostage_set == None : Hostage.hostage_set = load_image('hostage/hostage_set.png')
        if Hostage.hostageDie == None : Hostage.hostageDie = load_image('hostage/hostage_die.png')
        if Hostage.hostage_data == None :
            hostage_data_file = open('hostage/hostage_data.txt', 'r')
            Hostage.hostage_data = json.load(hostage_data_file)
            hostage_data_file.close()

        self.frame = 0
        self.aniDelay = 0
        self.x = 0
        self.y = 0
        self.HP_buff = 0
        self.guardMax = Hostage.GUARD_MAX
        self.guardMin = Hostage.GUARD_MIN
        self.turnFlag=random.randint(0, 1)
        self.velocity = random.randint(1, 2)
        self.position = random.randint(0+Hostage.king_appearance,100-Hostage.queen_appearance)
        self.direct = random.randint(0,3)
        self.survive = True

        if self.direct == self.UP : self.y += Hostage.SPAN_POSITION
        elif self.direct == self.DOWN : self.y -= Hostage.SPAN_POSITION
        elif self.direct == self.LEFT : self.x -= Hostage.SPAN_POSITION
        elif self.direct == self.RIGHT : self.x += Hostage.SPAN_POSITION
        self.point = 0

        if -1 < self.position and self.position < 1:
            self.position = self.KING
            Hostage.king_appearance = 1
        elif 0 < self.position and self.position < 11 : self.position = self.BUTLER
        elif 10 < self.position and self.position < 17 : self.position = self.KNIGHT
        elif 16 < self.position and self.position < 21 : self.position = self.CLERGY
        elif 20 < self.position and self.position < 100 : self.position = random.randint(self.SLAVE1, self.SLAVE2)
        elif 99 < self.position and self.position < 101:
            self.position = self.QUEEN
            Hostage.queen_appearance = 1
        self.point = Hostage.hostage_data[self.hostage_position[self.position]]['point']
        self.HP_buff = Hostage.hostage_data[self.hostage_position[self.position]]['HP_buff']
        self.life = True

    def update(self):
        if self.survive == True:
            if self.direct == self.UP or self.direct == self.DOWN:
                if self.turnFlag == 1:
                    self.x += self.velocity
                    if self.x > self.guardMax:
                        self.x=self.guardMax
                        self.guardMin=random.randint(Hostage.GUARD_MIN, self.x)
                        self.turnFlag = 0
                elif self.turnFlag == 0:
                    self.x -= self.velocity
                    if self.x < self.guardMin:
                        self.x=self.guardMin
                        self.guardMax=random.randint(self.x, Hostage.GUARD_MAX)
                        self.turnFlag = 1

            elif self.direct  == self.LEFT or self.direct  == self.RIGHT:
                if self.turnFlag == 1:
                    self.y += self.velocity
                    if self.y > self.guardMax:
                        self.y=self.guardMax
                        self.guardMin=random.randint(Hostage.GUARD_MIN, self.y)
                        self.turnFlag = 0
                elif self.turnFlag == 0:
                    self.y -= self.velocity
                    if self.y < self.guardMin:
                        self.y=self.guardMin
                        self.guardMax=random.randint(self.y, Hostage.GUARD_MAX)
                        self.turnFlag = 1
        else : pass
    def draw(self, carpet, ui):
        global hostage_num
        self.aniDelay +=1
        if self.survive == True:
            self.hostage_set.clip_draw(self.frame*40, self.position*40, 40,40, Hostage.MAP_CENTER_X+self.x-0.20*(carpet.x-Hostage.MAP_CENTER_X), Hostage.MAP_CENTER_Y+self.y-0.20*(carpet.y-Hostage.MAP_CENTER_Y))
            if self.aniDelay == 30 :
                self.frame = (self.frame+1)%2
                self.aniDelay=0
        elif self.survive == False:
            self.hostageDie.clip_draw(self.frame*40, 0, 40,40, Hostage.MAP_CENTER_X+self.x-0.20*(carpet.x-Hostage.MAP_CENTER_X), Hostage.MAP_CENTER_Y+self.y-0.20*(carpet.y-Hostage.MAP_CENTER_Y))
            if self.aniDelay == 10:
                self.frame = (self.frame+1)%12
                self.aniDelay = 0
                if self.frame == 0:
                    for i in range(-1, len(ui.hostageList)-1):
                        if self == ui.hostageList[i]:
                            del ui.hostageList[i]
                            ui.hostage_num-=1
                            break