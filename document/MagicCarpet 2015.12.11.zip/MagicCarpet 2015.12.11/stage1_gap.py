import game_framework
import title_state
import stage1
from pico2d import *

name = "STAGE1GAP"
image = None
logo_time = 0.0

def enter():
    global image
    image = load_image('UI/Stage1.png')

def exit():
    global image
    del(image)

def update():
    global logo_time

    if (logo_time > 0.5):
        logo_time = 0
        game_framework.change_state(stage1)
    delay(0.01)
    logo_time += 0.01

def draw():
    global image
    clear_canvas()
    image.draw(450, 350)
    update_canvas()

def handle_events():
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()

def pause(): pass
def resume(): pass