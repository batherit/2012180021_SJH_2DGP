from pico2d import *
import random
from simple_math_tool import *

class Ball:

    spanAni = None
    ball = None
    boom = None
    electric_shock = None

    NORMAL = 0
    MAP_CENTER_X, MAP_CENTER_Y = 350, 350

    def ball_normal(self, carpet, enemy2, ballRazerBox):        #enemy2의 평범한 움직임
        if self.move_count == 4:
            if self.frame == 0:     #self.aniDelay == 0 인 상태
                self.state = self.NORMAL #차후 추가되면 랜덤으로 패턴을 돌린다.
                self.move_flag = False
                self.move_count = 0
        else :
            if self.move_flag == False:
                if self.attack_start == False:
                    self.move_delay+=1
                    if self.move_delay == 50:
                        self.carpetX=carpet.x
                        self.carpetY=carpet.y
                        self.course = random.randint(0, 2)
                        if self.course==0:
                            self.endX = carpet.x
                            self.endY = carpet.y
                            self.angle = angle(self.x-0.7*(carpet.x-Ball.MAP_CENTER_X), self.y-0.7*(carpet.y-Ball.MAP_CENTER_Y), self.endX, self.endY)
                        elif self.course==1:
                            self.angle=angle(carpet.x, carpet.y, self.x-0.7*(carpet.x-Ball.MAP_CENTER_X), self.y-0.7*(carpet.y-Ball.MAP_CENTER_Y))+random.randint(-90,90)
                            self.endX = self.carpetX+100*math.cos(math.pi/180*self.angle)
                            self.endY = self.carpetY+100*math.sin(math.pi/180*self.angle)
                            self.angle=angle( self.x-0.7*(self.carpetX-Ball.MAP_CENTER_X), self.y-0.7*(self.carpetY-Ball.MAP_CENTER_Y),self.endX, self.endY)
                        elif self.course==2:
                            self.angle=angle(carpet.x, carpet.y, enemy2.x-0.7*(carpet.x-Ball.MAP_CENTER_X), enemy2.y-0.7*(carpet.y-Ball.MAP_CENTER_Y))+random.randint(-45, 45)
                            self.around_r = random.randint(200, 300)
                            self.endX = enemy2.x-0.7*(self.carpetX-Ball.MAP_CENTER_X)+self.around_r*math.cos(math.pi/180*self.angle)
                            self.endY = enemy2.y-0.7*(self.carpetY-Ball.MAP_CENTER_Y)+self.around_r*math.sin(math.pi/180*self.angle)
                            self.angle = angle( self.x-0.7*(self.carpetX-Ball.MAP_CENTER_X), self.y-0.7*(self.carpetY-Ball.MAP_CENTER_Y),self.endX, self.endY)
                        self.move_flag = True
                        self.move_delay = 0
                else: #self.attack_start
                    self.attack_delay +=1
                    if self.attack_delay == self.attack_ding: #공격 입력
                        if self.attack_type == 0:
                            ballRazerBox.append(BallRazer(angle(self.x-0.7*(carpet.x-Ball.MAP_CENTER_X), self.y-0.7*(carpet.y-Ball.MAP_CENTER_Y), carpet.x, carpet.y), self.x-0.7*(carpet.x-Ball.MAP_CENTER_X),self.y-0.7*(carpet.y-Ball.MAP_CENTER_Y), carpet))
                        elif self.attack_type == 1:
                            for i in range(0, 20):
                                ballRazerBox.append(BallRazer(360/20*i+45*(self.attack_count%2), self.x-0.7*(carpet.x-Ball.MAP_CENTER_X),self.y-0.7*(carpet.y-Ball.MAP_CENTER_Y), carpet))
                        elif self.attack_type == 2:
                            for i in range(0, 5):
                                ballRazerBox.append(BallRazer(angle(self.x-0.7*(carpet.x-Ball.MAP_CENTER_X), self.y-0.7*(carpet.y-Ball.MAP_CENTER_Y), carpet.x, carpet.y)+random.randint(-30, 30), self.x-0.7*(carpet.x-Ball.MAP_CENTER_X),self.y-0.7*(carpet.y-Ball.MAP_CENTER_Y), carpet))
                        self.attack_count+=1
                        self.attack_delay = 0
                    if self.attack_count == self.attack_count_max:
                        self.attack_start = False
                        self.move_count+=1
                        self.attack_count=0
            elif self.move_flag == True:
                if (self.endX-20 < self.x-0.7*(self.carpetX-Ball.MAP_CENTER_X) and self.x-0.7*(self.carpetX-Ball.MAP_CENTER_X)< self.endX+20) \
                         and (self.endY-20 < self.y-0.7*(self.carpetY-Ball.MAP_CENTER_Y) and self.y-0.7*(self.carpetY-Ball.MAP_CENTER_Y)< self.endY+20):
                    self.move_flag = False
                    self.attack_start = True
                    self.attack_type = random.randint(0, 2)
                    if self.attack_type == 0:
                        self.attack_ding = 15
                        self.attack_count_max = 5
                    elif self.attack_type == 1:
                        self.attack_ding = 15
                        self.attack_count_max = 3
                    elif self.attack_type == 2:
                        self.attack_ding = 10
                        self.attack_count_max = 2
                else:
                    if self.survive == True:
                        self.x += self.velocity*math.cos(math.pi/180*self.angle)
                        self.y += self.velocity*math.sin(math.pi/180*self.angle)
    ball_state = {
        NORMAL : ball_normal
    }

    def __init__(self, enemy, carpet):
        if Ball.spanAni == None : Ball.spanAni = load_image('enemy2/enemy2ballspan.png')
        if Ball.ball == None: Ball.ball = load_image('enemy2/enemy2ball.png')
        if Ball.boom == None: Ball.boom = load_image('enemy2/enemy2boom.png')
        if Ball.electric_shock == None: Ball.electric_shock = load_image('hero/heroSkill/skill2boom.png')
        self.x = enemy.skillX
        self.y = enemy.skillY
        self.carpetX = carpet.x
        self.carpetY = carpet.y
        self.span = False
        self.survive = False
        self.boom_flag = False
        self.move_count = 0
        self.move_flag = False
        self.move_delay = 0
        self.endX = 0
        self.endY = 0
        self.angle = 0.0
        self.course = 0
        self.state = self.NORMAL
        self.attack_start = False
        self.attack_type = 0
        self.attack_count = 0
        self.attack_count_max = 0
        self.attack_delay = 0
        self.attack_ding = 0
        self.velocity = 3
        self.around_r = 0
        self.aniDelay = 0
        self.ding = 5
        self.frame = 0
        self.HP= 60
        self.electric_shock_flag = False
        self.electric_shock_frame = 0
        self.electric_shock_aniDelay = 0
    def update(self, carpet, enemy2, ballRazerBox):
        if self.HP <= 0: self.survive = False
        if self.survive == True : self.ball_state[self.state](self, carpet, enemy2, ballRazerBox)

    def draw(self, carpet, enemy2):
        self.aniDelay += 1
        if self.span == False : self.spanAni.clip_draw(self.frame*50, 0, 50,50, self.x-0.7*(carpet.x-Ball.MAP_CENTER_X), self.y-0.7*(carpet.y-Ball.MAP_CENTER_Y))
        else:
            if self.survive == True : self.ball.clip_draw(0, 0, 40,40, self.x-0.7*(carpet.x-Ball.MAP_CENTER_X), self.y-0.7*(carpet.y-Ball.MAP_CENTER_Y))
            else: self.boom.clip_draw(self.frame*100, 0, 100,100, self.x-0.7*(carpet.x-Ball.MAP_CENTER_X), self.y-0.7*(carpet.y-Ball.MAP_CENTER_Y))

        if self.aniDelay == 5 :
            if self.survive != True: self.frame = (self.frame+1)%8
            if self.span == False and self.frame == 0:
                self.span = True
                self.survive = True
            else:
                if self.survive == False and self.frame == 0:
                    for i in range(-1, len(enemy2.ballList)-1):
                        if self == enemy2.ballList[i]:
                            del enemy2.ballList[i]
                            break
            self.aniDelay=0
        if self.electric_shock_flag == True:
            self.electric_shock_aniDelay+=1
            self.electric_shock.clip_draw(self.electric_shock_frame*50, 0, 50,50, self.x-0.7*(carpet.x-Ball.MAP_CENTER_X), self.y-0.7*(carpet.y-Ball.MAP_CENTER_Y))
            if self.electric_shock_aniDelay == 3:
                self.electric_shock_frame=(self.electric_shock_frame+1)%9
                self.electric_shock_aniDelay=0
                if self.electric_shock_frame == 0: self.electric_shock_flag = False

class BallRazer:

    razer = None

    def __init__(self, angle, x, y, carpet):
        if BallRazer.razer == None:
            BallRazer.razer = load_image('enemy2/ballrazer.png')
        self.x = x
        self.y = y
        self.angle = angle
        self.collision = False
        self.carpetX = carpet.x
        self.carpetY = carpet.y
        self.velocity = 3
        self.acceleration = 0
        self.power=20
        self.slope = 0
    def update(self):
        if self.collision == False:
            self.acceleration+=0.01
            self.slope+=1
            self.x += self.velocity*self.acceleration*math.cos(math.pi/180*(self.angle))
            self.y += self.velocity*self.acceleration*math.sin(math.pi/180*(self.angle))

    def draw(self, carpet, ballRazerBox):
        if self.collision == False : self.razer.clip_draw(0, 0, 15,15, self.x-0.7*(carpet.x-self.carpetX), self.y-0.7*(carpet.y-self.carpetY))
        else:
            for i in range(-1, len(ballRazerBox)-1):
                if self == ballRazerBox[i]:
                    del ballRazerBox[i]
                    break