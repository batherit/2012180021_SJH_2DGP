from pico2d import *
from simple_math_tool import *
from enemy2_skill import *
from ball import *
import random

#enemy2 클래스
class Enemy2:

    enemy2img = None
    enemy2die = None
    electric_shock = None

    NORMAL, ENEMY2_PATTERN1, ENEMY2_PATTERN2, ENEMY2_PATTERN3  = 0, 1, 2, 3

    def enemy2_normal(self, carpet):        #enemy2의 평범한 움직임
        if self.move_count == 2:
            if self.frame == 0:     #self.aniDelay == 0 인 상태
                self.state = random.randint(0,3) #차후 추가되면 랜덤으로 패턴을 돌린다.
                self.move_flag = False
                self.move_count = 0
        else :
            if self.move_flag == False:
                self.move_delay+=1
                if self.move_delay == 100:
                    self.endX = carpet.x
                    self.endY = carpet.y
                    self.angle = angle(self.x-0.7*(carpet.x-350), self.y-0.7*(carpet.y-350), self.endX, self.endY)
                    self.move_flag = True
                    self.move_delay = 0
            elif self.move_flag == True:
                if (self.endX-15 < self.x-0.7*(self.endX-350) and self.x-0.7*(self.endX-350)< self.endX+15) \
                        and (self.endY-15 < self.y-0.7*(self.endY-350) and self.y-0.7*(self.endY-350)< self.endY+15) :
                    self.move_flag = False
                    self.move_count+=1
                else:
                    self.x += 4*math.cos(math.pi/180*self.angle)
                    self.y += 4*math.sin(math.pi/180*self.angle)

    def enemy2_pattern1(self, carpet):
        if self.move_count == 3:
            if self.frame == 0:     #self.aniDelay == 0 인 상태
                self.state = random.randint(0,3)#차후 추가되면 랜덤으로 패턴을 돌린다.
                self.move_flag = False
                self.move_count = 0
        else:
            if self.move_flag == False:    #초기 위치값 지정
                if self.attack_ready == False:
                    self.around_r= random.randint(180,200)
                    self.angle=angle(carpet.x, carpet.y, self.x-0.7*(carpet.x-350), self.y-0.7*(carpet.y-350))+random.randint(-90,90)
                    self.carpetX=carpet.x
                    self.carpetY=carpet.y
                    self.endX = self.carpetX+self.around_r*math.cos(math.pi/180*self.angle)
                    self.endY = self.carpetY+self.around_r*math.sin(math.pi/180*self.angle)
                    self.angle=angle( self.x-0.7*(self.carpetX-350), self.y-0.7*(self.carpetY-350),self.endX, self.endY)
                    self.move_flag = True
                elif self.attack_ready == True: #공격을 준비
                    if self.attack_flag == False:
                        if self.frame == 3: #공격 모션을 취하는 애니메이션 프레임 컷이 될 때까지 대기
                            self.attack_flag = True
                    elif self.attack_flag == True: #공격 시작
                        self.attack_flag = False
                        for i in range(-10,10):
                            self.razer_angle= angle(self.x-0.7*(carpet.x-350), self.y-0.7*(carpet.y-350), carpet.x, carpet.y)+i*18
                            self.enemy2RazerBox.append(Enemy2Razer(self, carpet))
                        self.move_count+=1
            elif self.move_flag == True:    #이동한다.
                if (self.endX-20 < self.x-0.7*(self.carpetX-350) and self.x-0.7*(self.carpetX-350)< self.endX+20) \
                        and (self.endY-20 < self.y-0.7*(self.carpetY-350) and self.y-0.7*(self.carpetY-350)< self.endY+20) :
                    if self.frame == 0:  #프레임이 0이 될 때까지 대기
                        self.move_flag = False
                        self.attack_ready = True #멈췄다면 공격 준비 상태로 설정.
                        self.defensive_power = 1
                else:
                    self.x += 4*math.cos(math.pi/180*self.angle)
                    self.y += 4*math.sin(math.pi/180*self.angle)

    def enemy2_pattern2(self, carpet):
        if self.move_count == 5:
            if self.frame == 0:     #self.aniDelay == 0 인 상태
                self.state = random.randint(0,3) #차후 추가되면 랜덤으로 패턴을 돌린다.
                self.move_flag = False
                self.move_count = 0
        else:
            if self.move_flag == False:    #초기 위치값 지정
                if self.attack_ready == False:
                    self.carpetX=carpet.x
                    self.carpetY=carpet.y
                    self.endX = 350-0.7*(self.carpetX-350)
                    self.endY = 350-0.7*(self.carpetY-350)
                    self.angle=angle( self.x-0.7*(self.carpetX-350), self.y-0.7*(self.carpetY-350),self.endX, self.endY)
                    self.move_flag = True
                elif self.attack_ready == True: #공격을 준비
                    if self.attack_flag == False:
                        if self.frame == 3: #공격 모션을 취하는 애니메이션 프레임 컷이 될 때까지 대기
                            self.attack_flag = True
                    elif self.attack_flag == True: #공격 시작
                        #self.around_r= 50*(random.randint(0,4))+150
                        self.around_r=distance(carpet.x, carpet.y, self.x-0.7*(carpet.x-350), self.y-0.7*(carpet.y-350))+random.randint(-3, 3)
                        for j in range(1,4):
                            for i in range(0,30):
                                self.skillX = self.x-0.7*(carpet.x-350)+(self.around_r+(j-2)*80)*math.cos(math.pi/180*(i*360/30+6*(j%2)))
                                self.skillY = self.y-0.7*(carpet.y-350)+(self.around_r+(j-2)*80)*math.sin(math.pi/180*(i*360/30+6*(j%2)))
                                self.enemy2BombBox.append(Bomb(carpet, self))
                        self.attack_flag = False
                        self.move_count+=1
            elif self.move_flag == True:    #이동한다.
                if (self.endX-20 < self.x-0.7*(self.carpetX-350) and self.x-0.7*(self.carpetX-350)< self.endX+20) \
                        and (self.endY-20 < self.y-0.7*(self.carpetY-350) and self.y-0.7*(self.carpetY-350)< self.endY+20) :
                    if self.frame == 0:  #프레임이 0이 될 때까지 대기
                        self.move_flag = False
                        self.attack_ready = True #멈췄다면 공격 준비 상태로 설정.
                        self.defensive_power = 1
                else:
                    self.x += 4*math.cos(math.pi/180*self.angle)
                    self.y += 4*math.sin(math.pi/180*self.angle)

    def enemy2_pattern3(self, carpet):
        if self.move_count == 1:
            if self.frame == 0:     #self.aniDelay == 0 인 상태
                self.state = 3#random.randint(0,3) #차후 추가되면 랜덤으로 패턴을 돌린다.
                self.move_flag = False
                self.move_count = 0
                self.defensive_power = 5
        else:
            if self.move_flag == False:    #초기 위치값 지정
                self.carpetX=carpet.x
                self.carpetY=carpet.y
                self.endX = 350-0.7*(self.carpetX-350)
                self.endY = 350-0.7*(self.carpetY-350)
                self.angle=angle( self.x-0.7*(self.carpetX-350), self.y-0.7*(self.carpetY-350),self.endX, self.endY)
                self.move_flag = True #가운데 위치로 간다.
                self.defensive_power = 20
            elif self.move_flag == True:    #이동한다.
                if (self.endX-20 < self.x-0.7*(self.carpetX-350) and self.x-0.7*(self.carpetX-350)< self.endX+20) \
                        and (self.endY-20 < self.y-0.7*(self.carpetY-350) and self.y-0.7*(self.carpetY-350)< self.endY+20) :
                    if self.spaning_ball == False:
                        for i in range(0, 4):
                            self.skillX = self.x+150*math.cos(math.pi/ 180*90*i)#-0.7*(carpet.x-350)
                            self.skillY = self.y+150*math.sin(math.pi/ 180*90*i)#-0.7*(carpet.y-350)
                            self.ballList.append(Ball(self, carpet))
                        self.spaning_ball = True
                    else:
                        if self.allBallDie == True:
                            self.spaning_ball = False
                            self.allBallDie = False
                            self.move_count+=1
                        else:
                            if 0== len(self.ballList): self.allBallDie=True
                else:
                    self.x += 2*math.cos(math.pi/180*self.angle)
                    self.y += 2*math.sin(math.pi/180*self.angle)

    enemy2_state = {
        NORMAL : enemy2_normal,
        ENEMY2_PATTERN1 : enemy2_pattern1,
        ENEMY2_PATTERN2 : enemy2_pattern2,
        ENEMY2_PATTERN3 : enemy2_pattern3
    }

    def __init__(self):
        self.x, self.y = 350+800*math.cos(math.pi/180 * random.randint(0, 360)), 350+800*math.sin(math.pi/180 * random.randint(0, 360))
        self.frame = 0
        self.move_count = 0 #패턴 총 행동 횟수
        self.move_flag = False
        self.move_delay = 0
        self.angle = 0.0
        self.carpetX=0.0
        self.carpetY=0.0
        self.endX = 0.0
        self.endY = 0.0
        self.around_r = 0
        self.state = 3#self.NORMAL
        self.aniDelay = 0
        self.razer_angle = 0.0
        self.skillX = 0.0
        self.skillY = 0.0
        self.spaning_ball = False
        self.allBallDie = False
        self.ballList = []
        self.enemy2RazerBox = []
        self.enemy2BombBox = []
        self.attack_ready = False
        self.attack_flag = False
        self.HP = 5
        self.survive = True
        self.delete = False
        self.electric_shock_flag = False
        self.electric_shock_frame = 0
        self.electric_shock_aniDelay = 0
        self.defensive_power = 5
        if Enemy2.enemy2img == None: Enemy2.enemy2img = load_image('enemy2/enemy2normalprototype2.png')
        if Enemy2.enemy2die == None: Enemy2.enemy2die = load_image('enemy2/enemy2die.png')
        if Enemy2.electric_shock == None: Enemy2.electric_shock = load_image('hero/heroSkill/skill2boom.png')

    def update(self, carpet):
        if self.HP <= 0:
            if self.survive == True:
                self.survive = False
                self.frame = 0
                self.aniDelay = 0
        if self.survive == True : self.enemy2_state[self.state](self, carpet)

    def draw(self, carpet, ui):
        self.aniDelay+=1
        if self.survive == True:
            if self.state == self.NORMAL :
                self.enemy2img.clip_draw(self.frame*300, 350, 300,350, self.x-0.7*(carpet.x-350), self.y-0.7*(carpet.y-350))
            elif self.state != self.NORMAL :
                if self.move_flag == True:
                    self.enemy2img.clip_draw(self.frame*300, 350, 300,350, self.x-0.7*(carpet.x-350), self.y-0.7*(carpet.y-350))
                elif self.move_flag == False :
                    if self.attack_ready == True: #적이 멈춰있는 상태며, 공격 준비 상태
                        if self.attack_flag == True: self.frame = 4
                    self.enemy2img.clip_draw(self.frame*300, 0, 300,350, self.x-0.7*(carpet.x-350), self.y-0.7*(carpet.y-350))
        else:
            if self.delete == False : self.enemy2die.clip_draw(self.frame*300, 0, 300,300, self.x-0.7*(carpet.x-350), self.y-0.7*(carpet.y-350))

        if self.aniDelay == 10 :
            if self.delete == False : self.frame = (self.frame+1)%8
            self.aniDelay=0

            if self.survive == True:
                if self.state != self.NORMAL and self.frame == 0:
                    self.attack_ready = False
                    if self.state != self.ENEMY2_PATTERN3 : self.defensive_power = 5
            else:
                if self.frame == 0:
                    for i in range(-1, len(self.ballList)-1):
                         self.ballList[i].survive = False
                    self.delete = True
                    if ui.combo_flag == True:
                        ui.combo_flag = False
                        ui.combo_score_show_time = 15
                        ui.score += combo_score
                        ui.combo_score_degree = ui.combo_score
                        ui.combo_score = 0

        if self.electric_shock_flag == True:
            self.electric_shock_aniDelay+=1
            self.electric_shock.clip_draw(self.electric_shock_frame*50, 0, 50,50, self.x-0.7*(carpet.x-350), self.y-0.7*(carpet.y-350))
            if self.electric_shock_aniDelay == 3:
                self.electric_shock_frame=(self.electric_shock_frame+1)%9
                self.electric_shock_aniDelay=0
                if self.electric_shock_frame == 0: self.electric_shock_flag = False