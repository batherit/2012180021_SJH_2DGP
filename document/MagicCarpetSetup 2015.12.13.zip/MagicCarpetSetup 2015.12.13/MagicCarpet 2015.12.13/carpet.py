from pico2d import *
#양탄자 클래스 : 이동방향 플래그 변수에 종속적
#속성값 : 양탄자 위치
class Carpet:

    goToRight, goToLeft, goToUp, goToDown = False, False, False, False
    GUARD_LINE_MAX_X, GUARD_LINE_MIN_X, GUARD_LINE_MAX_Y, GUARD_LINE_MIN_Y = 650, 50, 650, 50
    VELOCITY = 6

    INIT_X, INIT_Y = 350, 350
    def __init__(self):
        self.x = Carpet.INIT_X
        self.y = Carpet.INIT_Y
        self.carpet = load_image('hero/carpet.png')

    def update(self):
        if self.goToRight == True:
            if self.x+50 >= self.GUARD_LINE_MAX_X : self.x -= (self.x+50-self.GUARD_LINE_MAX_X)
            else: self.x += Carpet.VELOCITY
        if self.goToLeft == True:
            if self.x-50 <= self.GUARD_LINE_MIN_X : self.x += (self.GUARD_LINE_MIN_X - (self.x-50))
            else: self.x -= Carpet.VELOCITY
        if self.goToUp == True:
            if self.y+50 >= self.GUARD_LINE_MAX_Y : self.y -= (self.y+50-self.GUARD_LINE_MAX_Y)
            else: self.y += Carpet.VELOCITY
        if self.goToDown == True:
            if self.y-50 <= self.GUARD_LINE_MIN_Y : self.y += (self.GUARD_LINE_MIN_Y - (self.y-50))
            else: self.y -= Carpet.VELOCITY
    def draw(self):
        self.carpet.draw(self.x, self.y)
    pass
