from pico2d import *
open_canvas(60,60)
skill2=load_image('skill2boom.png')

x=0
frame = 0
while (x<100):
    clear_canvas()
    skill2.clip_draw(frame*60,0 , 60,60, 30,30)
    frame = (frame+1)%8
    update_canvas()
    x+=1
    delay(0.05)
    get_events()

close_canvas()