import game_framework
import title_state
import math
import random
import json
import stage2
from pico2d import *



#주인공의 공격 상태
enumerate(['NORAML', 'ATTACK' ])
#주인공의 공격 방향
enumerate(['DEFAULT','LEFT, RIGHT, UP, DOWN'])
#주인공의 공격 타입
enumerate(['SKILL1, SKILL2, SKILL3'])
#왕과 왕비 구출 상태
enumerate(['NOT', 'SAVE']) #APPEAR, DIE 추가 예정

#UI 클래스
class UI:
    global font
    global hero
    global enemy2
    global hostage_num
    global king_state
    global queen_state
    global HP_buff_show_time
    global HP_buff_degree
    global combo_flag
    global combo_score
    global combo_score_show_time
    global combo_score_degree

    INIT_X, INIT_Y = 450, 350
    DISPLAY_CENTER_X, DISPLAY_CENTER_Y = 350, 350


    def ScoreInform(self, x, y, ctrlY, color):
        font.draw(x, y, '[SCORE]', color)
        font.draw(x, y-20, ': %d'%score, color)
        if combo_flag == True:
            font.draw(x, y-40, ': +RESCUE BONUS', color)
            font.draw(x, y-60, ': %d'%combo_score, color)



    def HeroState(self, x, y, ctrlY, color):
        font.draw(x, y+ctrlY, '[Hero State]', color)
        font.draw(x, y-20+ctrlY, '-HP : %d'%hero.HP, color)
        font.draw(x, y-40+ctrlY, '-Skill Type', color)
        font.draw(x, y-60+ctrlY, ': %s'%hero.skillType, color)
        if hero.skillType == 'SKILL2' :
            font.draw(x, y-80+ctrlY, '+CAHRGE', color)
            if hero.skill2Delay == 0 : font.draw(x, y-100+ctrlY, ': READY', color)
            else: font.draw(x, y-100+ctrlY, ': %d'%(70-hero.skill2Delay), color)
        elif hero.skillType == 'SKILL3' :
            font.draw(x, y-80+ctrlY, '+VALID NUM', color)
            font.draw(x, y-100+ctrlY, ': %d'%(5-hero.heroSkill3_num), color)
            font.draw(x, y-120+ctrlY, '+COOLTIME', color)
            if hero.heroSkill3_num >= 5:
                font.draw(x, y-140+ctrlY, ': %d'%(300-hero.heroSkill3CoolTime), color)
            else :
                font.draw(x, y-140+ctrlY, ': Completion', color)


    def RescueInform(self, x, y, ctrlY, color):
        font.draw(x, y+ctrlY, '[RESCUE INFORM]', color)
        font.draw(x, y-20+ctrlY, '-APPEAR : %d'%hostage_num, color)
        font.draw(x, y-40+ctrlY, '-SAVE : %d'%save_num, color)
        font.draw(x, y-60+ctrlY, 'KING : %s'%king_state, color)
        font.draw(x, y-80+ctrlY, 'QUEEN : %s'%queen_state, color)

    def CurrentStage(self, x, y, ctrlY, color, stage):
        font.draw(x, y, '[Current Stage]', color)
        font.draw(x, y-20, ': %d'%stage, color)
    def __init__(self):
        self.UITitle = load_image('UI/UITitle.png')
        self.gameover = load_image('UI/gameover.png')
        ui_data_file = open('UI/UI.txt', 'r')
        self.ui_data = json.load(ui_data_file)
        ui_data_file.close()

    def update(self):
        global score
        global king_state
        global queen_state
        global ultra_score
        global ultra_score_show_time
        global kq_all_rescue_flag
        if hero.survive == True : score += 1/10
        if kq_all_rescue_flag == False:
            if king_state == 'SAVE' and queen_state == 'SAVE':
                ultra_score_show_time = 50
                score += ultra_score
                kq_all_rescue_flag = True


    def draw(self):
        global HP_buff_show_time
        global point_show_time
        global combo_score_show_time
        global combo_score_degree
        global ultra_score
        global ultra_score_show_time
        self.UITitle.draw(UI.INIT_X, UI.INIT_Y)
        self.ScoreInform(self.ui_data['Score']['x'], self.ui_data['Score']['y'], self.ui_data['Score']['ctrlY'],\
                        (self.ui_data['Score']['R'], self.ui_data['Score']['G'], self.ui_data['Score']['B']))
        if point_show_time > 0 :
            font.draw(hero.x + carpet.x - 50, hero.y + carpet.y +40+40/(point_show_time+1), 'POINT +%d'%point_degree, (100,200,100))
            point_show_time -= 1
        if combo_score_show_time > 0 :
            font.draw(hero.x + carpet.x - 100, hero.y + carpet.y +40+40/(combo_score_show_time+1), 'RESCUE BONUS +%d'%combo_score_degree , (200,100,200))
            combo_score_show_time -= 1
        if ultra_score_show_time > 0 :
            font.draw(hero.x + carpet.x - 90, hero.y + carpet.y +40+40/(ultra_score_show_time+1), 'ULTRA BONUS +%d'%ultra_score  , (250,250,100))
            ultra_score_show_time -= 1
        # self.CurrentStage(self.ui_data['CurrentStage']['x'], self.ui_data['CurrentStage']['y'], self.ui_data['CurrentStage']['ctrlY'],\
        #                   (self.ui_data['CurrentStage']['R'], self.ui_data['CurrentStage']['G'], self.ui_data['CurrentStage']['B']), 2)
        # self.EnemyState(self.ui_data['EnemyState']['x'], self.ui_data['EnemyState']['y'], self.ui_data['EnemyState']['ctrlY'],\
        #                 (self.ui_data['EnemyState']['R'], self.ui_data['EnemyState']['G'], self.ui_data['EnemyState']['B']))
        self.HeroState(self.ui_data['HeroState']['x'], self.ui_data['HeroState']['y'], self.ui_data['HeroState']['ctrlY'],\
                       (self.ui_data['HeroState']['R'], self.ui_data['HeroState']['G'], self.ui_data['HeroState']['B']))
        self.RescueInform(self.ui_data['RescueInform']['x'], self.ui_data['RescueInform']['y'], self.ui_data['RescueInform']['ctrlY'],\
                          (self.ui_data['RescueInform']['R'], self.ui_data['RescueInform']['G'], self.ui_data['RescueInform']['B']))
        if HP_buff_show_time > 0 :
            font.draw(hero.x + carpet.x - 30, hero.y + carpet.y +20+20/(HP_buff_show_time+1), 'HP +%d'%HP_buff_degree, (200,100,100))
            HP_buff_show_time -= 1
        if hero.survive == False : self.gameover.draw(UI.DISPLAY_CENTER_X, UI.DISPLAY_CENTER_Y)
#맵 클래스 : carpet의 움직임에 종속적
class Map:
    global carpet
    CENTER_POS_X, CENTER_POS_Y = 350, 350
    BASE_MAP_POS_X, BASE_MAP_POS_Y = 450, 350
    def __init__(self):
        #self.mapCast = load_image('map/mapCast2.png')
        self.baseMap = load_image('map/baseMap.png')
        self.map1 = load_image('map/simpleMap1.png')
        self.map2 = load_image('map/simpleMap2.png')
        self.map3 = load_image('map/simpleMap3.png')
        self.map4 = load_image('map/simpleMap4.png')
        self.map5 = load_image('map/simpleMap5.png')
    def draw(self):
        self.baseMap.draw(Map.BASE_MAP_POS_X, Map.BASE_MAP_POS_Y)
        self.map1.draw(Map.BASE_MAP_POS_X-0.5*(carpet.x-Map.CENTER_POS_X), Map.BASE_MAP_POS_Y-0.5*(carpet.y-Map.CENTER_POS_Y))
        self.map2.draw(Map.BASE_MAP_POS_X-0.25*(carpet.x-Map.CENTER_POS_X), Map.BASE_MAP_POS_Y-0.25*(carpet.y-Map.CENTER_POS_Y))
        self.map3.draw(Map.BASE_MAP_POS_X-0.125*(carpet.x-Map.CENTER_POS_X), Map.BASE_MAP_POS_Y-0.125*(carpet.y-Map.CENTER_POS_Y))
        self.map4.draw(Map.BASE_MAP_POS_X-0.0625*(carpet.x-Map.CENTER_POS_X), Map.BASE_MAP_POS_Y-0.0625*(carpet.y-Map.CENTER_POS_Y))
        self.map5.draw(Map.CENTER_POS_X-0.20*(carpet.x-Map.CENTER_POS_X), Map.CENTER_POS_Y-0.20*(carpet.y-Map.CENTER_POS_Y))
        #self.mapCast.draw(450, 350)
    pass


#주인공 클래스 : carpet 클래스와 cootTime 변수에 종속적
#속성값 : 주인공 위치 좌표, 현재 상태(기본, 공격), 공격 방향, 공격 타입
class Hero:
    global carpet
    global heroSkill1Box
    global heroSkill2Box

    def __init__(self): #속성 초기화
        self.x = 0
        self.y = 0
        self.state = 'NORMAL'
        self.attackDirect = 'DEFAULT'
        self.skillType = 'SKILL1'
        self.hero = load_image('hero/mainchar.png')
        self.attack = load_image('hero/mainchar_attack.png')
        self.hero_die = load_image('hero/mainchar_die.png')
        self.attackAniFlag = 0
        self.frame = 0
        self.delay = 0
        self.skill1Delay = 0
        self.skill2Delay = 0
        self.skill3Delay = 0
        self.heroSkill3_num = 0
        self.heroSkill3CoolTime = 0
        self.HP = 100
        self.survive = True
        self.delete = False
    def update(self): #게임 로직
        #주인공이 공격 상태라면 탄환을 생성한다.
        if self.HP <= 0:
            if self.survive == True:
                self.survive = False
                self.frame = 0
                self.delay = 0
        if self.survive == True:
            if self.state == 'ATTACK':
                if self.skillType == 'SKILL1':
                    self.skill1Delay+=1
                    if self.skill1Delay == 8:
                        heroSkill1Box.append(Skill1())
                        self.skill1Delay = 0
                elif self.skillType == 'SKILL2':
                    self.skill2Delay+=1
                    if self.skill2Delay == 70:
                        heroSkill2Box.append(Skill2())
                        self.skill2Delay = 0
                elif self.skillType == 'SKILL3':
                    self.skill3Delay+=1
                    if self.skill3Delay == 15:
                        if self.heroSkill3_num < 5 :
                            self.heroSkill3_num+=1
                            heroSkill3Box.append(Skill3())
                        self.skill3Delay = 0
            if self.heroSkill3_num >= 5:
                self.heroSkill3CoolTime+=1
                if self.heroSkill3CoolTime == 300:
                    self.heroSkill3CoolTime = 0
                    self.heroSkill3_num = 0

    def draw(self): #게임 렌더링
        self.delay+=1
        if self.survive == True:
            if self.state == 'NORMAL': #아무런 입력이 없을 경우
                self.hero.clip_draw(self.frame*40, 0, 40,40, self.x+carpet.x, self.y+carpet.y)
                if self.delay == 10:
                    self.frame = (self.frame+1) % 2
                    self.delay = 0
            elif self.state == 'ATTACK': #스페이스키를 눌러 공격 형태가 됐을 경우
                if self.attackAniFlag == 0:
                    self.attack.clip_draw(self.frame*40, 40, 40,40,self.x+carpet.x, self.y+carpet.y)
                    if self.delay == 4:
                        self.frame = (self.frame+1) % 8
                        self.delay = 0
                        if self.frame == 0:
                            self.attackAniFlag = 1-self.attackAniFlag
                else:
                    self.attack.clip_draw(self.frame*40, 0, 40,40, self.x+carpet.x, self.y+carpet.y)
                    if self.delay == 4:
                        self.frame = (self.frame+1)%8
                        self.delay =0
                        #if self.frame == 0:
                        #    self.attackAniFlag = 1-self.attackAniFlag
        else:
            if self.delete == False :
                self.hero_die.clip_draw(self.frame*40, 0, 40,40, self.x+carpet.x, self.y+carpet.y)
                if self.delay == 10 :
                    if self.delete == False : self.frame = (self.frame+1)%12
                    if self.frame == 0 : self.delete = True
                    self.delay=0


def angle(startX,startY,directX, directY):
    axisDegree = (180.0 / math.pi)*math.atan2(0.0, 1.0)
    if axisDegree < 0: axisDegree += 360
    moveDegree = (180.0 / math.pi)*math.atan2((directY - startY), (directX - startX))
    if moveDegree < 0: moveDegree += 360
    return moveDegree - axisDegree
#주인공 마법 타입1 클래스 : 주인공 클래스에 종속적
#속성값 : 마법 초기 생성 위치, 마법 진행 방향, 마법 진행 방향각, 마법 이동 속도
#전제 : Skill1 인스턴스는 hero 내에서 생성된다. (hero.state == 'ATTACK' 상태 )
class Skill1:
    global hero
    global carpet
    global heroSkill1Box

    SPAN_POSITION = 30
    skill1 = None

    angle_about_direct = { 'UP' : 90, 'DOWN' : 270, 'LEFT' : 180, 'RIGHT' : 0}

    def __init__(self):
        if Skill1.skill1 == None:Skill1.skill1 = load_image('hero/heroSkill/skill1.png')
        #마법은 주인공 기준으로 생성된다.
        self.x = hero.x+carpet.x
        self.y = hero.y+carpet.y
        self.angle = 0.0
        self.frame = 0
        self.collision = False
        self.aniDelay = 0
        self.carpetX = carpet.x
        self.carpetY = carpet.y
        self.power = 2
        #마법 탄환 초기 생성 위치 초기화
        if hero.attackDirect=='UP': self.y += Skill1.SPAN_POSITION
        elif hero.attackDirect == 'DOWN': self.y -= Skill1.SPAN_POSITION
        elif hero.attackDirect == 'LEFT': self.x -= Skill1.SPAN_POSITION
        elif hero.attackDirect == 'RIGHT': self.x += Skill1.SPAN_POSITION
        self.angle = self.angle_about_direct[hero.attackDirect]+random.randint(-4, 4)
        self.direct = hero.attackDirect
        self.velocity = 10#random.randint(20,21)
    def update(self):
        if self.collision == False:
            self.x += self.velocity*math.cos(math.pi/180*self.angle)
            self.y += self.velocity*math.sin(math.pi/180*self.angle)
    def draw(self):
        if self.collision == False : self.skill1.clip_draw(0,0, 30, 30, self.x-0.7*(carpet.x-self.carpetX), self.y-0.7*(carpet.y-self.carpetY))
        else:
            self.aniDelay+=1
            self.skill1.clip_draw(self.frame*30, 0, 30, 30,self.x-0.7*(carpet.x-self.carpetX), self.y-0.7*(carpet.y-self.carpetY))
            if self.aniDelay == 3:
                self.frame = (self.frame+1)%8
                self.aniDelay = 0
                if self.frame == 0:
                    for i in range(-1, len(heroSkill1Box)-1):
                        if self == heroSkill1Box[i]:
                            del heroSkill1Box[i]
                            break

class Skill2:
    global hero
    global carpet
    global heroSkill2Box
    global enemy2


    SPAN_POSITION = 430
    skill2_1LR, skill2_2LR, skill2_1UD, skill2_2UD = None, None, None, None


    def collision(self, dir, skill2X, skill2Y): #800 60
        global score
        if dir == 'LEFT' :
            if enemy1.survive == True :
                if enemy1.x-0.7*(carpet.x-350) <= self.x + Skill2.SPAN_POSITION :
                    if enemy1.state != enemy1.ENEMY1_PATTERN1:
                        if self.y - 125 < enemy1.y-0.7*(carpet.y-350) and enemy1.y-0.7*(carpet.y-350) < self.y + 125 :
                            enemy1.HP-=self.power
                            enemy1.electric_shock_flag = True
                            score += 10
                        elif self.y - 160 < enemy1.y-0.7*(carpet.y-350) and enemy1.y-0.7*(carpet.y-350) < self.y + 160 :
                            enemy1.HP-=self.power/2
                            enemy1.electric_shock_flag = True
                            score += 10
                    else:
                        if self.y - 120 < enemy1.y-0.7*(carpet.y-350) and enemy1.y-0.7*(carpet.y-350) < self.y + 120 :
                            enemy1.HP-=self.power
                            enemy1.electric_shock_flag = True
                            score += 10
                        elif self.y - 160 < enemy1.y-0.7*(carpet.y-350) and enemy1.y-0.7*(carpet.y-350) < self.y + 160 :
                            enemy1.HP-=self.power/2
                            enemy1.electric_shock_flag = True
                            score += 10
        elif dir == 'RIGHT' :
            if enemy1.survive == True :
                if self.x - Skill2.SPAN_POSITION <= enemy1.x-0.7*(carpet.x-350) :
                    if enemy1.state != enemy1.ENEMY1_PATTERN1:
                        if self.y - 125 < enemy1.y-0.7*(carpet.y-350) and enemy1.y-0.7*(carpet.y-350) < self.y + 125 :
                            enemy1.HP-=self.power
                            enemy1.electric_shock_flag = True
                            score += 10
                        elif self.y - 160 < enemy1.y-0.7*(carpet.y-350) and enemy1.y-0.7*(carpet.y-350) < self.y + 160 :
                            enemy1.HP-=self.power/2
                            enemy1.electric_shock_flag = True
                            score += 10
                    else:
                        if self.y - 120 < enemy1.y-0.7*(carpet.y-350) and enemy1.y-0.7*(carpet.y-350) < self.y + 120 :
                            enemy1.HP-=self.power
                            enemy1.electric_shock_flag = True
                            score += 10
                        elif self.y - 160 < enemy1.y-0.7*(carpet.y-350) and enemy1.y-0.7*(carpet.y-350) < self.y + 160 :
                            enemy1.HP-=self.power/2
                            enemy1.electric_shock_flag = True
                            score += 10
        elif dir == 'UP' :
            if enemy1.survive == True :
                if self.y - Skill2.SPAN_POSITION <= enemy1.y-0.7*(carpet.y-350) :
                    if enemy1.state != enemy1.ENEMY1_PATTERN1:
                        if self.x - 50 < enemy1.x-0.7*(carpet.x-350) and enemy1.x-0.7*(carpet.x-350) < self.x + 50 :
                            enemy1.HP-=self.power
                            enemy1.electric_shock_flag = True
                            score += 10
                        elif self.x - 90 < enemy1.x-0.7*(carpet.x-350) and enemy1.x-0.7*(carpet.x-350) < self.x + 90 :
                            enemy1.HP-=self.power/2
                            enemy1.electric_shock_flag = True
                            score += 10
                    else:
                        if self.x - 120 < enemy1.x-0.7*(carpet.x-350) and enemy1.x-0.7*(carpet.x-350) < self.x + 120 :
                            enemy1.HP-=self.power
                            enemy1.electric_shock_flag = True
                            score += 10
                        elif self.x - 160 < enemy1.x-0.7*(carpet.x-350) and enemy1.x-0.7*(carpet.x-350) < self.x + 160 :
                            enemy1.HP-=self.power/2
                            enemy1.electric_shock_flag = True
                            score += 10
        elif dir == 'DOWN' :
            if enemy1.survive == True :
                if enemy1.y-0.7*(carpet.y-350) <= self.y + Skill2.SPAN_POSITION :
                    if enemy1.state != enemy1.ENEMY1_PATTERN1:
                        if self.x - 50 < enemy1.x-0.7*(carpet.x-350) and enemy1.x-0.7*(carpet.x-350) < self.x + 50 :
                            enemy1.HP-=self.power
                            enemy1.electric_shock_flag = True
                            score += 10
                        elif self.x - 90 < enemy1.x-0.7*(carpet.x-350) and enemy1.x-0.7*(carpet.x-350) < self.x + 90 :
                            enemy1.HP-=self.power/2
                            enemy1.electric_shock_flag = True
                            score += 10
                    else:
                        if self.x - 120 < enemy1.x-0.7*(carpet.x-350) and enemy1.x-0.7*(carpet.x-350) < self.x + 120 :
                            enemy1.HP-=self.power
                            enemy1.electric_shock_flag = True
                            score += 10
                        elif self.x - 160 < enemy1.x-0.7*(carpet.x-350) and enemy1.x-0.7*(carpet.x-350) < self.x + 160 :
                            enemy1.HP-=self.power/2
                            enemy1.electric_shock_flag = True
                            score += 10

    def __init__(self):
        if Skill2.skill2_1LR == None : Skill2.skill2_1LR = load_image('hero/heroSkill/skill2_1LR.png')
        if Skill2.skill2_2LR == None : Skill2.skill2_2LR = load_image('hero/heroSkill/skill2_2LR.png')
        if Skill2.skill2_1UD == None : Skill2.skill2_1UD = load_image('hero/heroSkill/skill2_1UD.png')
        if Skill2.skill2_2UD == None : Skill2.skill2_2UD = load_image('hero/heroSkill/skill2_2UD.png')
        #마법은 주인공 기준으로 생성된다.
        self.x = hero.x+carpet.x
        self.y = hero.y+carpet.y
        self.frame = 0
        self.aniFlag = random.randint(0,1)
        self.aniDelay = 0
        self.direct = hero.attackDirect
        self.distance = 0
        self.power = 26
        #마법 탄환 초기 생성 위치 초기화
        if hero.attackDirect=='UP' : self.y += Skill2.SPAN_POSITION
        elif hero.attackDirect == 'DOWN' : self.y -= Skill2.SPAN_POSITION
        elif hero.attackDirect == 'LEFT' : self.x -= Skill2.SPAN_POSITION
        elif hero.attackDirect == 'RIGHT' : self.x += Skill2.SPAN_POSITION

    def update(self):
        pass
    def draw(self):
        self.aniDelay+=1
        if self.direct == 'RIGHT' or self.direct == 'LEFT':
            if self.aniFlag == 0:
                self.skill2_1LR.clip_draw(0, 360-self.frame*60, 800,60, self.x, self.y)
                if self.aniDelay == 3:
                    if self.frame == 0 : self.collision(self.direct, self.x, self.y)
                    self.frame = (self.frame+1)%7
                    self.aniDelay=0
                    if self.frame == 0:
                        for i in range(-1, len(heroSkill2Box)-1):
                                if self == heroSkill2Box[i]:
                                    del heroSkill2Box[i]
                                    break
            else:
                self.skill2_2LR.clip_draw(0, 360-self.frame*60, 800,60, self.x, self.y)
                if self.aniDelay == 3:
                    if self.frame == 0 : self.collision(self.direct, self.x, self.y)
                    self.frame = (self.frame+1)%7
                    self.aniDelay=0
                    if self.frame == 0:
                        for i in range(-1, len(heroSkill2Box)-1):
                                if self == heroSkill2Box[i]:
                                    del heroSkill2Box[i]
                                    break
        elif self.direct == 'UP' or self.direct == 'DOWN':
            if self.aniFlag == 0:
                self.skill2_1UD.clip_draw(self.frame*60, 0, 60,800, self.x, self.y)
                if self.aniDelay == 3:
                    if self.frame == 0 : self.collision(self.direct, self.x, self.y)
                    self.frame = (self.frame+1)%7
                    self.aniDelay=0
                    if self.frame == 0:
                        for i in range(-1, len(heroSkill2Box)-1):
                                if self == heroSkill2Box[i]:
                                    del heroSkill2Box[i]
                                    break
            else:
                self.skill2_2UD.clip_draw(self.frame*60, 0, 60,800, self.x, self.y)
                if self.aniDelay == 3:
                    if self.frame == 0 : self.collision(self.direct, self.x, self.y)
                    self.frame = (self.frame+1)%7
                    self.aniDelay=0
                    if self.frame == 0:
                        for i in range(-1, len(heroSkill2Box)-1):
                                if self == heroSkill2Box[i]:
                                    del heroSkill2Box[i]
                                    break

class Skill3:
    global hero
    global carpet
    global heroSkill1Box

    skill3 = None
    skill3Boom = None
    skill3_data = None
    KIND1, KIND2, KIND3, KIND4, KIND5 = 0, 1, 2, 3, 4
    SPAN_POSITION = 30
    SELF_EXPLOSION_TIME = 180
    skill3_kind = { KIND1 : 'KIND1', KIND2 : 'KIND2', KIND3 : 'KIND3', KIND4 : 'KIND4', KIND5 : 'KIND5' }
    def __init__(self):
        if Skill3.skill3 == None: Skill3.skill3 = load_image('hero/heroSkill/skill3.png')
        if Skill3.skill3Boom == None: Skill3.skill3Boom = load_image('hero/heroSkill/skill3boom.png')
        if Skill3.skill3_data == None:
            skill3_data_file = open('hero/heroSkill/skill3_data.txt','r')
            Skill3.skill3_data = json.load(skill3_data_file)
            skill3_data_file.close()
        #마법은 주인공 기준으로 생성된다.
        self.x = hero.x+carpet.x
        self.y = hero.y+carpet.y
        self.frame = 0
        self.aniDelay = 0
        self.self_explosion_time = Skill3.SELF_EXPLOSION_TIME
        self.power = 0
        self.collision = False
        self.carpetX = carpet.x
        self.carpetY = carpet.y
        self.kind = random.randint(1, 36)
        if 0 < self.kind and self.kind < 16 : self.kind = self.KIND1
        elif 15< self.kind and self.kind <26 : self.kind = self.KIND2
        elif 25< self.kind and self.kind <31 : self.kind = self.KIND3
        elif 30< self.kind and self.kind <36 : self.kind = self.KIND4
        elif 35< self.kind and self.kind <37 : self.kind = self.KIND5
        self.power = Skill3.skill3_data[self.skill3_kind[self.kind]]['power']
        #마법 탄환 초기 생성 위치 초기화
        if hero.attackDirect=='UP': self.y += Skill3.SPAN_POSITION
        elif hero.attackDirect == 'DOWN': self.y -= Skill3.SPAN_POSITION
        elif hero.attackDirect == 'LEFT': self.x -= Skill3.SPAN_POSITION
        elif hero.attackDirect == 'RIGHT': self.x += Skill3.SPAN_POSITION
    def update(self):
        if self.collision == False :
            self.self_explosion_time -= 1
            if self.self_explosion_time < 0:
                self.collision = True

    def draw(self):
        if self.collision == False :
            self.skill3.clip_draw(self.kind*40,0, 40, 40, self.x-0.7*(carpet.x-self.carpetX), self.y-0.7*(carpet.y-self.carpetY))
        else :
            self.aniDelay+=1
            self.skill3Boom.clip_draw(60*self.frame, 0, 60, 60,self.x-0.7*(carpet.x-self.carpetX), self.y-0.7*(carpet.y-self.carpetY))
            if self.aniDelay == 10:
                self.frame = (self.frame+1)%8
                self.aniDelay = 0
                if self.frame == 0:
                    for i in range(-1, len(heroSkill3Box)-1):
                        if self == heroSkill3Box[i]:
                            del heroSkill3Box[i]
                            break

#양탄자 클래스 : 이동방향 플래그 변수에 종속적
#속성값 : 양탄자 위치
class Carpet:
    goToRight, goToLeft, goToUp, goToDown = False, False, False, False

    INIT_X, INIT_Y = 350, 350
    def __init__(self):
        self.x = Carpet.INIT_X
        self.y = Carpet.INIT_Y
        self.carpet = load_image('hero/carpet.png')

    def update(self):
        if self.goToRight == True:
            if self.x+50 > 650 : self.x -= 2
            else: self.x += 2
        if self.goToLeft == True:
            if self.x-50 < 50 : self.x += 2
            else: self.x -= 2
        if self.goToUp == True:
            if self.y+50 > 650 : self.y -=2
            else: self.y += 2
        if self.goToDown == True:
            if self.y-50 < 50 : self.y +=2
            else: self.y -= 2
    def draw(self):
        self.carpet.draw(self.x, self.y)
    pass

#enemy1 클래스
class Enemy1:
    global hero
    global carpet

    enemy1img = None
    enemy1disappear = None
    enemy1dark = None
    # enemy2die = None
    electric_shock = None

    EYE_TO_RIGHT, EYE_TO_LEFT = 0, 1
    EYE_TO_UP, EYE_TO_DOWN = 0, 1
    EYE_POSITION_Y = 80
    MAP_CENTER_X, MAP_CENTER_Y = 350, 350

    NORMAL, ENEMY1_PATTERN1, ENEMY1_PATTERN2, ENEMY1_PATTERN3  = 0, 1, 2, 3

    def enemy1_normal(self):        #enemy1의 평범한 움직임
        if self.move_count == 4:
            if self.frame == 0:     #self.aniDelay == 0 인 상태
                self.state = random.randint(0,3)#random.randint(0,3) #차후 추가되면 랜덤으로 패턴을 돌린다.
                self.move_flag = False
                self.move_count = 0
        else :
            if self.move_flag == False:
                self.move_delay+=1
                if self.move_delay == self.move_ding:
                    self.carpetX = carpet.x
                    self.carpetY = carpet.y
                    self.hero_around_angle += (-1+2*random.randint(0,1))*30
                    self.around_r = random.randint(-300,300)
                    self.endX = self.carpetX + self.around_r*math.cos(math.pi/180*self.hero_around_angle)
                    self.endY = self.carpetY + self.around_r*math.sin(math.pi/180*self.hero_around_angle)
                    self.angle = angle(self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X), self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y), self.endX, self.endY)
                    self.move_flag = True
                    self.move_delay = 0
                    self.move_ding = 1
                    self.velocity = 5
            elif self.move_flag == True:
                if 12 > distance(self.endX, self.endY,self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X), self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)):
                    self.move_flag = False
                    self.move_count+=1
                else:
                    self.x += self.velocity*math.cos(math.pi/180*self.angle)
                    self.y += self.velocity*math.sin(math.pi/180*self.angle)

    def enemy1_pattern1(self): #SickleWind!
        if self.move_count == 7:
            if self.frame == 0:     #self.aniDelay == 0 인 상태
                self.state = Enemy1.ENEMY1_PATTERN1#random.randint(0,3) #차후 추가되면 랜덤으로 패턴을 돌린다.
                self.move_flag = False
                self.move_count = 0
        else :
            if self.move_flag == False:
                self.move_delay+=1
                if self.move_delay == self.move_ding:
                    self.carpetX = carpet.x
                    self.carpetY = carpet.y
                    #self.hero_around_angle += (-1+2*random.randint(0,1))*30
                    self.around_r = random.randint(-200,200)
                    if math.fabs(carpet.x-(self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X))) > math.fabs(carpet.y-(self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y))):
                        self.endX = Enemy1.MAP_CENTER_X + (-1+2*self.ThisIsRight(carpet.x))*400-0.7*(self.carpetX-Enemy1.MAP_CENTER_X)
                        self.endY = Enemy1.MAP_CENTER_Y +  ((carpet.y-Enemy1.MAP_CENTER_Y)/400)*400-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)
                    else :
                        self.endX =Enemy1.MAP_CENTER_X +  ((carpet.x-Enemy1.MAP_CENTER_X)/400)*400-0.7*(self.carpetX-Enemy1.MAP_CENTER_X)
                        self.endY =Enemy1.MAP_CENTER_Y + (-1+2*self.ThisIsUP(carpet.y))*400-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)
                    self.angle = angle(self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X), self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y), self.endX, self.endY)
                    self.move_flag = True
                    self.move_delay = 0
                    self.move_ding = 1
                    self.velocity = 1
            elif self.move_flag == True:
                if 30 > distance(self.endX, self.endY, self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X), self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)) :
                    self.move_flag = False
                    self.acceleration = 0
                    self.move_count+=1
                else:
                    self.acceleration += 0.1
                    self.x += (self.velocity+self.acceleration)*math.cos(math.pi/180*self.angle)
                    self.y += (self.velocity+self.acceleration)*math.sin(math.pi/180*self.angle)


    def enemy1_pattern2(self): #HideAndSeek
        if self.move_count == 6:
            if self.frame == 0:     #self.aniDelay == 0 인 상태
                self.state = Enemy1.ENEMY1_PATTERN2#random.randint(0,3) #차후 추가되면 랜덤으로 패턴을 돌린다.
                self.move_flag = False
                self.move_count = 0
        else :
            if self.move_flag == False:
                self.move_delay+=1
                if self.move_delay == self.move_ding:
                    self.carpetX = carpet.x
                    self.carpetY = carpet.y
                    #self.hero_around_angle += (-1+2*random.randint(0,1))*30
                    self.around_r = random.randint(-200,200)
                    # if self.move_count <5:
                    self.endX = Enemy1.MAP_CENTER_X + (1-2*self.ThisIsRight(carpet.x))*(380+random.randint(-20, 20))-0.7*(self.carpetX-Enemy1.MAP_CENTER_X)
                    self.endY = Enemy1.MAP_CENTER_Y +  ((carpet.y-Enemy1.MAP_CENTER_Y)/350)*(400+random.randint(-20, 20))-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)
                    # else:
                    #     self.endX = Enemy1.MAP_CENTER_X + (-1+2*self.ThisIsRight(carpet.x))*(380+random.randint(-20, 20))-0.7*(self.carpetX-Enemy1.MAP_CENTER_X)
                    #     self.endY = Enemy1.MAP_CENTER_Y +  ((carpet.y-Enemy1.MAP_CENTER_Y)/350)*(400+random.randint(-20, 20))-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)
                    self.angle = angle(self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X), self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y), self.endX, self.endY)
                    self.move_flag = True
                    self.move_delay = 0
                    self.move_ding = 1
                    self.velocity = 3
            elif self.move_flag == True:
                if 30 > distance(self.endX, self.endY, self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X), self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)) :
                    self.move_flag = False
                    self.move_count+=1
                else:
                    self.x += (self.velocity+self.acceleration)*math.cos(math.pi/180*self.angle)
                    self.y += (self.velocity+self.acceleration)*math.sin(math.pi/180*self.angle)


    def enemy1_pattern3(self):
        if self.attack_time <= 0:
            if self.frame == 0:     #self.aniDelay == 0 인 상태
                self.state = Enemy1.ENEMY1_PATTERN3#random.randint(0,3) #차후 추가되면 랜덤으로 패턴을 돌린다.
                self.darkFlag = False
                self.disappear = False
                self.attack_time = 500
        else :
            if self.darkFlag == True:
                self.attack_time-=1
                if 10 < distance(carpet.x, carpet.y,self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y)):
                    self.angle = angle(self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y), carpet.x, carpet.y)
                    self.x += self.velocity*math.cos(math.pi/180*self.angle)
                    self.y += self.velocity*math.sin(math.pi/180*self.angle)
    enemy1_state = {
        NORMAL : enemy1_normal,
        ENEMY1_PATTERN1 : enemy1_pattern1,
        ENEMY1_PATTERN2 : enemy1_pattern2,
        ENEMY1_PATTERN3 : enemy1_pattern3
    }

    def ThisIsRight(self, objX):
        if self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X) < objX : return 1
        else : return 0
    def ThisIsUP(self, objY):
        if self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y) < objY : return 1
        else : return 0

    def __init__(self):
        self.x, self.y = Enemy1.MAP_CENTER_X+400*math.cos(math.pi/180 * random.randint(0, 360)), Enemy1.MAP_CENTER_Y+400*math.sin(math.pi/180 * random.randint(0, 360))
        self.frame = 0
        self.move_count = 0 #패턴 총 행동 횟수
        self.move_flag = False
        self.move_delay = 0
        self.move_ding = 10
        self.darkFlag = False
        self.angle = 0.0
        self.hero_around_angle = 0.0
        self.carpetX=0.0
        self.carpetY=0.0
        self.endX = 0.0
        self.endY = 0.0
        self.around_r = 0
        self.velocity = 0
        self.acceleration = 0
        self.state =Enemy1.ENEMY1_PATTERN1
        self.aniDelay = 0
        self.attack_time = 500
        self.attack_ding=0
        self.attack_delay = 0
        self.attack_count = 0
        self.attack_count_max = 0
        self.skillX = 0
        self.skillY = 0
        self.signFlag = 1
        self.HP = 500
        self.survive = True
        self.delete = False
        self.disappear=False
        self.electric_shock_flag = False
        self.electric_shock_frame = 0
        self.electric_shock_aniDelay = 0
        # self.defensive_power = 5
        if Enemy1.enemy1img == None: Enemy1.enemy1img = load_image('enemy1/enemy1AniSet.png')
        if Enemy1.enemy1disappear == None : Enemy1.enemy1disappear = load_image('enemy1/pattern/enemy1darksign.png')
        if Enemy1.enemy1dark == None : Enemy1.enemy1dark = load_image('enemy1/pattern/enemy1pattern2dark.png')
        if Enemy1.electric_shock == None: Enemy1.electric_shock = load_image('hero/heroSkill/skill2boom.png')
    def update(self):
        if self.HP <= 0:
            if self.survive == True:
                self.survive = False
                self.frame = 0
                self.aniDelay = 0
        if self.survive == True : self.enemy1_state[self.state](self)


    def draw(self, objX):
        global enemy1
        global score
        global combo_flag
        global combo_score
        global combo_score_degree
        global combo_score_show_time

        self.aniDelay+=1
        if self.survive == True:
            #if self.state == self.NORMAL :
            if self.darkFlag == False : self.enemy1img.clip_draw(self.frame*300, 350*(1-self.ThisIsRight(objX))+700*(self.state), 300,350, self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y))
            else :
                self.enemy1img.clip_draw(self.frame*300, 350*(1-self.ThisIsRight(objX))+700*(self.state - 1), 300,350, self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y))
                # self.enemy1dark.clip_draw(0, 0, 1250,1250, carpet.x, carpet.y)
                if self.disappear == False : self.enemy1disappear.clip_draw(self.frame*300, 80*(1-self.ThisIsRight(objX)), 300,80, self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y+Enemy1.EYE_POSITION_Y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y))
        if self.aniDelay == 10 :
            if self.delete == False : self.frame = (self.frame+1)%8
            if self.survive == True:
                if self.state == self.ENEMY1_PATTERN2:
                    if self.frame == 4:
                        enemy1SickleWindList.append(SickleWind(1-self.ThisIsRight(carpet.x),self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y), carpet.x,carpet.y))
                elif self.state == self.ENEMY1_PATTERN3:
                    if self.darkFlag == False and self.frame == 0:
                        self.darkFlag = True
                        self.velocity = 1
                    # elif self.darkFlag == True and self.frame == 4 and 250 < distance(carpet.x, carpet.y,self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y)):
                    #     enemy1SickleWindList.append(SickleWind(self.ThisIsRight(carpet.x),self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y), carpet.x,carpet.y))
                    elif self.darkFlag == True and self.disappear == False:
                        if self.frame == 0:
                            self.disappear = True
                            self.attack_ding = 2
                            self.attack_delay = 0
                            # self.attack_count = 0
                            # self.attack_count_max = 6
            if self.disappear == True:
                self.attack_delay +=1
                if self.attack_delay == self.attack_ding:
                    self.skillX= (Enemy1.MAP_CENTER_X+((-1+2*random.randint(0,1))*350))-0.7*(carpet.x-Enemy1.MAP_CENTER_X)
                    self.skillY= (Enemy1.MAP_CENTER_Y+((-1+2*random.randint(0,1))*350))-0.7*(carpet.y-Enemy1.MAP_CENTER_Y)
                    for i in range(0, 30):
                        enemy1RazerBox.append(Enemy1Razer(360/30*i+45*self.signFlag, self.skillX, self.skillY ))
                    self.signFlag = 1-self.signFlag
                    self.attack_delay = 0
                #
                # if self.attack_count >= self.attack_count_max:
                #         self.attack_start = False
                #         self.move_count+=1
                        # self.attack_count=0
                        # self.x = Enemy1Razer.MAP_CENTER_X+random.randint(-Enemy1Razer.MAP_CENTER_X, Enemy1Razer.MAP_CENTER_X)+0.7*(carpet.x-Enemy1Razer.MAP_CENTER_X)
                        # self.y = Enemy1Razer.MAP_CENTER_Y+random.randint(-Enemy1Razer.MAP_CENTER_Y, Enemy1Razer.MAP_CENTER_Y)+0.7*(carpet.y-Enemy1Razer.MAP_CENTER_Y)
                        # self.disappear = False
                        # self.frame = 0
                        # self.attack_ding = 2
                        # self.attack_delay = 0
                        # self.attack_count = 0
                        # self.attack_count_max = 6
                # elif self.attack_count < self.attack_count_max:
                #     if self.attack_delay == self.attack_ding: #공격 입력
                #         for i in range(0, 20):
                #             enemy1RazerBox.append(Enemy1Razer(360/20*i+45*(self.attack_count%2), self.x-0.7*(carpet.x-Enemy1Razer.MAP_CENTER_X),self.y-0.7*(carpet.y-Enemy1Razer.MAP_CENTER_Y)))
                #         self.attack_count = self.attack_count+1
                #         self.attack_delay = 0
            self.aniDelay=0

        if self.electric_shock_flag == True:
            self.electric_shock_aniDelay+=1
            self.electric_shock.clip_draw(self.electric_shock_frame*50, 0, 50,50, self.x-0.7*(carpet.x-350), self.y-0.7*(carpet.y-350))
            if self.electric_shock_aniDelay == 3:
                self.electric_shock_frame=(self.electric_shock_frame+1)%9
                self.electric_shock_aniDelay=0
                if self.electric_shock_frame == 0: self.electric_shock_flag = False

class SickleWind:

    sickleWindImg = None
    EYE_TO_RIGHT, EYE_TO_LEFT = 0, 1

    def __init__(self, dir, x, y, carpetX, carpetY):
        if SickleWind.sickleWindImg == None : SickleWind.sickleWindImg = load_image('enemy1/SickleWind.png')
        self.dir = dir
        self.carpetX = carpetX
        self.carpetY = carpetY
        self.x = x+150*(1-2*self.dir)
        self.y = y
        self.collision = False
        self.velocity = 1
        self.acceleration = 0


    def update(self):
        self.acceleration+=0.1
        self.x += (self.velocity+self.acceleration)*(1-2*self.dir)

    def draw(self, carpetX, carpetY):
        if self.collision == False :self.sickleWindImg.clip_draw(100*self.dir, 0, 100,350, self.x-0.7*(carpetX-self.carpetX), self.y-0.7*(carpetY-self.carpetY))
        else:
            for i in range(-1, len(enemy1SickleWindList)-1):
                if self == enemy1SickleWindList[i]:
                    del enemy1SickleWindList[i]
                    break

class Enemy1Razer:
    global hero
    global carpet
    global ballRazerBox

    razer = None
    MAP_CENTER_X, MAP_CENTER_Y = 350, 350

    def __init__(self, angle, x, y):
        if Enemy1Razer.razer == None:
            Enemy1Razer.razer = load_image('enemy1/enemy1razer.png')
        self.x = x
        self.y = y
        self.angle = angle
        self.collision = False
        self.carpetX = carpet.x
        self.carpetY = carpet.y
        self.velocity = 3
        self.acceleration = 0
        self.power=20
        self.slope = 0
    def update(self):
        if self.collision == False:
            self.acceleration+=0.01
            self.slope+=1
            self.x += self.velocity*self.acceleration*math.cos(math.pi/180*(self.angle))
            self.y += self.velocity*self.acceleration*math.sin(math.pi/180*(self.angle))

    def draw(self):
        if self.collision == False : self.razer.clip_draw(0, 0, 15,15, self.x-0.7*(carpet.x-self.carpetX), self.y-0.7*(carpet.y-self.carpetY))
        else:
            for i in range(-1, len(enemy1RazerBox)-1):
                if self == enemy1RazerBox[i]:
                    del enemy1RazerBox[i]
                    break

#인질 클래스
class Hostage:
    global carpet
    global hostageList

    #king, queen, butler, knight, clergy, slave1, slave2 = None, None, None, None, None, None, None
    hostage_set = None
    hostageDie = None
    hostage_data = None
    KING, BUTLER, KNIGHT, CLERGY, SLAVE1, SLAVE2, QUEEN = 0, 1, 2, 3, 4, 5, 6
    SPAN_POSITION = 375
    GUARD_MAX, GUARD_MIN = 350, -350
    MAP_CENTER_X, MAP_CENTER_Y = 350, 350
    UP, DOWN, LEFT, RIGHT = 0, 1, 2, 3
    #왕과 왕비는 한 스테이지에 한 번밖에 등장하지 않는다.
    #스테이지가 바뀌면 아래 두 클래스 변수는 0으로 초기화된다.
    #supervise_hostage에서 관리한다.
    king_appearance, queen_appearance = 0, 0

    hostage_position = {
        KING : 'KING',
        BUTLER : 'BUTLER',
        KNIGHT : 'KNIGHT',
        CLERGY : 'CLERGY',
        SLAVE1 : 'SLAVE1' ,
        SLAVE2 : 'SLAVE2',
        QUEEN : 'QUEEN'
    }

    def __init__(self):
        if Hostage.hostage_set == None : Hostage.hostage_set = load_image('hostage/hostage_set.png')
        if Hostage.hostageDie == None : Hostage.hostageDie = load_image('hostage/hostage_die.png')
        if Hostage.hostage_data == None :
            hostage_data_file = open('hostage/hostage_data.txt', 'r')
            Hostage.hostage_data = json.load(hostage_data_file)
            hostage_data_file.close()

        self.frame = 0
        self.aniDelay = 0
        self.x = 0
        self.y = 0
        self.HP_buff = 0
        self.guardMax = Hostage.GUARD_MAX
        self.guardMin = Hostage.GUARD_MIN
        self.turnFlag=random.randint(0, 1)
        self.velocity = random.randint(1, 2)
        self.position = random.randint(0+Hostage.king_appearance,100-Hostage.queen_appearance)
        self.direct = random.randint(0,3)
        self.survive = True

        if self.direct == self.UP : self.y += Hostage.SPAN_POSITION
        elif self.direct == self.DOWN : self.y -= Hostage.SPAN_POSITION
        elif self.direct == self.LEFT : self.x -= Hostage.SPAN_POSITION
        elif self.direct == self.RIGHT : self.x += Hostage.SPAN_POSITION
        self.point = 0

        if -1 < self.position and self.position < 1:
            self.position = self.KING
            Hostage.king_appearance = 1
        elif 0 < self.position and self.position < 11 : self.position = self.BUTLER
        elif 10 < self.position and self.position < 17 : self.position = self.KNIGHT
        elif 16 < self.position and self.position < 21 : self.position = self.CLERGY
        elif 20 < self.position and self.position < 100 : self.position = random.randint(self.SLAVE1, self.SLAVE2)
        elif 99 < self.position and self.position < 101:
            self.position = self.QUEEN
            Hostage.queen_appearance = 1
        self.point = Hostage.hostage_data[self.hostage_position[self.position]]['point']
        self.HP_buff = Hostage.hostage_data[self.hostage_position[self.position]]['HP_buff']
        self.life = True
    def update(self):
        if self.survive == True:
            if self.direct == self.UP or self.direct == self.DOWN:
                if self.turnFlag == 1:
                    self.x += self.velocity
                    if self.x > self.guardMax:
                        self.x=self.guardMax
                        self.guardMin=random.randint(Hostage.GUARD_MIN, self.x)
                        self.turnFlag = 0
                elif self.turnFlag == 0:
                    self.x -= self.velocity
                    if self.x < self.guardMin:
                        self.x=self.guardMin
                        self.guardMax=random.randint(self.x, Hostage.GUARD_MAX)
                        self.turnFlag = 1

            elif self.direct  == self.LEFT or self.direct  == self.RIGHT:
                if self.turnFlag == 1:
                    self.y += self.velocity
                    if self.y > self.guardMax:
                        self.y=self.guardMax
                        self.guardMin=random.randint(Hostage.GUARD_MIN, self.y)
                        self.turnFlag = 0
                elif self.turnFlag == 0:
                    self.y -= self.velocity
                    if self.y < self.guardMin:
                        self.y=self.guardMin
                        self.guardMax=random.randint(self.y, Hostage.GUARD_MAX)
                        self.turnFlag = 1
        else : pass
    def draw(self):
        global hostage_num
        self.aniDelay +=1
        if self.survive == True:
            self.hostage_set.clip_draw(self.frame*40, self.position*40, 40,40, Hostage.MAP_CENTER_X+self.x-0.20*(carpet.x-Hostage.MAP_CENTER_X), Hostage.MAP_CENTER_Y+self.y-0.20*(carpet.y-Hostage.MAP_CENTER_Y))
            if self.aniDelay == 30 :
                self.frame = (self.frame+1)%2
                self.aniDelay=0
        elif self.survive == False:
            self.hostageDie.clip_draw(self.frame*40, 0, 40,40, Hostage.MAP_CENTER_X+self.x-0.20*(carpet.x-Hostage.MAP_CENTER_X), Hostage.MAP_CENTER_Y+self.y-0.20*(carpet.y-Hostage.MAP_CENTER_Y))
            if self.aniDelay == 10:
                self.frame = (self.frame+1)%12
                self.aniDelay = 0
                if self.frame == 0:
                    for i in range(-1, len(hostageList)-1):
                        if self == hostageList[i]:
                            del hostageList[i]
                            hostage_num-=1
                            break

def distance(v1X,v1Y,  v2X, v2Y):
    return math.sqrt((v1X-v2X)*(v1X-v2X)+ (v1Y-v2Y)*(v1Y-v2Y))

#주인공의 스킬 속성 변화를 관리하는 함수
def supervise_bullet():
    global heroSkillBox
    global enemy2RazerBox
    global enemy2BombBox
    global ballRazerBox
    global enemy1
    global carpet
    global score
    global combo_flag
    global combo_score
    global combo_score_show_time
    global combo_score_degree

    #supervise skill1
    for i in range(-1, len(heroSkill1Box)-1):
        #if heroSkill1Box[i] in heroSkill1Box:
        if heroSkill1Box[i].direct == 'UP':
            if heroSkill1Box[i].y-0.7*(carpet.y-heroSkill1Box[i].carpetY) > 800-0.20*(carpet.y-350) : heroSkill1Box[i].collision = True
        elif heroSkill1Box[i].direct == 'DOWN':
            if heroSkill1Box[i].y-0.7*(carpet.y-heroSkill1Box[i].carpetY) < -100-0.20*(carpet.y-350) : heroSkill1Box[i].collision = True
        elif heroSkill1Box[i].direct == 'LEFT':
            if heroSkill1Box[i].x-0.7*(carpet.x-heroSkill1Box[i].carpetX) < -100-0.20*(carpet.x-350) : heroSkill1Box[i].collision = True
        elif heroSkill1Box[i].direct == 'RIGHT':
            if heroSkill1Box[i].x-0.7*(carpet.x-heroSkill1Box[i].carpetX) > 800-0.20*(carpet.x-350) : heroSkill1Box[i].collision = True

    # superbise_allSkill
    for i in range(-1, len(heroSkillBox)-1):
        for j in range(-1, len(heroSkillBox[i])-1):
            if heroSkillBox[i][j].collision == False:
                if enemy1.survive == True:
                    if enemy1.state != enemy1.ENEMY1_PATTERN1:
                        if ((enemy1.x-0.7*(carpet.x-350)-30 < heroSkillBox[i][j].x-0.7*(carpet.x-heroSkillBox[i][j].carpetX) and \
                            heroSkillBox[i][j].x-0.7*(carpet.x-heroSkillBox[i][j].carpetX) < enemy1.x-0.7*(carpet.x-350)+30 and \
                            enemy1.y-0.7*(carpet.y-350)+35 < heroSkillBox[i][j].y-0.7*(carpet.y-heroSkillBox[i][j].carpetY) and \
                            heroSkillBox[i][j].y-0.7*(carpet.y-heroSkillBox[i][j].carpetY) < enemy1.y-0.7*(carpet.y-350)+115) or \
                            (enemy1.x-0.7*(carpet.x-350)-35 < heroSkillBox[i][j].x-0.7*(carpet.x-heroSkillBox[i][j].carpetX) and \
                            heroSkillBox[i][j].x-0.7*(carpet.x-heroSkillBox[i][j].carpetX) < enemy1.x-0.7*(carpet.x-350)+35 and \
                            enemy1.y-0.7*(carpet.y-350)-35 < heroSkillBox[i][j].y-0.7*(carpet.y-heroSkillBox[i][j].carpetY) and \
                            heroSkillBox[i][j].y-0.7*(carpet.y-heroSkillBox[i][j].carpetY) < enemy1.y-0.7*(carpet.y-350)+35) or \
                            (enemy1.x-0.7*(carpet.x-350)-50 < heroSkillBox[i][j].x-0.7*(carpet.x-heroSkillBox[i][j].carpetX) and \
                            heroSkillBox[i][j].x-0.7*(carpet.x-heroSkillBox[i][j].carpetX) < enemy1.x-0.7*(carpet.x-350)+50 and \
                            enemy1.y-0.7*(carpet.y-350)-105 < heroSkillBox[i][j].y-0.7*(carpet.y-heroSkillBox[i][j].carpetY) and \
                            heroSkillBox[i][j].y-0.7*(carpet.y-heroSkillBox[i][j].carpetY) < enemy1.y-0.7*(carpet.y-350)-35)):
                            heroSkillBox[i][j].collision = True
                            enemy1.HP-=heroSkillBox[i][j].power
                            if enemy1.HP < 500:
                                enemy1.HP+=heroSkillBox[i][j].power
                                if enemy1.HP >= 500 : enemy1.HP = 500
                            score += 1
                    else:
                        if 120 > distance(heroSkillBox[i][j].x-0.7*(carpet.x-heroSkillBox[i][j].carpetX), heroSkillBox[i][j].y-0.7*(carpet.y-heroSkillBox[i][j].carpetY),
                                          enemy1.x-0.7*(carpet.x-350), enemy1.y-0.7*(carpet.y-350)):
                            heroSkillBox[i][j].collision = True
                            enemy1.HP-=heroSkillBox[i][j].power
                            if enemy1.HP < 500:
                                enemy1.HP+=heroSkillBox[i][j].power
                                if enemy1.HP >= 500 : enemy1.HP = 500
                            score += 1


    for i in range(-1, len(enemy1RazerBox)-1):
        if enemy1RazerBox[i].collision == False:
        #if ballRazerBox[i] in ballRazerBox:
            if enemy1RazerBox[i].y-0.7*(carpet.y-enemy1RazerBox[i].carpetY) > 800-0.20*(carpet.y-350) or \
                enemy1RazerBox[i].y-0.7*(carpet.y-enemy1RazerBox[i].carpetY) < -100-0.20*(carpet.y-350) or \
                enemy1RazerBox[i].x-0.7*(carpet.x-enemy1RazerBox[i].carpetX) < -100-0.20*(carpet.x-350) or \
                enemy1RazerBox[i].x-0.7*(carpet.x-enemy1RazerBox[i].carpetX) > 800-0.20*(carpet.x-350) :
                enemy1RazerBox[i].collision = True
# enemy1SickleWindList = []
# 인질의 속성 변화를 관리하는 함수

    for i in range(-1, len(enemy1SickleWindList)-1):
        if enemy1SickleWindList[i].collision == False:
        #if ballRazerBox[i] in ballRazerBox:
            if enemy1SickleWindList[i].y-0.7*(carpet.y-enemy1SickleWindList[i].carpetY) > 800-0.20*(carpet.y-350) or \
                enemy1SickleWindList[i].y-0.7*(carpet.y-enemy1SickleWindList[i].carpetY) < -100-0.20*(carpet.y-350) or \
                enemy1SickleWindList[i].x-0.7*(carpet.x-enemy1SickleWindList[i].carpetX) < -100-0.20*(carpet.x-350) or \
                enemy1SickleWindList[i].x-0.7*(carpet.x-enemy1SickleWindList[i].carpetX) > 800-0.20*(carpet.x-350) :
                enemy1SickleWindList[i].collision = True


def supervise_hostage():
    global hostageList
    global delay_create_hostage
    global carpet
    global hostage_num
    global king_state
    global queen_state
    global save_num
    global HP_buff_show_time
    global HP_buff_degree
    global score
    global combo_flag
    global combo_score
    global point_show_time
    global point_degree

    #도망치는 사람 생성을 관리한다.
    if hostage_num < 20:
        delay_create_hostage+=1
        if delay_create_hostage ==300:
            hostageList.append(Hostage())
            hostage_num+=1
            delay_create_hostage = 0
    #도망치는 사람이 구출됐을 경우
    for i in range(-1, len(hostageList)-1):
        if 80 > distance(350+hostageList[i].x-0.20*(carpet.x-350), 350+hostageList[i].y-0.20*(carpet.y-350), carpet.x, carpet.y ) and \
                hostageList[i].survive == True and hero.survive == True:
            if hostageList[i].position == hostageList[i].KING  :
                king_state = 'SAVE'
            elif hostageList[i].position == hostageList[i].QUEEN :
                queen_state = 'SAVE'
            if hero.HP < 100 : hero.HP += hostageList[i].HP_buffs
            if hero.HP >= 100 : hero.HP = 100
            HP_buff_degree = hostageList[i].HP_buff
            score += hostageList[i].point
            point_degree = hostageList[i].point
            HP_buff_show_time = 15
            point_show_time = 15
            combo_flag = True
            combo_score+=10
            del hostageList[i]
            hostage_num-=1
            save_num+=1
            break

def handle_events(): #플래그에 한 순간 영향받는 변수 처리
    global running
    global carpet
    global hero

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_ESCAPE: running = False
            # 마법 타입이 바뀔 수 있는 유일한 부분.l
            if event.key == SDLK_LSHIFT or event.key == SDLK_RSHIFT:
                hero.skill1Delay = 0
                hero.skill2Delay = 0
                if hero.skillType == 'SKILL1' : hero.skillType = 'SKILL2'
                elif hero.skillType == 'SKILL2' : hero.skillType = 'SKILL3'
                elif hero.skillType == 'SKILL3' : hero.skillType = 'SKILL1'
            if event.key == SDLK_d: carpet.goToRight = True
            if event.key == SDLK_a: carpet.goToLeft = True
            if event.key == SDLK_w: carpet.goToUp = True
            if event.key == SDLK_s: carpet.goToDown = True
            # 주인공의 공격 방향 설정 및 공격을 수행한다.
            if event.key == SDLK_i or event.key == SDLK_k or event.key ==SDLK_j or event.key == SDLK_l:
                if event.key == SDLK_i : hero.attackDirect = 'UP'
                if event.key == SDLK_k : hero.attackDirect = 'DOWN'
                if event.key == SDLK_j : hero.attackDirect = 'LEFT'
                if event.key == SDLK_l : hero.attackDirect = 'RIGHT'
                # hero.state는 공격 모션, 마법 탄환 생성에 영향을 준다.
                hero.state = 'ATTACK'
                hero.delay = 0
                hero.frame = 0
            if event.key == SDLK_SPACE and enemy1.survive == False:
                game_framework.change_state(stage2)
        elif event.type == SDL_KEYUP:
            if event.key == SDLK_d: carpet.goToRight = False
            if event.key == SDLK_a: carpet.goToLeft = False
            if event.key == SDLK_w: carpet.goToUp = False
            if event.key == SDLK_s: carpet.goToDown = False
            if event.key == SDLK_i or event.key == SDLK_k or event.key ==SDLK_j or event.key == SDLK_l:
                hero.attackDirect = 'DEFAULT'
                hero.state = 'NORMAL'
                hero.skill1Delay = 0
                hero.attackAniFlag = 0
                hero.delay = 0
                hero.frame = 0
            pass
        #공격 키 간에 동기화가 필요해보인다.

#UI 관련 클래스
ui = None
score = 0
combo_flag = False
combo_score = 0
combo_score_show_time = 0
combo_score_degree = 0
ultra_score = 5000
ultra_score_show_time = 0
kq_all_rescue_flag = False
font = None
#맵 관련 클래스
map = None

#주인공 관련 클래스
hero = None                       #주인공 인스턴스
heroSkillBox = []
heroSkill1Box = []                   #주인공 skill1 타입 마법 관리 리스트
heroSkill2Box = []                   #주인공 skill2 타입 마법 관리 리스트
heroSkill3Box = []                   #주인공 skill3 타입 마법 관리 리스트
heroSkillBox.append(heroSkill1Box)
heroSkillBox.append(heroSkill3Box)

#양탄자 관련 클래스
carpet = None

#enemy1 클래스
enemy1 = None
enemy1SickleWindList = []
enemy1RazerBox = []

#인질 리스트
hostageList=[]
delay_create_hostage = 0
hostage_num = 0
save_num = 0
HP_buff_show_time = 0
HP_buff_degree = 0
point_show_time = 0
point_degree = 0
king_state = 'NOT'
queen_state = 'NOT'


#running = True;

#리팩토링
def enter():

    global map
    global ui
    global hero
    global carpet
    global enemy1

    global score
    global combo_flag
    global combo_score
    global combo_score_show_time
    global combo_score_degree
    global ultra_score
    global ultra_score_show_time
    global kq_all_rescue_flag
    global font

    global delay_create_hostage
    global hostage_num
    global save_num
    global HP_buff_show_time
    global HP_buff_degree
    global point_show_time
    global point_degree
    global king_state
    global queen_state


    map = Map()
    ui = UI()
    hero = Hero()
    carpet = Carpet()
    enemy1 = Enemy1()

    score = 0
    combo_flag = False
    combo_score = 0
    combo_score_show_time = 0
    combo_score_degree = 0
    ultra_score = 5000
    ultra_score_show_time = 0
    kq_all_rescue_flag = False
    font = load_font('ENCR10B.TTF')

    delay_create_hostage = 0
    hostage_num = 0
    save_num = 0
    HP_buff_show_time = 0
    HP_buff_degree = 0
    point_show_time = 0
    point_degree = 0
    king_state = 'NOT'
    queen_state = 'NOT'

def exit():
    global map
    global ui
    global hero
    global carpet
    global enemy1
    global font

    global heroSkill1Box
    global heroSkill2Box
    global heroSkill3Box
    global heroSkillBox

    global hostageList

    while(len(heroSkill1Box)):
        del heroSkill1Box[0]
    while(len(heroSkill2Box)):
        del heroSkill2Box[0]
    while(len(heroSkill3Box)):
        del heroSkill3Box[0]

    while(len(enemy1SickleWindList)):
         del enemy1SickleWindList[0]
    while(len(enemy1RazerBox)):
        del enemy1RazerBox[0]

    while(len(hostageList)):
        del hostageList[0]

    del(map)
    del(ui)
    del(hero)
    del(carpet)
    del (enemy1)
    del (font)


def update():
    ui.update()
    carpet.update()
    hero.update()
    enemy1.update()
    for sickleWind in enemy1SickleWindList:
        sickleWind.update()
    for skill1 in heroSkill1Box:
        skill1.update()
    for skill3 in heroSkill3Box:
        skill3.update()
    for razer in enemy1RazerBox:
        razer.update()
    for hostage in hostageList:
        hostage.update()
    supervise_bullet()
    supervise_hostage()

    #delay(0.005)


def draw():

    global carpet
    clear_canvas()
    map.draw()
    carpet.draw()
    hero.draw()
    for hostage in hostageList:
        hostage.draw()
    for razer in enemy1RazerBox:
        razer.draw()
    enemy1.draw(carpet.x)
    for sickleWind in enemy1SickleWindList:
        sickleWind.draw(carpet.x, carpet.y)
    for skill1 in heroSkill1Box:
        skill1.draw()
    for skill2 in heroSkill2Box:
        skill2.draw()
    for skill3 in heroSkill3Box:
        skill3.draw()

    # ui.draw()

    update_canvas()


