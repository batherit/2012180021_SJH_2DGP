
from pico2d import *
import math
import random


#주인공의 공격 상태
enumerate(['NORAML', 'ATTACK' ])
#주인공의 공격 방향
enumerate(['DEFAULT','LEFT, RIGHT, UP, DOWN'])
#주인공의 공격 타입
enumerate(['SKILL1, SKILL2, SKILL3'])


#맵 클래스 : carpet의 움직임에 종속적
class Map:
    global carpet
    def __init__(self):
        self.mapCast = load_image('mapCast2.png')
        self.baseMap = load_image('baseMap.png')
        self.map1 = load_image('simpleMap1.png')
        self.map2 = load_image('simpleMap2.png')
        self.map3 = load_image('simpleMap3.png')
        self.map4 = load_image('simpleMap4.png')
        self.map5 = load_image('simpleMap5.png')
    def draw(self):
        self.baseMap.draw(450, 350)
        self.map1.draw(450-0.5*(carpet.x-350), 350-0.5*(carpet.y-350))
        self.map2.draw(450-0.25*(carpet.x-350), 350-0.25*(carpet.y-350))
        self.map3.draw(450-0.125*(carpet.x-350), 350-0.125*(carpet.y-350))
        self.map4.draw(450-0.0625*(carpet.x-350), 350-0.0625*(carpet.y-350))
        self.map5.draw(350-0.20*(carpet.x-350), 350-0.20*(carpet.y-350))
        self.mapCast.draw(450, 350)
    pass


#주인공 클래스 : carpet 클래스와 cootTime 변수에 종속적
#속성값 : 주인공 위치 좌표, 현재 상태(기본, 공격), 공격 방향, 공격 타입
class Hero:
    global carpet
    global coolTime
    global heroSkill1Box

    def __init__(self): #속성 초기화
        self.x = 0
        self.y = 0
        self.state = 'NORMAL'
        self.attackDirect = 'DEFAULT'
        self.skillType = 'SKILL1'
        self.hero = load_image('mainchar.png')
        self.attack = load_image('mainchar_attack.png')
        self.attackAniFlag = 0
        self.frame = 0
        self.delay = 0
        self.skill1Delay =0
    def update(self): #게임 로직
        #주인공이 공격 상태라면 탄환을 생성한다.
        if self.state == 'ATTACK':
            if self.skillType == 'SKILL1':
                self.skill1Delay+=1
                if self.skill1Delay == 8:
                    heroSkill1Box.append(Skill1())
                    self.skill1Delay = 0
                #for i in range(0, 100):
                #    if True == i not in heroSkill1Box:
                #        heroSkill1Box[i]= Skill1()
                #        break
            elif self.skillType == 'SKILL2':
                pass
            elif self.skillType == 'SKILL3':
                pass


    def draw(self): #게임 렌더링
        self.delay+=1
        if self.state == 'NORMAL': #아무런 입력이 없을 경우
            self.hero.clip_draw(self.frame*40, 0, 40,40, self.x+carpet.x, self.y+carpet.y)
            if self.delay == 10:
                self.frame = (self.frame+1) % 2
                self.delay = 0
        elif self.state == 'ATTACK': #스페이스키를 눌러 공격 형태가 됐을 경우
            if self.attackAniFlag == 0:
                self.attack.clip_draw(self.frame*40, 40, 40,40,self.x+carpet.x, self.y+carpet.y)
                if self.delay == 4:
                    self.frame = (self.frame+1) % 8
                    self.delay = 0
                    if self.frame == 0:
                        self.attackAniFlag = 1-self.attackAniFlag
            else:
                self.attack.clip_draw(self.frame*40, 0, 40,40, self.x+carpet.x, self.y+carpet.y)
                if self.delay == 4:
                    self.frame = (self.frame+1)%2
                    self.delay =0
                    #if self.frame == 0:
                    #    self.attackAniFlag = 1-self.attackAniFlag
            pass


#양탄자 클래스 : 이동방향 플래그 변수에 종속적
#속성값 : 양탄자 위치
class Carpet:
    global goToRight, goToLeft, goToUp, goToDown
    def __init__(self):
        self.x = 350
        self.y = 350
        self.carpet = load_image('carpet.png')

    def update(self):
        if goToRight == True:
            if self.x+50 > 650 : self.x -= 2
            else: self.x += 2
        if goToLeft == True:
            if self.x-50 < 50 : self.x += 2
            else: self.x -= 2
        if goToUp == True:
            if self.y+50 > 650 : self.y -=2
            else: self.y += 2
        if goToDown == True:
            if self.y-50 < 50 : self.y +=2
            else: self.y -= 2
    def draw(self):
        self.carpet.draw(self.x, self.y)
    pass

def angle(startX,startY,directX, directY):
    axisDegree = (180.0 / math.pi)*math.atan2(0.0, 1.0)
    if axisDegree < 0: axisDegree += 360
    moveDegree = (180.0 / math.pi)*math.atan2((directY - startY), (directX - startX))
    if moveDegree < 0: moveDegree += 360
    return moveDegree - axisDegree
#주인공 마법 타입1 클래스 : 주인공 클래스에 종속적
#속성값 : 마법 초기 생성 위치, 마법 진행 방향, 마법 진행 방향각, 마법 이동 속도
#전제 : Skill1 인스턴스는 hero 내에서 생성된다. (hero.state == 'ATTACK' 상태 )
class Skill1:
    global hero
    global carpet
    def __init__(self):
        self.skill1 = load_image('skill1.png')
        #마법은 주인공 기준으로 생성된다.
        self.x = hero.x+carpet.x
        self.y = hero.y+carpet.y
        self.angle = 0.0
        self.skill1=load_image('skill1.png')
        #마법 탄환 초기 생성 위치 초기화
        if hero.attackDirect=='UP':
            self.y += 30
            self.angle = angle(self.x, self.y, self.x+random.randint(-20, 20), self.y+500)
        elif hero.attackDirect == 'DOWN':
            self.y -= 30
            self.angle = angle(self.x, self.y, self.x+random.randint(-20, 20), self.y-500)
        elif hero.attackDirect == 'LEFT':
            self.x -= 30
            self.angle = angle(self.x, self.y, self.x-500, self.y+random.randint(-20, 20))
        elif hero.attackDirect == 'RIGHT':
            self.x += 30
            self.angle = angle(self.x, self.y, self.x+500, self.y+random.randint(-20, 20))
        self.direct = hero.attackDirect
        self.velocity = 4.0

    def update(self):
        self.x += self.velocity*math.cos(math.pi/180*self.angle)
        self.y += self.velocity*math.sin(math.pi/180*self.angle)
    def draw(self):
        self.skill1.clip_draw(0,0, 30, 30, self.x, self.y)



def handle_events(): #플래그에 한 순간 영향받는 변수 처리
    global running
    global goToRight, goToLeft, goToUp, goToDown
    global hero
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            running = False
        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_ESCAPE: running = False
            # 마법 타입이 바뀔 수 있는 유일한 부분.
            if event.key == SDLK_LSHIFT or event.key == SDLK_RSHIFT:
                #hero.skillType=(hero.skillType+1)%3
                pass
            if event.key == SDLK_d: goToRight = True
            if event.key == SDLK_a: goToLeft = True
            if event.key == SDLK_w: goToUp = True
            if event.key == SDLK_s: goToDown = True
            # 주인공의 공격 방향 설정 및 공격을 수행한다.
            if event.key == SDLK_i or event.key == SDLK_k or event.key ==SDLK_j or event.key == SDLK_l:
                if event.key == SDLK_i : hero.attackDirect = 'UP'
                if event.key == SDLK_k : hero.attackDirect = 'DOWN'
                if event.key == SDLK_j : hero.attackDirect = 'LEFT'
                if event.key == SDLK_l : hero.attackDirect = 'RIGHT'
                # hero.state는 공격 모션, 마법 탄환 생성에 영향을 준다.
                hero.state = 'ATTACK'
                hero.delay = 0
                hero.frame = 0

        elif event.type == SDL_KEYUP:
            if event.key == SDLK_d: goToRight = False
            if event.key == SDLK_a: goToLeft = False
            if event.key == SDLK_w: goToUp = False
            if event.key == SDLK_s: goToDown = False
            if event.key == SDLK_i or event.key == SDLK_k or event.key ==SDLK_j or event.key == SDLK_l:
                hero.attackDirect = 'DEFAULT'
                hero.state = 'NORMAL'
                hero.skill1Delay = 0
                hero.attackAniFlag = 0
                hero.delay = 0
                hero.frame = 0
            pass
        #공격 키 간에 동기화가 필요해보인다.

open_canvas(900, 700)

coolTime = 0.001

#맵 관련 클래스
map = Map()

#주인공 관련 클래스
hero = Hero()                       #주인공 인스턴스
heroSkill1Box=[]                    #주인공 skill1 타입 마법 관리 리스트

#양탄자 관련 클래스
carpet = Carpet()

goToRight = False
goToUp = False
goToDown = False
goToLeft = False

running = True;
while running:
#게임 로직 부
    handle_events()
    carpet.update()
    hero.update()
    for skill1 in heroSkill1Box:
        skill1.update()


#게임 렌더링 부
    clear_canvas()
    map.draw()
    carpet.draw()
    hero.draw()
    for skill1 in heroSkill1Box:
        skill1.draw()

    update_canvas()

    delay(coolTime)

close_canvas()
