from pico2d import *
from hero_skill import *
from stage1 import *
#주인공 클래스 : carpet 클래스와 cootTime 변수에 종속적
#속성값 : 주인공 위치 좌표, 현재 상태(기본, 공격), 공격 방향, 공격 타입
class Hero:

    SKILL1_SPAN_TIME = 5

    def __init__(self): #속성 초기화
        self.x = 0
        self.y = 0
        self.state = 'NORMAL'
        self.attackDirect = 'DEFAULT'
        self.skillType = 'SKILL1'
        self.hero = load_image('hero/mainchar.png')
        self.attack = load_image('hero/mainchar_attack.png')
        self.hero_die = load_image('hero/mainchar_die.png')
        self.attackAniFlag = 0
        self.frame = 0
        self.delay = 0
        self.skill1Delay = 0
        self.skill2Delay = 0
        self.skill3Delay = 0
        self.heroSkill3_num = 0
        self.heroSkill3CoolTime = 0
        self.HP = 100
        self.collision = False
        self.cooltime_after_collision = 50
        self.cooltime = 0
        self.survive = True
        self.delete = False
        self.heroSkillBox = []
        self.heroSkill1Box = []                   #주인공 skill1 타입 마법 관리 리스트
        self.heroSkill2Box = []                   #주인공 skill2 타입 마법 관리 리스트
        self.heroSkill3Box = []                   #주인공 skill3 타입 마법 관리 리스트
        self.heroSkillBox.append(self.heroSkill1Box)
        self.heroSkillBox.append(self.heroSkill3Box)


    def update(self, carpet): #게임 로직

        global heroSkill1Box
        global heroSkill2Box
        global heroSkill3Box

        if self.collision == True:
            self.cooltime+=1
            if self.cooltime == self.cooltime_after_collision:
                self.collision = False
                self.cooltime = 0
        #주인공이 공격 상태라면 탄환을 생성한다.
        if self.HP <= 0:
            if self.survive == True:
                self.survive = False
                self.frame = 0
                self.delay = 0
        if self.survive == True:
            if self.state == 'ATTACK':
                if self.skillType == 'SKILL1':
                    self.skill1Delay+=1
                    if self.skill1Delay == Hero.SKILL1_SPAN_TIME:
                        self.heroSkill1Box.append(Skill1(self, carpet))
                        self.skill1Delay = 0
                elif self.skillType == 'SKILL2':
                    self.skill2Delay+=1
                    if self.skill2Delay == 70:
                        self.heroSkill2Box.append(Skill2(self, carpet))
                        self.skill2Delay = 0
                elif self.skillType == 'SKILL3':
                    self.skill3Delay+=1
                    if self.skill3Delay == 15:
                        if self.heroSkill3_num < 5 :
                            self.heroSkill3_num+=1
                            self.heroSkill3Box.append(Skill3(self, carpet))
                        self.skill3Delay = 0
            if self.heroSkill3_num >= 5:
                self.heroSkill3CoolTime+=1
                if self.heroSkill3CoolTime == 300:
                    self.heroSkill3CoolTime = 0
                    self.heroSkill3_num = 0

    def draw(self, carpet): #게임 렌더링
        self.delay+=1
        if self.survive == True:
            if self.state == 'NORMAL': #아무런 입력이 없을 경우
                self.hero.clip_draw(self.frame*40, 0, 40,40, self.x+carpet.x, self.y+carpet.y)
                if self.delay == 10:
                    self.frame = (self.frame+1) % 2
                    self.delay = 0
            elif self.state == 'ATTACK': #스페이스키를 눌러 공격 형태가 됐을 경우
                if self.attackAniFlag == 0:
                    self.attack.clip_draw(self.frame*40, 40, 40,40,self.x+carpet.x, self.y+carpet.y)
                    if self.delay == 4:
                        self.frame = (self.frame+1) % 8
                        self.delay = 0
                        if self.frame == 0:
                            self.attackAniFlag = 1-self.attackAniFlag
                else:
                    self.attack.clip_draw(self.frame*40, 0, 40,40, self.x+carpet.x, self.y+carpet.y)
                    if self.delay == 4:
                        self.frame = (self.frame+1)%8
                        self.delay =0
                        #if self.frame == 0:
                        #    self.attackAniFlag = 1-self.attackAniFlag
        else:
            if self.delete == False :
                self.hero_die.clip_draw(self.frame*40, 0, 40,40, self.x+carpet.x, self.y+carpet.y)
                if self.delay == 10 :
                    if self.delete == False : self.frame = (self.frame+1)%12
                    if self.frame == 0 : self.delete = True
                    self.delay=0


