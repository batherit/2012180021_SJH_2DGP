from pico2d import *

#맵 클래스 : carpet의 움직임에 종속적
class Map:
    global carpet
    CENTER_POS_X, CENTER_POS_Y = 350, 350
    BASE_MAP_POS_X, BASE_MAP_POS_Y = 450, 350
    def __init__(self):
        #self.mapCast = load_image('map/mapCast2.png')
        self.baseMap = load_image('map/baseMap.png')
        self.map1 = load_image('map/simpleMap1.png')
        self.map2 = load_image('map/simpleMap2.png')
        self.map3 = load_image('map/simpleMap3.png')
        self.map4 = load_image('map/simpleMap4.png')
        self.map5 = load_image('map/simpleMap5.png')
    def draw(self, carpet):
        self.baseMap.draw(Map.BASE_MAP_POS_X, Map.BASE_MAP_POS_Y)
        self.map1.draw(Map.BASE_MAP_POS_X-0.5*(carpet.x-Map.CENTER_POS_X), Map.BASE_MAP_POS_Y-0.5*(carpet.y-Map.CENTER_POS_Y))
        self.map2.draw(Map.BASE_MAP_POS_X-0.25*(carpet.x-Map.CENTER_POS_X), Map.BASE_MAP_POS_Y-0.25*(carpet.y-Map.CENTER_POS_Y))
        self.map3.draw(Map.BASE_MAP_POS_X-0.125*(carpet.x-Map.CENTER_POS_X), Map.BASE_MAP_POS_Y-0.125*(carpet.y-Map.CENTER_POS_Y))
        self.map4.draw(Map.BASE_MAP_POS_X-0.0625*(carpet.x-Map.CENTER_POS_X), Map.BASE_MAP_POS_Y-0.0625*(carpet.y-Map.CENTER_POS_Y))
        self.map5.draw(Map.CENTER_POS_X-0.20*(carpet.x-Map.CENTER_POS_X), Map.CENTER_POS_Y-0.20*(carpet.y-Map.CENTER_POS_Y))
        #self.mapCast.draw(450, 350)
    pass
