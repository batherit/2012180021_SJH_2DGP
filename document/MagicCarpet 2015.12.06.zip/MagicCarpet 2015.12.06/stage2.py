import game_framework
import title_state
import math
import random
import json
import stage2_gap
from pico2d import *
from hero import Hero
from map import Map
from carpet import Carpet
from UI import UI
# from enemy2_skill import BallRazer
from enemy2 import Enemy2


#주인공의 공격 상태
enumerate(['NORAML', 'ATTACK' ])
#주인공의 공격 방향
enumerate(['DEFAULT','LEFT, RIGHT, UP, DOWN'])
#주인공의 공격 타입
enumerate(['SKILL1, SKILL2, SKILL3'])
#왕과 왕비 구출 상태
enumerate(['NOT', 'SAVE']) #APPEAR, DIE 추가 예정




def handle_events(): #플래그에 한 순간 영향받는 변수 처리
    global running
    global carpet
    global hero

    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            game_framework.quit()
        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_ESCAPE: running = False
            # 마법 타입이 바뀔 수 있는 유일한 부분.l
            if event.key == SDLK_LSHIFT or event.key == SDLK_RSHIFT:
                ui.magic_swap()
                hero.skill1Delay = 0
                hero.skill2Delay = 0
                if hero.skillType == 'SKILL1' : hero.skillType = 'SKILL2'
                elif hero.skillType == 'SKILL2' : hero.skillType = 'SKILL3'
                elif hero.skillType == 'SKILL3' : hero.skillType = 'SKILL1'
            if event.key == SDLK_d: carpet.goToRight = True
            if event.key == SDLK_a: carpet.goToLeft = True
            if event.key == SDLK_w: carpet.goToUp = True
            if event.key == SDLK_s: carpet.goToDown = True
            # 주인공의 공격 방향 설정 및 공격을 수행한다.
            if event.key == SDLK_i or event.key == SDLK_k or event.key ==SDLK_j or event.key == SDLK_l:
                if event.key == SDLK_i : hero.attackDirect = 'UP'
                if event.key == SDLK_k : hero.attackDirect = 'DOWN'
                if event.key == SDLK_j : hero.attackDirect = 'LEFT'
                if event.key == SDLK_l : hero.attackDirect = 'RIGHT'
                # hero.state는 공격 모션, 마법 탄환 생성에 영향을 준다.
                hero.state = 'ATTACK'
                hero.delay = 0
                hero.frame = 0
            if event.key == SDLK_SPACE :
                if enemy2.delete == True:
                    game_framework.change_state(title_state)
                elif hero.delete == True:
                    game_framework.change_state(stage2_gap)
        elif event.type == SDL_KEYUP:
            if event.key == SDLK_d: carpet.goToRight = False
            if event.key == SDLK_a: carpet.goToLeft = False
            if event.key == SDLK_w: carpet.goToUp = False
            if event.key == SDLK_s: carpet.goToDown = False
            if event.key == SDLK_i or event.key == SDLK_k or event.key ==SDLK_j or event.key == SDLK_l:
                hero.attackDirect = 'DEFAULT'
                hero.state = 'NORMAL'
                hero.skill1Delay = 0
                hero.attackAniFlag = 0
                hero.delay = 0
                hero.frame = 0
            pass
        #공격 키 간에 동기화가 필요해보인다.

#UI 관련 클래스
ui = None
# score = 0
# combo_flag = False
# combo_score = 0
# combo_score_show_time = 0
# combo_score_degree = 0
# ultra_score = 5000
# ultra_score_show_time = 0
# kq_all_rescue_flag = False
# font = None
#맵 관련 클래스
map = None

#주인공 관련 클래스
hero = None                       #주인공 인스턴스

#양탄자 관련 클래스
carpet = None

#enemy2 클래스
enemy2 = None
ballRazerBox = []


#running = True;

#리팩토링
def enter():

    global map
    global ui
    global hero
    global carpet
    global enemy2

    global score
    global combo_flag
    global combo_score
    global combo_score_show_time
    global combo_score_degree
    global ultra_score
    global ultra_score_show_time
    global kq_all_rescue_flag
    global font

    global delay_create_hostage
    global hostage_num
    global save_num
    global HP_buff_show_time
    global HP_buff_degree
    global point_show_time
    global point_degree
    global king_state
    global queen_state


    map = Map()
    ui = UI()
    hero = Hero()
    carpet = Carpet()
    enemy2 = Enemy2()

    score = 0
    combo_flag = False
    combo_score = 0
    combo_score_show_time = 0
    combo_score_degree = 0
    ultra_score = 5000
    ultra_score_show_time = 0
    kq_all_rescue_flag = False
    font = load_font('ENCR10B.TTF')

    delay_create_hostage = 0
    hostage_num = 0
    save_num = 0
    HP_buff_show_time = 0
    HP_buff_degree = 0
    point_show_time = 0
    point_degree = 0
    king_state = 'NOT'
    queen_state = 'NOT'

def exit():
    global map
    global ui
    global hero
    global carpet
    global enemy2
    global font

    global heroSkill1Box
    global heroSkill2Box
    global heroSkill3Box
    global heroSkillBox

    global enemy2RazerBox
    global enemy2BombBox
    global ballRazerBox

    global hostageList

    while(len(hero.heroSkill1Box)):
        del hero.heroSkill1Box[0]
    del hero.heroSkill1Box
    while(len(hero.heroSkill2Box)):
        del hero.heroSkill2Box[0]
    del hero.heroSkill2Box
    while(len(hero.heroSkill3Box)):
        del hero.heroSkill3Box[0]
    del hero.heroSkill3Box
    del hero.heroSkillBox
    # while(len(heroSkillBox)):
    #     heroSkillBox.pop(0)
    while(len(enemy2.ballList)):
        del enemy2.ballList[0]

    while(len(enemy2.enemy2RazerBox)):
        del enemy2.enemy2RazerBox[0]
    while(len(enemy2.enemy2BombBox)):
        del enemy2.enemy2BombBox[0]
    while(len(ballRazerBox)):
        del ballRazerBox[0]

    while(len(ui.hostageList)):
        del ui.hostageList[0]

    del(map)
    del(ui)
    del(hero)
    del(carpet)
    del (enemy2)
    del (font)


def update():
    ui.update(hero, enemy2)
    carpet.update()
    hero.update(carpet)
    enemy2.update(carpet)
    for ball in enemy2.ballList:
        ball.update(carpet, enemy2, ballRazerBox)
    for skill1 in hero.heroSkill1Box:
        skill1.update()
    for skill3 in hero.heroSkill3Box:
        skill3.update()
    for razer in enemy2.enemy2RazerBox:
        razer.update()
    for razer in ballRazerBox:
        razer.update()
    for hostage in ui.hostageList:
        hostage.update()
    ui.supervise_bullet(hero, carpet, enemy2, 2,ballRazerBox)
    ui.supervise_hostage(hero, carpet, enemy2, ui)
    #delay(0.005)


def draw():
    clear_canvas()
    map.draw(carpet)
    carpet.draw()
    hero.draw(carpet)
    for hostage in ui.hostageList:
        hostage.draw(carpet, ui)
    enemy2.draw(carpet, ui)

    for ball in enemy2.ballList:
        ball.draw(carpet, enemy2)
    for skill1 in hero.heroSkill1Box:
        skill1.draw(hero, carpet)
    for skill2 in hero.heroSkill2Box:
        skill2.draw(hero, carpet, enemy2, ui,2 )
    for skill3 in hero.heroSkill3Box:
        skill3.draw(hero, carpet)
    for razer in enemy2.enemy2RazerBox:
        razer.draw(enemy2, carpet)
    for razer in ballRazerBox:
        razer.draw(carpet, ballRazerBox)
    for bomb in enemy2.enemy2BombBox:
        bomb.draw(enemy2, carpet, ui, hero)

    ui.draw(hero, carpet, enemy2, 2)

    update_canvas()


