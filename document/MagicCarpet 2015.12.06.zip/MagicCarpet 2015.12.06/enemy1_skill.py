import math
from pico2d import *


class SickleWind:

    sickleWindImg = None
    EYE_TO_RIGHT, EYE_TO_LEFT = 0, 1

    def __init__(self, dir, x, y, carpetX, carpetY):
        if SickleWind.sickleWindImg == None : SickleWind.sickleWindImg = load_image('enemy1/SickleWind.png')
        self.dir = dir
        self.carpetX = carpetX
        self.carpetY = carpetY
        self.x = x+150*(1-2*self.dir)
        self.y = y
        self.collision = False
        self.velocity = 4
        self.acceleration = 0
        self.power=30

    def update(self):
        self.acceleration+=0.5
        self.x += (self.velocity+self.acceleration)*(1-2*self.dir)

    def draw(self, carpetX, carpetY, enemy):
        if self.collision == False :self.sickleWindImg.clip_draw(100*self.dir, 0, 100,350, self.x-0.7*(carpetX-self.carpetX), self.y-0.7*(carpetY-self.carpetY))
        else:
            for i in range(-1, len(enemy.enemy1SickleWindList)-1):
                if self == enemy.enemy1SickleWindList[i]:
                    del enemy.enemy1SickleWindList[i]
                    break

class Enemy1Razer:
    global hero
    global carpet
    global ballRazerBox

    razer = None
    MAP_CENTER_X, MAP_CENTER_Y = 350, 350

    def __init__(self, angle, x, y, carpet):
        if Enemy1Razer.razer == None:
            Enemy1Razer.razer = load_image('enemy1/enemy1razer.png')
        self.x = x
        self.y = y
        self.angle = angle
        self.collision = False
        self.carpetX = carpet.x
        self.carpetY = carpet.y
        self.velocity = 3
        self.acceleration = 0
        self.power=20
        self.slope = 0
    def update(self):
        if self.collision == False:
            self.acceleration+=0.01
            self.slope+=1
            self.x += self.velocity*self.acceleration*math.cos(math.pi/180*(self.angle))
            self.y += self.velocity*self.acceleration*math.sin(math.pi/180*(self.angle))

    def draw(self, enemy, carpet):
        if self.collision == False : self.razer.clip_draw(0, 0, 15,15, self.x-0.7*(carpet.x-self.carpetX), self.y-0.7*(carpet.y-self.carpetY))
        else:
            for i in range(-1, len(enemy.enemy1RazerBox)-1):
                if self == enemy.enemy1RazerBox[i]:
                    del enemy.enemy1RazerBox[i]
                    break
