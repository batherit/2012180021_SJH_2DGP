import math

def angle(startX,startY,directX, directY):
    axisDegree = (180.0 / math.pi)*math.atan2(0.0, 1.0)
    if axisDegree < 0: axisDegree += 360
    moveDegree = (180.0 / math.pi)*math.atan2((directY - startY), (directX - startX))
    if moveDegree < 0: moveDegree += 360
    return moveDegree - axisDegree

def distance(v1X,v1Y,  v2X, v2Y):
    return math.sqrt((v1X-v2X)*(v1X-v2X)+ (v1Y-v2Y)*(v1Y-v2Y))