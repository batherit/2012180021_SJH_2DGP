
from pico2d import *
import math
import random

class Map:
    global carpet
    def __init__(self):
        self.mapCast = load_image('mapCast.png')
        self.baseMap = load_image('baseMap.png')
        self.map1 = load_image('simpleMap1.png')
        self.map2 = load_image('simpleMap2.png')
        self.map3 = load_image('simpleMap3.png')
        self.map4 = load_image('simpleMap4.png')
    def draw(self):
        self.baseMap.draw(450, 350)
        self.map1.draw(450-0.5*(carpet.x-350), 350-0.5*(carpet.y-350))
        self.map2.draw(450-0.25*(carpet.x-350), 350-0.25*(carpet.y-350))
        self.map3.draw(450-0.125*(carpet.x-350), 350-0.125*(carpet.y-350))
        self.map4.draw(450-0.0625*(carpet.x-350), 350-0.0625*(carpet.y-350))
        self.mapCast.draw(450, 350)
    pass

class Hero:
    global carpet
    global coolTime

    def __init__(self):
        self.x = 0
        self.y = 0
        self.hero = load_image('mainchar_pix.png')
        self.frame = 0
        self.delay = 0
    def update(self): #게임 로직
        self.delay+=1
        if self.delay == 10:
            self.frame = (self.frame+1) % 2
            self.delay=0
    def draw(self): #게임 렌더링
        self.hero.clip_draw(self.frame*40, 0, 40,40, self.x+carpet.x, self.y+carpet.y)
    pass

class Carpet:
    global carpet
    def __init__(self):
        self.x = 350
        self.y = 350
        self.carpet = load_image('carpet.png')
    def draw(self):
        self.carpet.draw(carpet.x, carpet.y)
    pass

def process_flag():
    global carpet
    global goToRight, goToLeft, goToUp, goToDown
    if goToRight == True:
        if carpet.x+50 > 650 : carpet.x -= 5
        else: carpet.x += 5
    if goToLeft == True:
        if carpet.x-50 < 50 : carpet.x += 5
        else: carpet.x -= 5
    if goToUp == True:
        if carpet.y+50 > 650 : carpet.y -=5
        else: carpet.y += 5
    if goToDown == True:
        if carpet.y-50 < 50 : carpet.y +=5
        else: carpet.y -= 5


def handle_events():
    global running
    global goToRight, goToLeft, goToUp, goToDown
    events = get_events()
    for event in events:
        if event.type == SDL_QUIT:
            running = False

        elif event.type == SDL_KEYDOWN:
            if event.key == SDLK_ESCAPE: running = False
            if event.key == SDLK_RIGHT: goToRight = True
            if event.key == SDLK_LEFT: goToLeft = True
            if event.key == SDLK_UP: goToUp = True
            if event.key == SDLK_DOWN: goToDown = True

        elif event.type == SDL_KEYUP:
            if event.key == SDLK_RIGHT: goToRight = False
            if event.key == SDLK_LEFT: goToLeft = False
            if event.key == SDLK_UP: goToUp = False
            if event.key == SDLK_DOWN: goToDown = False
            pass

open_canvas(900, 700)

#team = [Boy() for i in range(11)]
coolTime = 0.01

map = Map()
hero = Hero()
carpet = Carpet()

goToRight = False
goToUp = False
goToDown = False
goToLeft = False

running = True;
while running:
#게임 로직 부
    handle_events()
    process_flag()

    hero.update()

#게임 렌더링 부
    clear_canvas()
    map.draw()
    carpet.draw()
    hero.draw()

    update_canvas()

    delay(coolTime)

close_canvas()
