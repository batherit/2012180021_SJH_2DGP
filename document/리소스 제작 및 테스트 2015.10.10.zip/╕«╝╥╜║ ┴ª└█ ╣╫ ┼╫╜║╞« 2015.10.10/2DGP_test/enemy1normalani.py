from pico2d import *
open_canvas(300,200)
enemy1normal=load_image('enemy1normal.png')

x=0
frame = 0
fFlag = 0
while (x<100):
    clear_canvas()
    enemy1normal.clip_draw(frame*300, 0, 300,200, 150,100)
    frame = (frame+1)%8

    update_canvas()

    x+=1
    delay(0.2)
    get_events()

close_canvas()