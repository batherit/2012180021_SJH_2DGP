from enemy1_skill import *
import random
from pico2d import *
import math
from simple_math_tool import *

#enemy1 클래스
class Enemy1:
    global hero
    global carpet

    enemy1img = None
    enemy1die = None
    enemy1disappear = None
    enemy1dark = None
    # enemy2die = None
    electric_shock = None

    EYE_TO_RIGHT, EYE_TO_LEFT = 0, 1
    EYE_TO_UP, EYE_TO_DOWN = 0, 1
    EYE_POSITION_Y = 80
    MAP_CENTER_X, MAP_CENTER_Y = 350, 350

    NORMAL, ENEMY1_PATTERN1, ENEMY1_PATTERN2, ENEMY1_PATTERN3  = 0, 1, 2, 3

    def enemy1_normal(self, carpet):        #enemy1의 평범한 움직임
        if self.move_count == 4:
            if self.frame == 0:     #self.aniDelay == 0 인 상태
                self.state = random.randint(1,3)#random.randint(0,3) #차후 추가되면 랜덤으로 패턴을 돌린다.
                self.move_flag = False
                self.move_count = 0
        else :
            if self.move_flag == False:
                self.move_delay+=1
                if self.move_delay == self.move_ding:
                    self.carpetX = carpet.x
                    self.carpetY = carpet.y
                    self.hero_around_angle += (-1+2*random.randint(0,1))*30
                    self.around_r = random.randint(-300,300)
                    self.endX = self.carpetX + self.around_r*math.cos(math.pi/180*self.hero_around_angle)
                    self.endY = self.carpetY + self.around_r*math.sin(math.pi/180*self.hero_around_angle)
                    self.angle = angle(self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X), self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y), self.endX, self.endY)
                    self.move_flag = True
                    self.move_delay = 0
                    self.move_ding = 1
                    self.velocity = 5
            elif self.move_flag == True:
                if 12 > distance(self.endX, self.endY,self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X), self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)):
                    self.move_flag = False
                    self.move_count+=1
                else:
                    self.x += self.velocity*math.cos(math.pi/180*self.angle)
                    self.y += self.velocity*math.sin(math.pi/180*self.angle)

    def enemy1_pattern1(self, carpet): #SickleWind!
        if self.move_count == 7:
            if self.frame == 0:     #self.aniDelay == 0 인 상태
                self.state = random.randint(1,3)#random.randint(0,3) #차후 추가되면 랜덤으로 패턴을 돌린다.
                self.move_flag = False
                self.move_count = 0
        else :
            if self.move_flag == False:
                self.move_delay+=1
                if self.move_delay == self.move_ding:
                    self.carpetX = carpet.x
                    self.carpetY = carpet.y
                    #self.hero_around_angle += (-1+2*random.randint(0,1))*30
                    self.around_r = random.randint(-200,200)
                    if math.fabs(carpet.x-(self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X))) > math.fabs(carpet.y-(self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y))):
                        self.endX = Enemy1.MAP_CENTER_X + (-1+2*self.ThisIsRight(carpet.x, carpet))*400-0.7*(self.carpetX-Enemy1.MAP_CENTER_X)
                        self.endY = Enemy1.MAP_CENTER_Y +  ((carpet.y-Enemy1.MAP_CENTER_Y)/400)*400-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)
                    else :
                        self.endX =Enemy1.MAP_CENTER_X +  ((carpet.x-Enemy1.MAP_CENTER_X)/400)*400-0.7*(self.carpetX-Enemy1.MAP_CENTER_X)
                        self.endY =Enemy1.MAP_CENTER_Y + (-1+2*self.ThisIsUP(carpet.y, carpet))*400-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)
                    self.angle = angle(self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X), self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y), self.endX, self.endY)
                    self.move_flag = True
                    self.move_delay = 0
                    self.move_ding = 1
                    self.velocity = 1
            elif self.move_flag == True:
                if 30 > distance(self.endX, self.endY, self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X), self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)) :
                    self.move_flag = False
                    self.acceleration = 0
                    self.move_count+=1
                else:
                    self.acceleration += 0.1
                    self.x += (self.velocity+self.acceleration)*math.cos(math.pi/180*self.angle)
                    self.y += (self.velocity+self.acceleration)*math.sin(math.pi/180*self.angle)


    def enemy1_pattern2(self, carpet): #HideAndSeek
        if self.move_count == 13:
            if self.frame == 0:     #self.aniDelay == 0 인 상태
                self.state = random.randint(1,3)#random.randint(0,3) #차후 추가되면 랜덤으로 패턴을 돌린다.
                self.move_flag = False
                self.move_count = 0
        else :
            if self.move_flag == False:
                self.move_delay+=1
                if self.move_delay == self.move_ding:
                    self.carpetX = carpet.x
                    self.carpetY = carpet.y
                    #self.hero_around_angle += (-1+2*random.randint(0,1))*30
                    self.around_r = random.randint(-200,200)
                    # if self.move_count <5:
                    self.endX = Enemy1.MAP_CENTER_X + (1-2*self.ThisIsRight(carpet.x, carpet))*(380+random.randint(-20, 20))-0.7*(self.carpetX-Enemy1.MAP_CENTER_X)
                    self.endY = Enemy1.MAP_CENTER_Y +  ((carpet.y-Enemy1.MAP_CENTER_Y)/350)*(400+random.randint(-20, 20))-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)
                    # else:
                    #     self.endX = Enemy1.MAP_CENTER_X + (-1+2*self.ThisIsRight(carpet.x))*(380+random.randint(-20, 20))-0.7*(self.carpetX-Enemy1.MAP_CENTER_X)
                    #     self.endY = Enemy1.MAP_CENTER_Y +  ((carpet.y-Enemy1.MAP_CENTER_Y)/350)*(400+random.randint(-20, 20))-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)
                    self.angle = angle(self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X), self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y), self.endX, self.endY)
                    self.move_flag = True
                    self.move_delay = 0
                    self.move_ding = 1
                    self.velocity = 5
            elif self.move_flag == True:
                if 30 > distance(self.endX, self.endY, self.x-0.7*(self.carpetX-Enemy1.MAP_CENTER_X), self.y-0.7*(self.carpetY-Enemy1.MAP_CENTER_Y)) :
                    self.move_flag = False
                    self.move_count+=1
                else:
                    self.x += (self.velocity+self.acceleration)*math.cos(math.pi/180*self.angle)
                    self.y += (self.velocity+self.acceleration)*math.sin(math.pi/180*self.angle)


    def enemy1_pattern3(self, carpet):
        if self.attack_time <= 0:
            if self.frame == 0:     #self.aniDelay == 0 인 상태
                self.state = random.randint(1,3)#random.randint(0,3) #차후 추가되면 랜덤으로 패턴을 돌린다.
                self.darkFlag = False
                self.disappear = False
                self.attack_time = 500
        else :
            if self.darkFlag == True:
                self.attack_time-=1
                if 10 < distance(carpet.x, carpet.y,self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y)):
                    self.angle = angle(self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y), carpet.x, carpet.y)
                    self.x += self.velocity*math.cos(math.pi/180*self.angle)
                    self.y += self.velocity*math.sin(math.pi/180*self.angle)
    enemy1_state = {
        NORMAL : enemy1_normal,
        ENEMY1_PATTERN1 : enemy1_pattern1,
        ENEMY1_PATTERN2 : enemy1_pattern2,
        ENEMY1_PATTERN3 : enemy1_pattern3
    }

    def ThisIsRight(self, objX, carpet):
        if self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X) < objX : return 1
        else : return 0
    def ThisIsUP(self, objY, carpet):
        if self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y) < objY : return 1
        else : return 0

    def __init__(self):
        self.x, self.y = Enemy1.MAP_CENTER_X+400*math.cos(math.pi/180 * random.randint(0, 360)), Enemy1.MAP_CENTER_Y+400*math.sin(math.pi/180 * random.randint(0, 360))
        self.frame = 0
        self.move_count = 0 #패턴 총 행동 횟수
        self.move_flag = False
        self.move_delay = 0
        self.move_ding = 10
        self.darkFlag = False
        self.angle = 0.0
        self.hero_around_angle = 0.0
        self.carpetX=0.0
        self.carpetY=0.0
        self.endX = 0.0
        self.endY = 0.0
        self.around_r = 0
        self.velocity = 0
        self.acceleration = 0
        self.state = Enemy1.NORMAL
        self.aniDelay = 0
        self.attack_time = 500
        self.attack_ding=0
        self.attack_delay = 0
        self.attack_count = 0
        self.attack_count_max = 0
        self.skillX = 0
        self.skillY = 0
        self.signFlag = 1
        self.HP = 600
        self.survive = True
        self.delete = False
        self.disappear=False
        self.electric_shock_flag = False
        self.electric_shock_frame = 0
        self.electric_shock_aniDelay = 0
        self.power = 20
        self.enemy1SickleWindList = []
        self.enemy1RazerBox = []

        # self.defensive_power = 5
        if Enemy1.enemy1img == None: Enemy1.enemy1img = load_image('enemy1/enemy1AniSet.png')
        if Enemy1.enemy1die == None: Enemy1.enemy1die = load_image('enemy1/enemy1die.png')
        if Enemy1.enemy1disappear == None : Enemy1.enemy1disappear = load_image('enemy1/pattern/enemy1darksign.png')
        if Enemy1.enemy1dark == None : Enemy1.enemy1dark = load_image('enemy1/pattern/enemy1pattern2dark.png')
        if Enemy1.electric_shock == None: Enemy1.electric_shock = load_image('hero/heroSkill/skill2boom.png')
    def update(self, carpet):
        if self.HP <= 0:
            if self.survive == True:
                self.survive = False
                self.disappear = False
                self.frame = 0
                self.aniDelay = 0
        if self.survive == True : self.enemy1_state[self.state](self, carpet)


    def draw(self, objX, carpet, ui):
        global enemy1
        global score
        global combo_flag
        global combo_score
        global combo_score_degree
        global combo_score_show_time

        self.aniDelay+=1
        if self.survive == True:
            #if self.state == self.NORMAL :
            if self.darkFlag == False : self.enemy1img.clip_draw(self.frame*300, 350*(1-self.ThisIsRight(objX, carpet))+700*(self.state), 300,350, self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y))
            else :
                self.enemy1img.clip_draw(self.frame*300, 350*(1-self.ThisIsRight(objX, carpet))+700*(self.state - 1), 300,350, self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y))
                self.enemy1dark.clip_draw(0, 0, 1250,1250, carpet.x, carpet.y)
                if self.disappear == False : self.enemy1disappear.clip_draw(self.frame*300, 80*(1-self.ThisIsRight(objX, carpet)), 300,80, self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y+Enemy1.EYE_POSITION_Y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y))
        else:
            if self.delete == False : self.enemy1die.clip_draw(self.frame*300, 0, 300,300, self.x-0.7*(carpet.x-350), self.y-0.7*(carpet.y-350))

        if self.aniDelay == 10 :
            if self.delete == False : self.frame = (self.frame+1)%8

            if self.survive == True:
                if self.state == self.ENEMY1_PATTERN2:
                    if self.frame == 4:
                        self.enemy1SickleWindList.append(SickleWind(1-self.ThisIsRight(carpet.x, carpet),self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y), carpet.x,carpet.y))
                elif self.state == self.ENEMY1_PATTERN3:
                    if self.darkFlag == False and self.frame == 0:
                        self.darkFlag = True
                        self.velocity = 1
                    # elif self.darkFlag == True and self.frame == 4 and 250 < distance(carpet.x, carpet.y,self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y)):
                    #     enemy1SickleWindList.append(SickleWind(self.ThisIsRight(carpet.x),self.x-0.7*(carpet.x-Enemy1.MAP_CENTER_X), self.y-0.7*(carpet.y-Enemy1.MAP_CENTER_Y), carpet.x,carpet.y))
                    elif self.darkFlag == True and self.disappear == False:
                        if self.frame == 0:
                            self.disappear = True
                            self.attack_ding = 2
                            self.attack_delay = 0
                            # self.attack_count = 0
                            # self.attack_count_max = 6
            else:
                if self.frame == 0:
                    self.delete = True
                    while(len(self.enemy1SickleWindList)):
                        del self.enemy1SickleWindList[0]
                    while(len(self.enemy1RazerBox)):
                        del self.enemy1RazerBox[0]
                    if ui.combo_flag == True:
                        ui.combo_flag = False
                        ui.combo_score_show_time = 15
                        ui.score += ui.combo_score
                        ui.combo_score_degree = ui.combo_score
                        ui.combo_score = 0
            if self.disappear == True:
                self.attack_delay +=1
                if self.attack_delay == self.attack_ding:
                    self.skillX= (Enemy1.MAP_CENTER_X+((-1+2*random.randint(0,1))*350))-0.7*(carpet.x-Enemy1.MAP_CENTER_X)
                    self.skillY= (Enemy1.MAP_CENTER_Y+((-1+2*random.randint(0,1))*350))-0.7*(carpet.y-Enemy1.MAP_CENTER_Y)
                    for i in range(0, 30):
                        self.enemy1RazerBox.append(Enemy1Razer(360/30*i+45*self.signFlag, self.skillX, self.skillY , carpet))
                    self.signFlag = 1-self.signFlag
                    self.attack_delay = 0
                #
                # if self.attack_count >= self.attack_count_max:
                #         self.attack_start = False
                #         self.move_count+=1
                        # self.attack_count=0
                        # self.x = Enemy1Razer.MAP_CENTER_X+random.randint(-Enemy1Razer.MAP_CENTER_X, Enemy1Razer.MAP_CENTER_X)+0.7*(carpet.x-Enemy1Razer.MAP_CENTER_X)
                        # self.y = Enemy1Razer.MAP_CENTER_Y+random.randint(-Enemy1Razer.MAP_CENTER_Y, Enemy1Razer.MAP_CENTER_Y)+0.7*(carpet.y-Enemy1Razer.MAP_CENTER_Y)
                        # self.disappear = False
                        # self.frame = 0
                        # self.attack_ding = 2
                        # self.attack_delay = 0
                        # self.attack_count = 0
                        # self.attack_count_max = 6
                # elif self.attack_count < self.attack_count_max:
                #     if self.attack_delay == self.attack_ding: #공격 입력
                #         for i in range(0, 20):
                #             enemy1RazerBox.append(Enemy1Razer(360/20*i+45*(self.attack_count%2), self.x-0.7*(carpet.x-Enemy1Razer.MAP_CENTER_X),self.y-0.7*(carpet.y-Enemy1Razer.MAP_CENTER_Y)))
                #         self.attack_count = self.attack_count+1
                #         self.attack_delay = 0
            self.aniDelay=0

        if self.electric_shock_flag == True:
            self.electric_shock_aniDelay+=1
            self.electric_shock.clip_draw(self.electric_shock_frame*50, 0, 50,50, self.x-0.7*(carpet.x-350), self.y-0.7*(carpet.y-350))
            if self.electric_shock_aniDelay == 3:
                self.electric_shock_frame=(self.electric_shock_frame+1)%9
                self.electric_shock_aniDelay=0
                if self.electric_shock_frame == 0: self.electric_shock_flag = False
